/*
SQLyog Ultimate v12.4.3 (64 bit)
MySQL - 10.1.26-MariaDB : Database - guitarhouse_dev
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`guitarhouse_dev` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;

USE `guitarhouse_dev`;

/*Table structure for table `account_availablecity` */

DROP TABLE IF EXISTS `account_availablecity`;

CREATE TABLE `account_availablecity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `slug` varchar(255) COLLATE utf8_bin,
  `shipping_fee` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `account_availablecity` */

insert  into `account_availablecity`(`id`,`name`,`slug`,`shipping_fee`) values 
(1,'Hong Kong','hk',5);

/*Table structure for table `account_availableshippingtime` */

DROP TABLE IF EXISTS `account_availableshippingtime`;

CREATE TABLE `account_availableshippingtime` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_bin NOT NULL,
  `day` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_availablesh_city_id_67992f8e_fk_account_availablecity_id` (`city_id`),
  CONSTRAINT `account_availablesh_city_id_67992f8e_fk_account_availablecity_id` FOREIGN KEY (`city_id`) REFERENCES `account_availablecity` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `account_availableshippingtime` */

insert  into `account_availableshippingtime`(`id`,`description`,`day`,`city_id`) values 
(1,'hkm',0,1);

/*Table structure for table `account_indexpagedata` */

DROP TABLE IF EXISTS `account_indexpagedata`;

CREATE TABLE `account_indexpagedata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `banners` longtext COLLATE utf8_bin,
  `coupons` longtext COLLATE utf8_bin,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `account_indexpagedata` */

insert  into `account_indexpagedata`(`id`,`banners`,`coupons`) values 
(1,'[{\"src\":\"/static/img/banner/banner-1.JPG\"}, {\"src\":\"/static/img/banner/banner-2.JPG\"}, {\"src\":\"/static/img/banner/banner-3.JPG\"}]','{}');

/*Table structure for table `account_message` */

DROP TABLE IF EXISTS `account_message`;

CREATE TABLE `account_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `subject` varchar(256) COLLATE utf8_bin DEFAULT NULL,
  `body` longtext COLLATE utf8_bin,
  `html` longtext COLLATE utf8_bin,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `account_message` */

insert  into `account_message`(`id`,`order_id`,`subject`,`body`,`html`) values 
(1,100006,'Confirmation of order 100006','Hello,\n\nWe are pleased to confirm your order 100006 has been received and\nwill be processed shortly.\n\nYour order contains:\n\n * product_gitar1 - quantity: 1 - price: \n\nCart total: \nShipping: \nOrder Total: \n\nShipping address:\n\n\n\n\n\nThe team\n','\n\n    <!doctype html>\n    <html lang=\"en\">\n    <head>\n        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n    </head>\n    <body>\n        <table style=\"width: 100%;\">\n            <tr>\n                <td style=\"height: 100px;\" align=\"center\">\n                    <a href=\"http://www.vanfruits.com\" target=\"_blank\">\n                        <img src=\"http://www.vanfruits.com/static/images/vanf.png\" alt=\"Vanfruits logo \" style=\"width: 200px; border: none;\">\n                    </a>\n                </td>\n            </tr>\n        </table>\n        <hr>\n        <div style=\"background-color:#f5f5f5;width:100%;\">\n            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\">\n                <tbody>\n                <tr>\n                    <td align=\"center\" valign=\"top\">\n                        <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" id=\"ecxtemplate_container\" style=\"border-radius:6px !important;background-color:#fdfdfd;border:1px solid #dcdcdc;border-radius:6px !important;\">\n                            <tbody>\n                            <tr>\n                                <td align=\"center\" valign=\"top\">\n                                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" id=\"ecxtemplate_header\" style=\"background-color:#557da1;color:#ffffff;border-top-left-radius:6px !important;border-top-right-radius:6px !important;border-bottom:0;font-family:Arial;font-weight:bold;line-height:100%;vertical-align:middle;\"\n                                           bgcolor=\"#557da1\">\n                                        <tbody>\n                                        <tr>\n                                            <td>\n                                                <h2 style=\"color:#ffffff;padding: 10px 24px;text-shadow:0 1px 0 #7797b4;display:block;font-family:Arial;font-size:20px;font-weight:bold;text-align:center;line-height:150%; margin-bottom: 0;\">\n                                                    謝謝您的訂單\n                                                    <br>\n                                                    Thank you for your order\n                                                </h2>\n\n                                            </td>\n                                        </tr>\n                                        </tbody>\n                                    </table>\n                                </td>\n                            </tr>\n                            <tr>\n                                <td align=\"center\" valign=\"top\">\n\n                                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" id=\"ecxtemplate_body\">\n                                        <tbody>\n                                        <tr>\n                                            <td valign=\"top\" style=\"background-color:#fdfdfd;border-radius:6px !important;\">\n\n                                                <table border=\"0\" cellpadding=\"20\" cellspacing=\"0\" width=\"100%\">\n                                                    <tbody>\n                                                    <tr>\n                                                        <td valign=\"top\" style=\"padding-top: 0; padding-bottom: 0;\" colspan=\"2\">\n                                                            <div style=\"color:#000; font-family:Arial;font-size:14px;line-height:150%;text-align:left;\">\n                                                                <p>\n                                                                    我們已經收到您的訂單，現在在處理當中。以下是您的訂單詳情。\n                                                                    <br>\n                                                                    Your order has been received and is now being\n                                                                    processed. Your order details are shown below for\n                                                                    your reference:\n                                                                </p>\n                                                                <p>\n                                                                    為確保向各位客戶提供更加優質的購物體驗，煩請選擇送貨到家的客人在下單前務必確保所選擇的送貨時間段內家中有人收貨，並註意保持手機，電話或微信等通訊方式順暢.如有特殊情況需要更改送貨時間或地址，請提前聯繫我們客服人員告知情況.\n                                                                    若送貨時家中無人收貨，我們會首先嘗試將貨品留在您家門口，客服人員會隨後與您聯繫處理付款事宜。對於家中無人收貨且通訊不暢的公寓住戶，我們會在您住所處等候5分鐘無果後離開，以確保不耽誤餘下的送單任務。而該訂單擇日再次補送時客人需要支付額外運費。</p>\n\n                                                                <ul class=\"ecxorder_details ecxbacs_details\"></ul>\n                                                                <h2 style=\"color:#505050;display:block;font-family:Arial;font-size:20px;font-weight:bold;text-align:left;line-height:150%;\">\n                                                                    \n                                                                        <img src=\"https://vanfruits.com/static/images/vanf.png\" style=\"width: 100px; float: left; margin-right: 50px;\">\n                                                                        訂單 / Order: 100006\n                                                                    \n                                                                </h2>\n\n                                                                <table cellspacing=\"0\" cellpadding=\"6\" style=\"width:100%;border:2px solid #e0e0e0;\">\n                                                                    <thead>\n                                                                    <tr>\n                                                                        <th scope=\"col\" style=\"text-align:left;border:2px solid #e0e0e0;\">\n                                                                            數量 / Quantity:\n                                                                        </th>\n                                                                        <th scope=\"col\" style=\"text-align:left;border:2px solid #e0e0e0;\">\n                                                                            產品 / Product\n                                                                        </th>\n                                                                        <th scope=\"col\" style=\"text-align:left;border:2px solid #e0e0e0;\">\n                                                                            總價 / Price\n                                                                        </th>\n                                                                    </tr>\n                                                                    </thead>\n                                                                    <tbody>\n                                                                    \n                                                                        <tr>\n                                                                            <td style=\"text-align:left;vertical-align:middle;border:2px solid #e0e0e0;word-wrap:break-word;\">\n                                                                                1\n                                                                            </td>\n                                                                            <td style=\"text-align:left;vertical-align:middle;border:2px solid #e0e0e0;\">\n                                                                                product_gitar1\n                                                                                \n                                                                                    <br> (\n                                                                                    11\n                                                                                    )\n                                                                                \n                                                                            </td>\n                                                                            <td style=\"text-align:left;vertical-align:middle;border:2px solid #e0e0e0;\">\n                                                                                \n                                                                            </td>\n                                                                        </tr>\n                                                                    \n                                                                    </tbody>\n                                                                    <tfoot>\n                                                                    \n                                                                        \n                                                                            \n                                                                        \n\n                                                                        \n                                                                            \n                                                                                <tr>\n                                                                                    <th colspan=\"2\" style=\"text-align: left; border: 2px solid #e0e0e0;\">購物車總價 / Basket total</th>\n                                                                                    <td colspan=\"1\" style=\"border: 2px solid #e0e0e0;\"></td>\n                                                                                </tr>\n                                                                            \n                                                                        \n                                                                    \n\n                                                                    \n                                                                        \n                                                                            <tr>\n                                                                                <th colspan=\"2\" style=\"text-align: left; border: 2px solid #e0e0e0;\">運費 / Shipping total</th>\n                                                                                <td colspan=\"1\" style=\"border: 2px solid #e0e0e0;\"></td>\n                                                                            </tr>\n                                                                        \n                                                                    \n\n                                                                    \n                                                                        <tr>\n                                                                            <th colspan=\"2\" style=\"text-align: left; border: 2px solid #e0e0e0;\">總價 / Order total</th>\n                                                                            <td colspan=\"1\" style=\"border: 2px solid #e0e0e0;\"></td>\n                                                                        </tr>\n                                                                    \n                                                                    </tfoot>\n                                                                </table>\n                                                                <!-- if shipping code is standard (delivery) then check if it\'s add to order else it must be pick up -->\n                                                                \n                                                                    <h2 style=\"color:#505050;display:block;font-family:Arial;font-size:20px;font-weight:bold;text-align:left;line-height:150%; margin-bottom: 0; text-decoration: underline;\">\n                                                                        取貨信息 / Shipping</h2>\n                                                                    <p style=\"margin-top: 0; margin-bottom: 5px;\">\n                                                                        <strong>取貨地址: Hong Kong</strong>\n                                                                    </p>\n                                                                \n                                                            </div>\n                                                        </td>\n                                                    </tr>\n                                                    <tr>\n                                                        <td style=\"padding-top: 0; padding-bottom: 0;\">\n                                                            <h2 style=\"color:#505050;display:block;font-family:Arial;font-size:20px;font-weight:bold;text-align:left;line-height:150%; margin-bottom: 0; text-decoration: underline;\">\n                                                                客户信息/ Client Info</h2>\n                                                            <p style=\"color:#000; margin-top: 0; text-align: left;\">\n                                                                \n                                                                    <strong>客户名字: </strong>\n                                                                    1\n                                                                    <br>\n                                                                    <strong>客户電話：</strong>\n                                                                    \n                                                                        1\n                                                                    <br>\n                                                                    <strong>取貨備註：</strong>\n                                                                        1<br>\n                                                                    \n                                                                    <strong>付费：</strong>\n                                                                    貨到付款\n                                                                    \n                                                                \n\n                                                            </p>\n                                                        </td>\n                                                        <td align=\"center\" style=\"padding: 0;\">\n                                                            <img src=\"https://vanfruits.com/static/images/vanfruits_qrcode_mini.jpg\"\n                                                                 width=\"170px\">\n                                                            <p style=\"font-size: 12px; margin: 0;\">為了更好的為您服務<br>\n                                                                請掃二維碼<br>添加温鲜生小秘微信</p>\n                                                        </td>\n                                                    </tr>\n                                                    \n                                                    <tr>\n                                                        <td style=\"padding-top: 5px; padding-bottom: 10px; text-align: left;\" colspan=\"2\">\n                                                            <h2 style=\"color:#505050;display:block;font-family:Arial;font-size:20px;font-weight:bold;text-align:left;line-height:150%; margin-bottom: 0; text-decoration: underline;\">\n                                                                聯系我們/ Contact Us</h2>\n                                                            <p style=\"color:#000; margin-top: 0;\">\n                                                                <strong>總部地址: </strong>211-669 Ridley Place Delta\n                                                                (Annacis Island)<br> (取貨時間為次日9am至5pm之間)<br>\n                                                                <strong>總部電話：</strong>604-568-8882<br>\n                                                                <strong>客服微信：</strong>vanfruits<br>\n                                                                <strong>官方網站: </strong>www.vanfruits.com<br>\n                                                                <strong>電子郵件：</strong>info@vanfruits.com<br>\n                                                                <strong>公眾服務號：van_fruits</strong></p>\n                                                        </td>\n                                                    </tr>\n                                                    </tbody>\n                                                </table>\n                                            </td>\n                                        </tr>\n                                        </tbody>\n                                    </table>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </td>\n                </tr>\n                </tbody>\n            </table>\n        </div>\n        \n    </body>\n    </html>\n\n\n\n<p>Thanks for using our site!</p>\n<p>The example.com team</p>\n');

/*Table structure for table `account_pickupinfo` */

DROP TABLE IF EXISTS `account_pickupinfo`;

CREATE TABLE `account_pickupinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data` longtext COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `account_pickupinfo` */

insert  into `account_pickupinfo`(`id`,`data`) values 
(2,'Hong Kong');

/*Table structure for table `account_verification` */

DROP TABLE IF EXISTS `account_verification`;

CREATE TABLE `account_verification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` longtext COLLATE utf8_bin,
  `phone` longtext COLLATE utf8_bin,
  `last_sent` datetime DEFAULT NULL,
  `verified` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `account_verification_user_id_a94367a_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `account_verification` */

/*Table structure for table `address_country` */

DROP TABLE IF EXISTS `address_country`;

CREATE TABLE `address_country` (
  `iso_3166_1_a2` varchar(2) COLLATE utf8_bin NOT NULL,
  `iso_3166_1_a3` varchar(3) COLLATE utf8_bin NOT NULL,
  `iso_3166_1_numeric` varchar(3) COLLATE utf8_bin NOT NULL,
  `printable_name` varchar(128) COLLATE utf8_bin NOT NULL,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `display_order` smallint(5) unsigned NOT NULL,
  `is_shipping_country` tinyint(1) NOT NULL,
  PRIMARY KEY (`iso_3166_1_a2`),
  KEY `address_country_010c8bce` (`display_order`),
  KEY `address_country_0b3676f8` (`is_shipping_country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `address_country` */

insert  into `address_country`(`iso_3166_1_a2`,`iso_3166_1_a3`,`iso_3166_1_numeric`,`printable_name`,`name`,`display_order`,`is_shipping_country`) values 
('HK','','','Hong Kong','Hong Kong',0,1);

/*Table structure for table `address_useraddress` */

DROP TABLE IF EXISTS `address_useraddress`;

CREATE TABLE `address_useraddress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) COLLATE utf8_bin NOT NULL,
  `first_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `last_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `line1` varchar(255) COLLATE utf8_bin NOT NULL,
  `line2` varchar(255) COLLATE utf8_bin NOT NULL,
  `line3` varchar(255) COLLATE utf8_bin NOT NULL,
  `line4` varchar(255) COLLATE utf8_bin NOT NULL,
  `state` varchar(255) COLLATE utf8_bin NOT NULL,
  `postcode` varchar(64) COLLATE utf8_bin NOT NULL,
  `search_text` longtext COLLATE utf8_bin NOT NULL,
  `phone_number` varchar(128) COLLATE utf8_bin NOT NULL,
  `notes` longtext COLLATE utf8_bin NOT NULL,
  `is_default_for_shipping` tinyint(1) NOT NULL,
  `is_default_for_billing` tinyint(1) NOT NULL,
  `num_orders` int(10) unsigned NOT NULL,
  `hash` varchar(255) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  `country_id` varchar(2) COLLATE utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address_useraddress_user_id_14958def_uniq` (`user_id`,`hash`),
  KEY `address_use_country_id_64461a5a_fk_address_country_iso_3166_1_a2` (`country_id`),
  KEY `address_useraddress_0800fc57` (`hash`),
  CONSTRAINT `address_use_country_id_64461a5a_fk_address_country_iso_3166_1_a2` FOREIGN KEY (`country_id`) REFERENCES `address_country` (`iso_3166_1_a2`),
  CONSTRAINT `address_useraddress_user_id_3a2086f2_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `address_useraddress` */

insert  into `address_useraddress`(`id`,`title`,`first_name`,`last_name`,`line1`,`line2`,`line3`,`line4`,`state`,`postcode`,`search_text`,`phone_number`,`notes`,`is_default_for_shipping`,`is_default_for_billing`,`num_orders`,`hash`,`date_created`,`country_id`,`user_id`) values 
(1,'Mr','','','First line of address:','','','Hong Kong','','','First line of address: Hong Kong Hong Kong','','',0,0,0,'1281151852','2018-06-24 03:44:44','HK',1);

/*Table structure for table `analytics_productrecord` */

DROP TABLE IF EXISTS `analytics_productrecord`;

CREATE TABLE `analytics_productrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `num_views` int(10) unsigned NOT NULL,
  `num_basket_additions` int(10) unsigned NOT NULL,
  `num_purchases` int(10) unsigned NOT NULL,
  `score` double NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`),
  KEY `analytics_productrecord_81a5c7b1` (`num_purchases`),
  CONSTRAINT `analytics_productrec_product_id_2ad3b0b8_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `analytics_productrecord` */

insert  into `analytics_productrecord`(`id`,`num_views`,`num_basket_additions`,`num_purchases`,`score`,`product_id`) values 
(2,34,0,4,0,3);

/*Table structure for table `analytics_userproductview` */

DROP TABLE IF EXISTS `analytics_userproductview`;

CREATE TABLE `analytics_userproductview` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created` datetime NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `analytics_userproductview_9bea82de` (`product_id`),
  KEY `analytics_userproductview_e8701ad4` (`user_id`),
  CONSTRAINT `analytics_userproduc_product_id_4d0aa3ed_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `analytics_userproductview_user_id_10f8c4b6_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `analytics_userproductview` */

insert  into `analytics_userproductview`(`id`,`date_created`,`product_id`,`user_id`) values 
(5,'2018-06-24 04:09:48',3,1),
(6,'2018-06-24 04:10:03',3,1),
(7,'2018-06-24 04:18:23',3,1),
(8,'2018-06-24 04:18:35',3,1),
(9,'2018-06-24 04:19:46',3,1),
(10,'2018-06-24 04:19:50',3,1),
(11,'2018-06-24 04:32:22',3,1),
(12,'2018-06-24 04:32:24',3,1),
(13,'2018-06-24 04:32:39',3,1),
(14,'2018-06-24 04:34:00',3,1),
(15,'2018-06-24 04:41:13',3,1),
(16,'2018-06-24 04:42:16',3,1),
(17,'2018-06-24 04:46:02',3,1),
(18,'2018-06-24 06:36:48',3,1),
(19,'2018-06-24 06:43:55',3,1),
(20,'2018-06-24 15:59:47',3,1),
(21,'2018-06-24 16:08:55',3,1),
(22,'2018-06-24 21:26:59',3,1),
(23,'2018-06-24 22:55:50',3,1),
(24,'2018-06-24 23:39:27',3,1),
(25,'2018-06-25 00:02:19',3,1),
(26,'2018-06-25 00:35:48',3,1),
(27,'2018-06-25 00:53:34',3,1),
(28,'2018-06-25 00:53:44',3,1),
(29,'2018-06-25 00:59:00',3,1),
(30,'2018-06-25 01:01:01',3,1),
(31,'2018-06-25 01:04:19',3,1),
(32,'2018-06-25 01:04:55',3,1),
(33,'2018-06-25 01:15:54',3,1);

/*Table structure for table `analytics_userrecord` */

DROP TABLE IF EXISTS `analytics_userrecord`;

CREATE TABLE `analytics_userrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `num_product_views` int(10) unsigned NOT NULL,
  `num_basket_additions` int(10) unsigned NOT NULL,
  `num_orders` int(10) unsigned NOT NULL,
  `num_order_lines` int(10) unsigned NOT NULL,
  `num_order_items` int(10) unsigned NOT NULL,
  `total_spent` decimal(12,2) NOT NULL,
  `date_last_order` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `analytics_userrecord_29bdb5ea` (`num_orders`),
  KEY `analytics_userrecord_89bb6879` (`num_order_lines`),
  KEY `analytics_userrecord_25cd4b4a` (`num_order_items`),
  CONSTRAINT `analytics_userrecord_user_id_67aaee86_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `analytics_userrecord` */

insert  into `analytics_userrecord`(`id`,`num_product_views`,`num_basket_additions`,`num_orders`,`num_order_lines`,`num_order_items`,`total_spent`,`date_last_order`,`user_id`) values 
(1,33,0,3,3,4,40000.00,'2018-06-25 01:22:47',1);

/*Table structure for table `analytics_usersearch` */

DROP TABLE IF EXISTS `analytics_usersearch`;

CREATE TABLE `analytics_usersearch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `query` varchar(255) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `analytics_usersearch_user_id_211b811b_fk_authUser_user_id` (`user_id`),
  KEY `analytics_usersearch_1b1cc7f0` (`query`),
  CONSTRAINT `analytics_usersearch_user_id_211b811b_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `analytics_usersearch` */

/*Table structure for table `auth_group` */

DROP TABLE IF EXISTS `auth_group`;

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `auth_group` */

/*Table structure for table `auth_group_permissions` */

DROP TABLE IF EXISTS `auth_group_permissions`;

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissi_permission_id_23962d04_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_group_permissi_permission_id_23962d04_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_58c48ba9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `auth_group_permissions` */

/*Table structure for table `auth_permission` */

DROP TABLE IF EXISTS `auth_permission`;

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permissi_content_type_id_51277a81_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=305 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `auth_permission` */

insert  into `auth_permission`(`id`,`name`,`content_type_id`,`codename`) values 
(1,'Can add log entry',1,'add_logentry'),
(2,'Can change log entry',1,'change_logentry'),
(3,'Can delete log entry',1,'delete_logentry'),
(4,'Can add permission',2,'add_permission'),
(5,'Can change permission',2,'change_permission'),
(6,'Can delete permission',2,'delete_permission'),
(7,'Can add group',3,'add_group'),
(8,'Can change group',3,'change_group'),
(9,'Can delete group',3,'delete_group'),
(10,'Can add content type',4,'add_contenttype'),
(11,'Can change content type',4,'change_contenttype'),
(12,'Can delete content type',4,'delete_contenttype'),
(13,'Can add session',5,'add_session'),
(14,'Can change session',5,'change_session'),
(15,'Can delete session',5,'delete_session'),
(16,'Can add site',6,'add_site'),
(17,'Can change site',6,'change_site'),
(18,'Can delete site',6,'delete_site'),
(19,'Can add flat page',7,'add_flatpage'),
(20,'Can change flat page',7,'change_flatpage'),
(21,'Can delete flat page',7,'delete_flatpage'),
(22,'Can add available city',8,'add_availablecity'),
(23,'Can change available city',8,'change_availablecity'),
(24,'Can delete available city',8,'delete_availablecity'),
(25,'Can add available shipping time',9,'add_availableshippingtime'),
(26,'Can change available shipping time',9,'change_availableshippingtime'),
(27,'Can delete available shipping time',9,'delete_availableshippingtime'),
(28,'Can add index page data',10,'add_indexpagedata'),
(29,'Can change index page data',10,'change_indexpagedata'),
(30,'Can delete index page data',10,'delete_indexpagedata'),
(31,'Can add pick up info',11,'add_pickupinfo'),
(32,'Can change pick up info',11,'change_pickupinfo'),
(33,'Can delete pick up info',11,'delete_pickupinfo'),
(34,'Can add verification',12,'add_verification'),
(35,'Can change verification',12,'change_verification'),
(36,'Can delete verification',12,'delete_verification'),
(37,'Can add message',13,'add_message'),
(38,'Can change message',13,'change_message'),
(39,'Can delete message',13,'delete_message'),
(40,'Can add User',14,'add_user'),
(41,'Can change User',14,'change_user'),
(42,'Can delete User',14,'delete_user'),
(43,'Can add Product record',15,'add_productrecord'),
(44,'Can change Product record',15,'change_productrecord'),
(45,'Can delete Product record',15,'delete_productrecord'),
(46,'Can add User record',16,'add_userrecord'),
(47,'Can change User record',16,'change_userrecord'),
(48,'Can delete User record',16,'delete_userrecord'),
(49,'Can add User product view',17,'add_userproductview'),
(50,'Can change User product view',17,'change_userproductview'),
(51,'Can delete User product view',17,'delete_userproductview'),
(52,'Can add User search query',18,'add_usersearch'),
(53,'Can change User search query',18,'change_usersearch'),
(54,'Can delete User search query',18,'delete_usersearch'),
(55,'Can add User address',19,'add_useraddress'),
(56,'Can change User address',19,'change_useraddress'),
(57,'Can delete User address',19,'delete_useraddress'),
(58,'Can add Country',20,'add_country'),
(59,'Can change Country',20,'change_country'),
(60,'Can delete Country',20,'delete_country'),
(61,'Can add Order and Item Charge',21,'add_orderanditemcharges'),
(62,'Can change Order and Item Charge',21,'change_orderanditemcharges'),
(63,'Can delete Order and Item Charge',21,'delete_orderanditemcharges'),
(64,'Can add Weight-based Shipping Method',22,'add_weightbased'),
(65,'Can change Weight-based Shipping Method',22,'change_weightbased'),
(66,'Can delete Weight-based Shipping Method',22,'delete_weightbased'),
(67,'Can add Weight Band',23,'add_weightband'),
(68,'Can change Weight Band',23,'change_weightband'),
(69,'Can delete Weight Band',23,'delete_weightband'),
(70,'Can add Product',24,'add_product'),
(71,'Can change Product',24,'change_product'),
(72,'Can delete Product',24,'delete_product'),
(73,'Can add Product class',25,'add_productclass'),
(74,'Can change Product class',25,'change_productclass'),
(75,'Can delete Product class',25,'delete_productclass'),
(76,'Can add Category',26,'add_category'),
(77,'Can change Category',26,'change_category'),
(78,'Can delete Category',26,'delete_category'),
(79,'Can add Product category',27,'add_productcategory'),
(80,'Can change Product category',27,'change_productcategory'),
(81,'Can delete Product category',27,'delete_productcategory'),
(82,'Can add Product recommendation',28,'add_productrecommendation'),
(83,'Can change Product recommendation',28,'change_productrecommendation'),
(84,'Can delete Product recommendation',28,'delete_productrecommendation'),
(85,'Can add Product attribute',29,'add_productattribute'),
(86,'Can change Product attribute',29,'change_productattribute'),
(87,'Can delete Product attribute',29,'delete_productattribute'),
(88,'Can add Product attribute value',30,'add_productattributevalue'),
(89,'Can change Product attribute value',30,'change_productattributevalue'),
(90,'Can delete Product attribute value',30,'delete_productattributevalue'),
(91,'Can add Attribute option group',31,'add_attributeoptiongroup'),
(92,'Can change Attribute option group',31,'change_attributeoptiongroup'),
(93,'Can delete Attribute option group',31,'delete_attributeoptiongroup'),
(94,'Can add Attribute option',32,'add_attributeoption'),
(95,'Can change Attribute option',32,'change_attributeoption'),
(96,'Can delete Attribute option',32,'delete_attributeoption'),
(97,'Can add Option',33,'add_option'),
(98,'Can change Option',33,'change_option'),
(99,'Can delete Option',33,'delete_option'),
(100,'Can add Product image',34,'add_productimage'),
(101,'Can change Product image',34,'change_productimage'),
(102,'Can delete Product image',34,'delete_productimage'),
(103,'Can add Product review',35,'add_productreview'),
(104,'Can change Product review',35,'change_productreview'),
(105,'Can delete Product review',35,'delete_productreview'),
(106,'Can add Vote',36,'add_vote'),
(107,'Can change Vote',36,'change_vote'),
(108,'Can delete Vote',36,'delete_vote'),
(109,'Can add Fulfillment partner',37,'add_partner'),
(110,'Can change Fulfillment partner',37,'change_partner'),
(111,'Can delete Fulfillment partner',37,'delete_partner'),
(112,'Can access dashboard',37,'dashboard_access'),
(113,'Can add Partner address',38,'add_partneraddress'),
(114,'Can change Partner address',38,'change_partneraddress'),
(115,'Can delete Partner address',38,'delete_partneraddress'),
(116,'Can add Stock record',39,'add_stockrecord'),
(117,'Can change Stock record',39,'change_stockrecord'),
(118,'Can delete Stock record',39,'delete_stockrecord'),
(119,'Can add Stock alert',40,'add_stockalert'),
(120,'Can change Stock alert',40,'change_stockalert'),
(121,'Can delete Stock alert',40,'delete_stockalert'),
(122,'Can add Basket',41,'add_basket'),
(123,'Can change Basket',41,'change_basket'),
(124,'Can delete Basket',41,'delete_basket'),
(125,'Can add Basket line',42,'add_line'),
(126,'Can change Basket line',42,'change_line'),
(127,'Can delete Basket line',42,'delete_line'),
(128,'Can add Line attribute',43,'add_lineattribute'),
(129,'Can change Line attribute',43,'change_lineattribute'),
(130,'Can delete Line attribute',43,'delete_lineattribute'),
(131,'Can add Transaction',44,'add_transaction'),
(132,'Can change Transaction',44,'change_transaction'),
(133,'Can delete Transaction',44,'delete_transaction'),
(134,'Can add Source',45,'add_source'),
(135,'Can change Source',45,'change_source'),
(136,'Can delete Source',45,'delete_source'),
(137,'Can add Source Type',46,'add_sourcetype'),
(138,'Can change Source Type',46,'change_sourcetype'),
(139,'Can delete Source Type',46,'delete_sourcetype'),
(140,'Can add Bankcard',47,'add_bankcard'),
(141,'Can change Bankcard',47,'change_bankcard'),
(142,'Can delete Bankcard',47,'delete_bankcard'),
(143,'Can add Conditional offer',48,'add_conditionaloffer'),
(144,'Can change Conditional offer',48,'change_conditionaloffer'),
(145,'Can delete Conditional offer',48,'delete_conditionaloffer'),
(146,'Can add Benefit',49,'add_benefit'),
(147,'Can change Benefit',49,'change_benefit'),
(148,'Can delete Benefit',49,'delete_benefit'),
(149,'Can add Condition',50,'add_condition'),
(150,'Can change Condition',50,'change_condition'),
(151,'Can delete Condition',50,'delete_condition'),
(152,'Can add Range',51,'add_range'),
(153,'Can change Range',51,'change_range'),
(154,'Can delete Range',51,'delete_range'),
(155,'Can add range product',52,'add_rangeproduct'),
(156,'Can change range product',52,'change_rangeproduct'),
(157,'Can delete range product',52,'delete_rangeproduct'),
(158,'Can add Range Product Uploaded File',53,'add_rangeproductfileupload'),
(159,'Can change Range Product Uploaded File',53,'change_rangeproductfileupload'),
(160,'Can delete Range Product Uploaded File',53,'delete_rangeproductfileupload'),
(161,'Can add Count condition',50,'add_countcondition'),
(162,'Can change Count condition',50,'change_countcondition'),
(163,'Can delete Count condition',50,'delete_countcondition'),
(164,'Can add Coverage Condition',50,'add_coveragecondition'),
(165,'Can change Coverage Condition',50,'change_coveragecondition'),
(166,'Can delete Coverage Condition',50,'delete_coveragecondition'),
(167,'Can add Value condition',50,'add_valuecondition'),
(168,'Can change Value condition',50,'change_valuecondition'),
(169,'Can delete Value condition',50,'delete_valuecondition'),
(170,'Can add Percentage discount benefit',49,'add_percentagediscountbenefit'),
(171,'Can change Percentage discount benefit',49,'change_percentagediscountbenefit'),
(172,'Can delete Percentage discount benefit',49,'delete_percentagediscountbenefit'),
(173,'Can add Absolute discount benefit',49,'add_absolutediscountbenefit'),
(174,'Can change Absolute discount benefit',49,'change_absolutediscountbenefit'),
(175,'Can delete Absolute discount benefit',49,'delete_absolutediscountbenefit'),
(176,'Can add Fixed price benefit',49,'add_fixedpricebenefit'),
(177,'Can change Fixed price benefit',49,'change_fixedpricebenefit'),
(178,'Can delete Fixed price benefit',49,'delete_fixedpricebenefit'),
(179,'Can add Multibuy discount benefit',49,'add_multibuydiscountbenefit'),
(180,'Can change Multibuy discount benefit',49,'change_multibuydiscountbenefit'),
(181,'Can delete Multibuy discount benefit',49,'delete_multibuydiscountbenefit'),
(182,'Can add shipping benefit',49,'add_shippingbenefit'),
(183,'Can change shipping benefit',49,'change_shippingbenefit'),
(184,'Can delete shipping benefit',49,'delete_shippingbenefit'),
(185,'Can add Shipping absolute discount benefit',49,'add_shippingabsolutediscountbenefit'),
(186,'Can change Shipping absolute discount benefit',49,'change_shippingabsolutediscountbenefit'),
(187,'Can delete Shipping absolute discount benefit',49,'delete_shippingabsolutediscountbenefit'),
(188,'Can add Fixed price shipping benefit',49,'add_shippingfixedpricebenefit'),
(189,'Can change Fixed price shipping benefit',49,'change_shippingfixedpricebenefit'),
(190,'Can delete Fixed price shipping benefit',49,'delete_shippingfixedpricebenefit'),
(191,'Can add Shipping percentage discount benefit',49,'add_shippingpercentagediscountbenefit'),
(192,'Can change Shipping percentage discount benefit',49,'change_shippingpercentagediscountbenefit'),
(193,'Can delete Shipping percentage discount benefit',49,'delete_shippingpercentagediscountbenefit'),
(194,'Can add Payment Event Quantity',65,'add_paymenteventquantity'),
(195,'Can change Payment Event Quantity',65,'change_paymenteventquantity'),
(196,'Can delete Payment Event Quantity',65,'delete_paymenteventquantity'),
(197,'Can add Shipping Event Quantity',66,'add_shippingeventquantity'),
(198,'Can change Shipping Event Quantity',66,'change_shippingeventquantity'),
(199,'Can delete Shipping Event Quantity',66,'delete_shippingeventquantity'),
(200,'Can add Order',67,'add_order'),
(201,'Can change Order',67,'change_order'),
(202,'Can delete Order',67,'delete_order'),
(203,'Can add Order Note',68,'add_ordernote'),
(204,'Can change Order Note',68,'change_ordernote'),
(205,'Can delete Order Note',68,'delete_ordernote'),
(206,'Can add Communication Event',69,'add_communicationevent'),
(207,'Can change Communication Event',69,'change_communicationevent'),
(208,'Can delete Communication Event',69,'delete_communicationevent'),
(209,'Can add Shipping address',70,'add_shippingaddress'),
(210,'Can change Shipping address',70,'change_shippingaddress'),
(211,'Can delete Shipping address',70,'delete_shippingaddress'),
(212,'Can add Billing address',71,'add_billingaddress'),
(213,'Can change Billing address',71,'change_billingaddress'),
(214,'Can delete Billing address',71,'delete_billingaddress'),
(215,'Can add Order Line',72,'add_line'),
(216,'Can change Order Line',72,'change_line'),
(217,'Can delete Order Line',72,'delete_line'),
(218,'Can add Line Price',73,'add_lineprice'),
(219,'Can change Line Price',73,'change_lineprice'),
(220,'Can delete Line Price',73,'delete_lineprice'),
(221,'Can add Line Attribute',74,'add_lineattribute'),
(222,'Can change Line Attribute',74,'change_lineattribute'),
(223,'Can delete Line Attribute',74,'delete_lineattribute'),
(224,'Can add Shipping Event',75,'add_shippingevent'),
(225,'Can change Shipping Event',75,'change_shippingevent'),
(226,'Can delete Shipping Event',75,'delete_shippingevent'),
(227,'Can add Shipping Event Type',76,'add_shippingeventtype'),
(228,'Can change Shipping Event Type',76,'change_shippingeventtype'),
(229,'Can delete Shipping Event Type',76,'delete_shippingeventtype'),
(230,'Can add Payment Event',77,'add_paymentevent'),
(231,'Can change Payment Event',77,'change_paymentevent'),
(232,'Can delete Payment Event',77,'delete_paymentevent'),
(233,'Can add Payment Event Type',78,'add_paymenteventtype'),
(234,'Can change Payment Event Type',78,'change_paymenteventtype'),
(235,'Can delete Payment Event Type',78,'delete_paymenteventtype'),
(236,'Can add Order Discount',79,'add_orderdiscount'),
(237,'Can change Order Discount',79,'change_orderdiscount'),
(238,'Can delete Order Discount',79,'delete_orderdiscount'),
(239,'Can add Email',80,'add_email'),
(240,'Can change Email',80,'change_email'),
(241,'Can delete Email',80,'delete_email'),
(242,'Can add Communication event type',81,'add_communicationeventtype'),
(243,'Can change Communication event type',81,'change_communicationeventtype'),
(244,'Can delete Communication event type',81,'delete_communicationeventtype'),
(245,'Can add Notification',82,'add_notification'),
(246,'Can change Notification',82,'change_notification'),
(247,'Can delete Notification',82,'delete_notification'),
(248,'Can add Product alert',83,'add_productalert'),
(249,'Can change Product alert',83,'change_productalert'),
(250,'Can delete Product alert',83,'delete_productalert'),
(251,'Can add Page Promotion',84,'add_pagepromotion'),
(252,'Can change Page Promotion',84,'change_pagepromotion'),
(253,'Can delete Page Promotion',84,'delete_pagepromotion'),
(254,'Can add Keyword Promotion',85,'add_keywordpromotion'),
(255,'Can change Keyword Promotion',85,'change_keywordpromotion'),
(256,'Can delete Keyword Promotion',85,'delete_keywordpromotion'),
(257,'Can add Raw HTML',86,'add_rawhtml'),
(258,'Can change Raw HTML',86,'change_rawhtml'),
(259,'Can delete Raw HTML',86,'delete_rawhtml'),
(260,'Can add Image',87,'add_image'),
(261,'Can change Image',87,'change_image'),
(262,'Can delete Image',87,'delete_image'),
(263,'Can add Multi Image',88,'add_multiimage'),
(264,'Can change Multi Image',88,'change_multiimage'),
(265,'Can delete Multi Image',88,'delete_multiimage'),
(266,'Can add Single product',89,'add_singleproduct'),
(267,'Can change Single product',89,'change_singleproduct'),
(268,'Can delete Single product',89,'delete_singleproduct'),
(269,'Can add Hand Picked Product List',90,'add_handpickedproductlist'),
(270,'Can change Hand Picked Product List',90,'change_handpickedproductlist'),
(271,'Can delete Hand Picked Product List',90,'delete_handpickedproductlist'),
(272,'Can add Ordered product',91,'add_orderedproduct'),
(273,'Can change Ordered product',91,'change_orderedproduct'),
(274,'Can delete Ordered product',91,'delete_orderedproduct'),
(275,'Can add Automatic product list',92,'add_automaticproductlist'),
(276,'Can change Automatic product list',92,'change_automaticproductlist'),
(277,'Can delete Automatic product list',92,'delete_automaticproductlist'),
(278,'Can add Ordered Product List',93,'add_orderedproductlist'),
(279,'Can change Ordered Product List',93,'change_orderedproductlist'),
(280,'Can delete Ordered Product List',93,'delete_orderedproductlist'),
(281,'Can add Tabbed Block',94,'add_tabbedblock'),
(282,'Can change Tabbed Block',94,'change_tabbedblock'),
(283,'Can delete Tabbed Block',94,'delete_tabbedblock'),
(284,'Can add Voucher',95,'add_voucher'),
(285,'Can change Voucher',95,'change_voucher'),
(286,'Can delete Voucher',95,'delete_voucher'),
(287,'Can add Voucher Application',96,'add_voucherapplication'),
(288,'Can change Voucher Application',96,'change_voucherapplication'),
(289,'Can delete Voucher Application',96,'delete_voucherapplication'),
(290,'Can add Wish List',97,'add_wishlist'),
(291,'Can change Wish List',97,'change_wishlist'),
(292,'Can delete Wish List',97,'delete_wishlist'),
(293,'Can add Wish list line',98,'add_line'),
(294,'Can change Wish list line',98,'change_line'),
(295,'Can delete Wish list line',98,'delete_line'),
(296,'Can add kv store',99,'add_kvstore'),
(297,'Can change kv store',99,'change_kvstore'),
(298,'Can delete kv store',99,'delete_kvstore'),
(299,'Can add ott order',100,'add_ottorder'),
(300,'Can change ott order',100,'change_ottorder'),
(301,'Can delete ott order',100,'delete_ottorder'),
(302,'Can add ott refund',101,'add_ottrefund'),
(303,'Can change ott refund',101,'change_ottrefund'),
(304,'Can delete ott refund',101,'delete_ottrefund');

/*Table structure for table `authuser_user` */

DROP TABLE IF EXISTS `authuser_user`;

CREATE TABLE `authuser_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) COLLATE utf8_bin NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `email` varchar(254) COLLATE utf8_bin NOT NULL,
  `first_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `last_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  `activation_code` varchar(255) COLLATE utf8_bin NOT NULL,
  `points` int(11) NOT NULL,
  `inviter_id` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `authuser_user` */

insert  into `authuser_user`(`id`,`password`,`last_login`,`is_superuser`,`email`,`first_name`,`last_name`,`is_staff`,`is_active`,`date_joined`,`activation_code`,`points`,`inviter_id`) values 
(1,'pbkdf2_sha256$20000$vypDBWqC0pMQ$5g5yEsRcmRJkgNltZAeu3KVg877tZoL9ypoBJIvEQ5Y=','2018-06-24 21:26:54',1,'admin@chinagood.net','','',1,1,'2018-06-24 03:18:17','',0,'');

/*Table structure for table `authuser_user_groups` */

DROP TABLE IF EXISTS `authuser_user_groups`;

CREATE TABLE `authuser_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `authUser_user_groups_group_id_c863770_fk_auth_group_id` (`group_id`),
  CONSTRAINT `authUser_user_groups_group_id_c863770_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `authUser_user_groups_user_id_31ffe409_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `authuser_user_groups` */

/*Table structure for table `authuser_user_user_permissions` */

DROP TABLE IF EXISTS `authuser_user_user_permissions`;

CREATE TABLE `authuser_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `authUser_user_user__permission_id_496d982d_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `authUser_user_user__permission_id_496d982d_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `authUser_user_user_permissi_user_id_1a5f0f81_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `authuser_user_user_permissions` */

/*Table structure for table `basket_basket` */

DROP TABLE IF EXISTS `basket_basket`;

CREATE TABLE `basket_basket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(128) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  `date_merged` datetime DEFAULT NULL,
  `date_submitted` datetime DEFAULT NULL,
  `owner_id` int(11),
  PRIMARY KEY (`id`),
  KEY `basket_basket_5e7b1936` (`owner_id`),
  CONSTRAINT `basket_basket_owner_id_7ee25cfc_fk_authUser_user_id` FOREIGN KEY (`owner_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `basket_basket` */

insert  into `basket_basket`(`id`,`status`,`date_created`,`date_merged`,`date_submitted`,`owner_id`) values 
(2,'Frozen','2018-06-24 04:19:34',NULL,NULL,1),
(3,'Merged','2018-06-24 21:26:49','2018-06-24 21:26:57',NULL,NULL),
(4,'Frozen','2018-06-25 00:51:54',NULL,NULL,1),
(5,'Frozen','2018-06-25 00:58:49',NULL,NULL,1),
(6,'Submitted','2018-06-25 01:00:53',NULL,'2018-06-25 01:01:59',1),
(7,'Submitted','2018-06-25 01:04:12',NULL,'2018-06-25 01:05:34',1),
(8,'Submitted','2018-06-25 01:15:52',NULL,'2018-06-25 01:22:47',1),
(9,'Merged','2018-06-25 01:18:20','2018-06-25 01:18:54',NULL,1);

/*Table structure for table `basket_basket_vouchers` */

DROP TABLE IF EXISTS `basket_basket_vouchers`;

CREATE TABLE `basket_basket_vouchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `basket_id` int(11) NOT NULL,
  `voucher_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `basket_id` (`basket_id`,`voucher_id`),
  KEY `basket_basket_vouchers_voucher_id_130f453a_fk_voucher_voucher_id` (`voucher_id`),
  CONSTRAINT `basket_basket_vouchers_basket_id_1f0dcb7_fk_basket_basket_id` FOREIGN KEY (`basket_id`) REFERENCES `basket_basket` (`id`),
  CONSTRAINT `basket_basket_vouchers_voucher_id_130f453a_fk_voucher_voucher_id` FOREIGN KEY (`voucher_id`) REFERENCES `voucher_voucher` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `basket_basket_vouchers` */

/*Table structure for table `basket_line` */

DROP TABLE IF EXISTS `basket_line`;

CREATE TABLE `basket_line` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_reference` varchar(128) COLLATE utf8_bin NOT NULL,
  `quantity` int(10) unsigned NOT NULL,
  `price_currency` varchar(12) COLLATE utf8_bin NOT NULL,
  `price_excl_tax` decimal(12,2) DEFAULT NULL,
  `price_incl_tax` decimal(12,2) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `basket_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `stockrecord_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `basket_line_basket_id_7fd92c45_uniq` (`basket_id`,`line_reference`),
  KEY `basket_line_767217f5` (`line_reference`),
  KEY `basket_line_afdeaea9` (`basket_id`),
  KEY `basket_line_9bea82de` (`product_id`),
  KEY `basket_line_271c5733` (`stockrecord_id`),
  CONSTRAINT `basket_line_basket_id_19c0cd86_fk_basket_basket_id` FOREIGN KEY (`basket_id`) REFERENCES `basket_basket` (`id`),
  CONSTRAINT `basket_line_product_id_50bef418_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `basket_line_stockrecord_id_54703c38_fk_partner_stockrecord_id` FOREIGN KEY (`stockrecord_id`) REFERENCES `partner_stockrecord` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `basket_line` */

insert  into `basket_line`(`id`,`line_reference`,`quantity`,`price_currency`,`price_excl_tax`,`price_incl_tax`,`date_created`,`basket_id`,`product_id`,`stockrecord_id`) values 
(2,'3_1',15,'CNY',10000.00,10000.00,'2018-06-24 04:19:48',2,3,1),
(4,'3_1',2,'CNY',10000.00,10000.00,'2018-06-25 00:53:38',4,3,1),
(5,'3_1',1,'CNY',10000.00,10000.00,'2018-06-25 00:59:02',5,3,1),
(6,'3_1',1,'CNY',10000.00,10000.00,'2018-06-25 01:01:02',6,3,1),
(7,'3_1',2,'CNY',10000.00,10000.00,'2018-06-25 01:04:20',7,3,1),
(8,'3_1',1,'CNY',10000.00,10000.00,'2018-06-25 01:15:55',8,3,1);

/*Table structure for table `basket_lineattribute` */

DROP TABLE IF EXISTS `basket_lineattribute`;

CREATE TABLE `basket_lineattribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) COLLATE utf8_bin NOT NULL,
  `line_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `basket_lineattribute_line_id_e7f4e05_fk_basket_line_id` (`line_id`),
  KEY `basket_lineattribute_28df3725` (`option_id`),
  CONSTRAINT `basket_lineattribute_line_id_e7f4e05_fk_basket_line_id` FOREIGN KEY (`line_id`) REFERENCES `basket_line` (`id`),
  CONSTRAINT `basket_lineattribute_option_id_9cbadce_fk_catalogue_option_id` FOREIGN KEY (`option_id`) REFERENCES `catalogue_option` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `basket_lineattribute` */

/*Table structure for table `catalogue_attributeoption` */

DROP TABLE IF EXISTS `catalogue_attributeoption`;

CREATE TABLE `catalogue_attributeoption` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option` varchar(255) COLLATE utf8_bin NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catalogue_attributeoption_group_id_60fbf9d0_uniq` (`group_id`,`option`),
  KEY `catalogue_attributeoption_0e939a4f` (`group_id`),
  CONSTRAINT `catalogue_group_id_4615ba9e_fk_catalogue_attributeoptiongroup_id` FOREIGN KEY (`group_id`) REFERENCES `catalogue_attributeoptiongroup` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `catalogue_attributeoption` */

/*Table structure for table `catalogue_attributeoptiongroup` */

DROP TABLE IF EXISTS `catalogue_attributeoptiongroup`;

CREATE TABLE `catalogue_attributeoptiongroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `catalogue_attributeoptiongroup` */

/*Table structure for table `catalogue_category` */

DROP TABLE IF EXISTS `catalogue_category`;

CREATE TABLE `catalogue_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(255) COLLATE utf8_bin NOT NULL,
  `depth` int(10) unsigned NOT NULL,
  `numchild` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` longtext COLLATE utf8_bin NOT NULL,
  `image` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `path` (`path`),
  KEY `catalogue_category_b068931c` (`name`),
  KEY `catalogue_category_2dbcba41` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `catalogue_category` */

insert  into `catalogue_category`(`id`,`path`,`depth`,`numchild`,`name`,`description`,`image`,`slug`) values 
(1,'0001',1,0,'特别推荐','<p>特别推荐 <span style=\"font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 12px; font-weight: bold;\">Description</span></p>','','specialOfferSuggestion');

/*Table structure for table `catalogue_option` */

DROP TABLE IF EXISTS `catalogue_option`;

CREATE TABLE `catalogue_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `code` varchar(128) COLLATE utf8_bin NOT NULL,
  `type` varchar(128) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `catalogue_option` */

/*Table structure for table `catalogue_product` */

DROP TABLE IF EXISTS `catalogue_product`;

CREATE TABLE `catalogue_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structure` varchar(10) COLLATE utf8_bin NOT NULL,
  `upc` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_bin NOT NULL,
  `slug` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` longtext COLLATE utf8_bin NOT NULL,
  `rating` double DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `is_discountable` tinyint(1) NOT NULL,
  `parent_id` int(11),
  `product_class_id` int(11),
  `flag_image_url` varchar(255) COLLATE utf8_bin NOT NULL,
  `short_description` varchar(255) COLLATE utf8_bin NOT NULL,
  `properties` longtext COLLATE utf8_bin NOT NULL,
  `published` tinyint(1) NOT NULL,
  `original_price` decimal(12,2),
  `primary_product_id` int(11),
  PRIMARY KEY (`id`),
  UNIQUE KEY `upc` (`upc`),
  KEY `catalogue_product_2dbcba41` (`slug`),
  KEY `catalogue_product_9474e4b5` (`date_updated`),
  KEY `catalogue_product_6be37982` (`parent_id`),
  KEY `catalogue_product_c6619e6f` (`product_class_id`),
  KEY `catalogue_product_00232096` (`primary_product_id`),
  CONSTRAINT `catalogue_pr_primary_product_id_6f81eb5d_fk_catalogue_product_id` FOREIGN KEY (`primary_product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `catalogue_product_class_id_4e393d81_fk_catalogue_productclass_id` FOREIGN KEY (`product_class_id`) REFERENCES `catalogue_productclass` (`id`),
  CONSTRAINT `catalogue_product_parent_id_4925af12_fk_catalogue_product_id` FOREIGN KEY (`parent_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `catalogue_product` */

insert  into `catalogue_product`(`id`,`structure`,`upc`,`title`,`slug`,`description`,`rating`,`date_created`,`date_updated`,`is_discountable`,`parent_id`,`product_class_id`,`flag_image_url`,`short_description`,`properties`,`published`,`original_price`,`primary_product_id`) values 
(3,'standalone','gitar','product_gitar1','product_gitar1','<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\">產品描述</label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\">產品描述</label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\">產品描述</label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\">產品描述</label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\">產品描述</label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\">產品描述</label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\">產品描述</label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\">產品描述</label></label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\">產品描述</label></label></label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\">產品描述</label></label></label></label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\">產品描述</label></label></label></label></label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\">產品描述</label></label></label></label></label></label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\">產品描述</label></label></label></label></label></label></label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold; font-size: 12px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_description\"> </label></label></label></label></label></label></label></label></label></label></label></label></label></p>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_21\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_21-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_23\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_23-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_24\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_24-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_25\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_21\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_21-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_23\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_23-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_24\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_24-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_25\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_21\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_21-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_23\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_23-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_24\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_24-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_25\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_21\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_21-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_23\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_23-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_24\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_24-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_25\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_21\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_21-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_23\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_23-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_24\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_24-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_25\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_21\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_21-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_23\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_23-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_24\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_24-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_25\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_21\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_21-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_23\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_23-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_24\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_24-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_25\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_21\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_21-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_23\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_23-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_24\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_24-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_25\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_21\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_21-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_23\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_23-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_24\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_24-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_25\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_21\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_21-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_23\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_23-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_24\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_24-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_25\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_21\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_21-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_23\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_23-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_24\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_24-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_25\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_21\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_21-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_23\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_23-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_24\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_24-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_25\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_21\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_21-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_22-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_23\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_23-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_24\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_24-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_25\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>',NULL,'2018-06-24 04:08:26','2018-06-24 04:09:44',1,NULL,1,'11','11','<h1 style=\"font-size: 18px; color: #666666; padding: 0px 6px 0px 0px; margin: 0px 0px 0.2em; font-family: \'Lucida Grande\', \'DejaVu Sans\', \'Bitstream Vera Sans\', Verdana, Arial, sans-serif;\"><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\">產品屬性，請使用以下格式</label></h1>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; color: #000000; font-size: 16px; font-weight: 400;\">\r\n<div id=\"mceu_6\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_6-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_8\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_8-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_9\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_9-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_10\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;\" for=\"id_properties\">產品屬性，請使用以下格式</label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\">產品屬性，請使用以下格式</label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\">產品屬性，請使用以下格式</label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\">產品屬性，請使用以下格式</label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\">產品屬性，請使用以下格式</label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\">產品屬性，請使用以下格式</label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\">產品屬性，請使用以下格式</label></label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\">產品屬性，請使用以下格式</label></label></label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\">產品屬性，請使用以下格式</label></label></label></label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\">產品屬性，請使用以下格式</label></label></label></label></label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\">產品屬性，請使用以下格式</label></label></label></label></label></label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\">產品屬性，請使用以下格式</label></label></label></label></label></label></label></label></label></label></label></label></label></p>\r\n<p><label class=\" control-label\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; display: inline-block; max-width: 100%; margin-bottom: 5px; font-size: 12px; color: #000000;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px; font-weight: bold;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"><label class=\" control-label\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 5px;\" for=\"id_properties\"> </label></label></label></label></label></label></label></label></label></label></label></label></label></p>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_6\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_6-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_8\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_8-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_9\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_9-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_10\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_6\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_6-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_8\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_8-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_9\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_9-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_10\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_6\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_6-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_8\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_8-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_9\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_9-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_10\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_6\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_6-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_8\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_8-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_9\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_9-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_10\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_6\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_6-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_8\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_8-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_9\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_9-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_10\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_6\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_6-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_8\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_8-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_9\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_9-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_10\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_6\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_6-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_8\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_8-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_9\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_9-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_10\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_6\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_6-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_8\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_8-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_9\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_9-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_10\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_6\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_6-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_8\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_8-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_9\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_9-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_10\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_6\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_6-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_8\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_8-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_9\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_9-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_10\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_6\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_6-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_8\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_8-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_9\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_9-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_10\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"\" style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; font-size: 16px;\">\r\n<div id=\"mceu_6\" class=\"mce-tinymce mce-container mce-panel\" style=\"box-sizing: content-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; margin: 0px; padding: 0px; border: 1px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: #595959; font-size: 14px; text-shadow: none; float: none; position: relative; width: 1349.75px; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; visibility: hidden; box-shadow: rgba(0, 0, 0, 0.2) 0px 1px 2px;\" tabindex=\"-1\" role=\"application\">\r\n<div id=\"mceu_6-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7\" class=\"mce-top-part mce-container mce-stack-layout-item mce-first\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: relative; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_7-body\" class=\"mce-container-body\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_8\" class=\"mce-toolbar-grp mce-container mce-panel mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px solid #c5c5c5; outline: 0px; vertical-align: top; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" tabindex=\"-1\" role=\"group\">\r\n<div id=\"mceu_8-body\" class=\"mce-container-body mce-stack-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_9\" class=\"mce-container mce-toolbar mce-stack-layout-item mce-first mce-last\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\" role=\"toolbar\">\r\n<div id=\"mceu_9-body\" class=\"mce-container-body mce-flow-layout\" style=\"box-sizing: content-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: normal; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none;\">\r\n<div id=\"mceu_10\" class=\"mce-container mce-flow-layout-item mce-first mce-btn-group\" style=\"box-sizing: content-box; margin: 0px; padding: 2px 0px; border: 0px; outline: 0px; vertical-align: top; background: transparent; text-shadow: none; float: none; position: static; width: auto; height: auto; white-space: nowrap; cursor: inherit; -webkit-tap-highlight-color: transparent; line-height: normal; direction: ltr; max-width: none; display: inline-block;\" role=\"group\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>',1,50000.00,NULL);

/*Table structure for table `catalogue_product_product_options` */

DROP TABLE IF EXISTS `catalogue_product_product_options`;

CREATE TABLE `catalogue_product_product_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`,`option_id`),
  KEY `catalogue_product_prod_option_id_45e1eda2_fk_catalogue_option_id` (`option_id`),
  CONSTRAINT `catalogue_product_pr_product_id_1abb306d_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `catalogue_product_prod_option_id_45e1eda2_fk_catalogue_option_id` FOREIGN KEY (`option_id`) REFERENCES `catalogue_option` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `catalogue_product_product_options` */

/*Table structure for table `catalogue_productattribute` */

DROP TABLE IF EXISTS `catalogue_productattribute`;

CREATE TABLE `catalogue_productattribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `code` varchar(128) COLLATE utf8_bin NOT NULL,
  `type` varchar(20) COLLATE utf8_bin NOT NULL,
  `required` tinyint(1) NOT NULL,
  `option_group_id` int(11) DEFAULT NULL,
  `product_class_id` int(11),
  PRIMARY KEY (`id`),
  KEY `cat_option_group_id_b312a16_fk_catalogue_attributeoptiongroup_id` (`option_group_id`),
  KEY `catalogue_productattribute_c1336794` (`code`),
  KEY `catalogue_productattribute_c6619e6f` (`product_class_id`),
  CONSTRAINT `cat_option_group_id_b312a16_fk_catalogue_attributeoptiongroup_id` FOREIGN KEY (`option_group_id`) REFERENCES `catalogue_attributeoptiongroup` (`id`),
  CONSTRAINT `catalogue_product_class_id_346b5bf0_fk_catalogue_productclass_id` FOREIGN KEY (`product_class_id`) REFERENCES `catalogue_productclass` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `catalogue_productattribute` */

insert  into `catalogue_productattribute`(`id`,`name`,`code`,`type`,`required`,`option_group_id`,`product_class_id`) values 
(1,'size','size','text',0,NULL,1),
(2,'BodyType','bodytype','text',0,NULL,1),
(3,'Type','type','text',0,NULL,1);

/*Table structure for table `catalogue_productattributevalue` */

DROP TABLE IF EXISTS `catalogue_productattributevalue`;

CREATE TABLE `catalogue_productattributevalue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value_text` longtext COLLATE utf8_bin,
  `value_integer` int(11) DEFAULT NULL,
  `value_boolean` tinyint(1) DEFAULT NULL,
  `value_float` double DEFAULT NULL,
  `value_richtext` longtext COLLATE utf8_bin,
  `value_date` date DEFAULT NULL,
  `value_file` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `value_image` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `entity_object_id` int(10) unsigned DEFAULT NULL,
  `attribute_id` int(11) NOT NULL,
  `entity_content_type_id` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `value_option_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catalogue_productattributevalue_attribute_id_42652928_uniq` (`attribute_id`,`product_id`),
  KEY `catalog_entity_content_type_id_d4399b4_fk_django_content_type_id` (`entity_content_type_id`),
  KEY `catalogue_productatt_product_id_5f32fefb_fk_catalogue_product_id` (`product_id`),
  KEY `catalog_value_option_id_49b694a4_fk_catalogue_attributeoption_id` (`value_option_id`),
  CONSTRAINT `catalog_entity_content_type_id_d4399b4_fk_django_content_type_id` FOREIGN KEY (`entity_content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `catalog_value_option_id_49b694a4_fk_catalogue_attributeoption_id` FOREIGN KEY (`value_option_id`) REFERENCES `catalogue_attributeoption` (`id`),
  CONSTRAINT `catalogue__attribute_id_eb6d798_fk_catalogue_productattribute_id` FOREIGN KEY (`attribute_id`) REFERENCES `catalogue_productattribute` (`id`),
  CONSTRAINT `catalogue_productatt_product_id_5f32fefb_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `catalogue_productattributevalue` */

insert  into `catalogue_productattributevalue`(`id`,`value_text`,`value_integer`,`value_boolean`,`value_float`,`value_richtext`,`value_date`,`value_file`,`value_image`,`entity_object_id`,`attribute_id`,`entity_content_type_id`,`product_id`,`value_option_id`) values 
(4,'BodyType1',NULL,NULL,NULL,NULL,NULL,'','',NULL,2,NULL,3,NULL),
(5,'size1',NULL,NULL,NULL,NULL,NULL,'','',NULL,1,NULL,3,NULL),
(6,'size2',NULL,NULL,NULL,NULL,NULL,'','',NULL,3,NULL,3,NULL);

/*Table structure for table `catalogue_productcategory` */

DROP TABLE IF EXISTS `catalogue_productcategory`;

CREATE TABLE `catalogue_productcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catalogue_productcategory_product_id_7ddeddfe_uniq` (`product_id`,`category_id`),
  KEY `catalogue_productc_category_id_1ea04730_fk_catalogue_category_id` (`category_id`),
  CONSTRAINT `catalogue_productc_category_id_1ea04730_fk_catalogue_category_id` FOREIGN KEY (`category_id`) REFERENCES `catalogue_category` (`id`),
  CONSTRAINT `catalogue_productcat_product_id_7e6154c6_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `catalogue_productcategory` */

insert  into `catalogue_productcategory`(`id`,`category_id`,`product_id`) values 
(2,1,3);

/*Table structure for table `catalogue_productclass` */

DROP TABLE IF EXISTS `catalogue_productclass`;

CREATE TABLE `catalogue_productclass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `slug` varchar(128) COLLATE utf8_bin NOT NULL,
  `requires_shipping` tinyint(1) NOT NULL,
  `track_stock` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `catalogue_productclass` */

insert  into `catalogue_productclass`(`id`,`name`,`slug`,`requires_shipping`,`track_stock`) values 
(1,'gitar','gitar',1,1);

/*Table structure for table `catalogue_productclass_options` */

DROP TABLE IF EXISTS `catalogue_productclass_options`;

CREATE TABLE `catalogue_productclass_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productclass_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `productclass_id` (`productclass_id`,`option_id`),
  KEY `catalogue_productclass_option_id_5a0e7ae1_fk_catalogue_option_id` (`option_id`),
  CONSTRAINT `catalogue__productclass_id_7010c9f3_fk_catalogue_productclass_id` FOREIGN KEY (`productclass_id`) REFERENCES `catalogue_productclass` (`id`),
  CONSTRAINT `catalogue_productclass_option_id_5a0e7ae1_fk_catalogue_option_id` FOREIGN KEY (`option_id`) REFERENCES `catalogue_option` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `catalogue_productclass_options` */

/*Table structure for table `catalogue_productimage` */

DROP TABLE IF EXISTS `catalogue_productimage`;

CREATE TABLE `catalogue_productimage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `original` varchar(255) COLLATE utf8_bin NOT NULL,
  `caption` varchar(200) COLLATE utf8_bin NOT NULL,
  `display_order` int(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catalogue_productimage_product_id_4d886d95_uniq` (`product_id`,`display_order`),
  CONSTRAINT `catalogue_productima_product_id_25e67bb0_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `catalogue_productimage` */

insert  into `catalogue_productimage`(`id`,`original`,`caption`,`display_order`,`date_created`,`product_id`) values 
(2,'images/products/2018/06/item-1.JPG','',0,'2018-06-24 04:09:27',3),
(3,'images/products/2018/06/item-2.JPG','',1,'2018-06-24 04:09:27',3);

/*Table structure for table `catalogue_productrecommendation` */

DROP TABLE IF EXISTS `catalogue_productrecommendation`;

CREATE TABLE `catalogue_productrecommendation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ranking` smallint(5) unsigned NOT NULL,
  `primary_id` int(11) NOT NULL,
  `recommendation_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catalogue_productrecommendation_primary_id_7a69631d_uniq` (`primary_id`,`recommendation_id`),
  KEY `catalogue_pro_recommendation_id_19a404e0_fk_catalogue_product_id` (`recommendation_id`),
  CONSTRAINT `catalogue_pro_recommendation_id_19a404e0_fk_catalogue_product_id` FOREIGN KEY (`recommendation_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `catalogue_productrec_primary_id_43553ffe_fk_catalogue_product_id` FOREIGN KEY (`primary_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `catalogue_productrecommendation` */

/*Table structure for table `customer_communicationeventtype` */

DROP TABLE IF EXISTS `customer_communicationeventtype`;

CREATE TABLE `customer_communicationeventtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(128) COLLATE utf8_bin NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `category` varchar(255) COLLATE utf8_bin NOT NULL,
  `email_subject_template` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `email_body_template` longtext COLLATE utf8_bin,
  `email_body_html_template` longtext COLLATE utf8_bin,
  `sms_template` varchar(170) COLLATE utf8_bin DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `customer_communicationeventtype` */

/*Table structure for table `customer_email` */

DROP TABLE IF EXISTS `customer_email`;

CREATE TABLE `customer_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` longtext COLLATE utf8_bin NOT NULL,
  `body_text` longtext COLLATE utf8_bin NOT NULL,
  `body_html` longtext COLLATE utf8_bin NOT NULL,
  `date_sent` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_email_user_id_1aa9371c_fk_authUser_user_id` (`user_id`),
  CONSTRAINT `customer_email_user_id_1aa9371c_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `customer_email` */

/*Table structure for table `customer_notification` */

DROP TABLE IF EXISTS `customer_notification`;

CREATE TABLE `customer_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) COLLATE utf8_bin NOT NULL,
  `body` longtext COLLATE utf8_bin NOT NULL,
  `category` varchar(255) COLLATE utf8_bin NOT NULL,
  `location` varchar(32) COLLATE utf8_bin NOT NULL,
  `date_sent` datetime NOT NULL,
  `date_read` datetime DEFAULT NULL,
  `recipient_id` int(11) NOT NULL,
  `sender_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_notification_recipient_id_eeda4bf_fk_authUser_user_id` (`recipient_id`),
  KEY `customer_notification_sender_id_16ed7258_fk_authUser_user_id` (`sender_id`),
  CONSTRAINT `customer_notification_recipient_id_eeda4bf_fk_authUser_user_id` FOREIGN KEY (`recipient_id`) REFERENCES `authuser_user` (`id`),
  CONSTRAINT `customer_notification_sender_id_16ed7258_fk_authUser_user_id` FOREIGN KEY (`sender_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `customer_notification` */

/*Table structure for table `customer_productalert` */

DROP TABLE IF EXISTS `customer_productalert`;

CREATE TABLE `customer_productalert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(75) COLLATE utf8_bin NOT NULL,
  `key` varchar(128) COLLATE utf8_bin NOT NULL,
  `status` varchar(20) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  `date_confirmed` datetime DEFAULT NULL,
  `date_cancelled` datetime DEFAULT NULL,
  `date_closed` datetime DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_productalert_product_id_1b70d57_fk_catalogue_product_id` (`product_id`),
  KEY `customer_productalert_user_id_637ecf4c_fk_authUser_user_id` (`user_id`),
  KEY `customer_productalert_0c83f57c` (`email`),
  KEY `customer_productalert_3c6e0b8a` (`key`),
  CONSTRAINT `customer_productalert_product_id_1b70d57_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `customer_productalert_user_id_637ecf4c_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `customer_productalert` */

/*Table structure for table `django_admin_log` */

DROP TABLE IF EXISTS `django_admin_log`;

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext COLLATE utf8_bin,
  `object_repr` varchar(200) COLLATE utf8_bin NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext COLLATE utf8_bin NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin__content_type_id_5151027a_fk_django_content_type_id` (`content_type_id`),
  KEY `django_admin_log_user_id_1c5f563_fk_authUser_user_id` (`user_id`),
  CONSTRAINT `django_admin__content_type_id_5151027a_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_1c5f563_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `django_admin_log` */

insert  into `django_admin_log`(`id`,`action_time`,`object_id`,`object_repr`,`action_flag`,`change_message`,`content_type_id`,`user_id`) values 
(1,'2018-06-24 03:18:45','1','IndexPageData object',1,'',10,1),
(2,'2018-06-24 03:19:23','1','IndexPageData object',2,'Changed banners.',10,1),
(3,'2018-06-24 03:44:17','HK','Hong Kong',1,'',20,1),
(4,'2018-06-24 03:44:44','1','Mr, 1, Hong Kong',1,'',19,1),
(5,'2018-06-24 03:47:18','1','gitar',1,'',25,1),
(6,'2018-06-24 03:47:51','1','size',1,'',29,1),
(7,'2018-06-24 03:48:27','2','BodyType',1,'',29,1),
(8,'2018-06-24 03:48:43','3','Type',1,'',29,1),
(9,'2018-06-24 03:49:27','1','特别推荐',1,'',26,1),
(10,'2018-06-24 03:49:35','1','古典吉他南波万!',1,'',24,1),
(11,'2018-06-24 03:51:05','1','Image of \'古典吉他南波万!\'',1,'',34,1),
(12,'2018-06-24 03:59:25','1','Open cart (owner: admin@chinagood.net, lines: 0)',2,'No fields changed.',41,1),
(13,'2018-06-24 04:07:27','1','partner1',1,'',37,1),
(14,'2018-06-24 04:13:28','1','Delivery City: Hong Kong',1,'',8,1),
(15,'2018-06-24 04:19:26','1','Open cart (owner: admin@chinagood.net, lines: 1)',3,'',41,1),
(16,'2018-06-24 04:24:55','1','Delivery City: Hong Kong',2,'Changed slug.',8,1),
(17,'2018-06-24 04:29:51','1','admin@chinagood.net',2,'No fields changed.',14,1),
(18,'2018-06-24 04:31:48','1','Mr, First line of address:, Hong Kong, Hong Kong',2,'Changed line1 and line4.',19,1),
(19,'2018-06-25 00:57:00','1','信用卡',1,'Added.',78,1),
(20,'2018-06-25 00:57:13','2','支付宝',1,'Added.',78,1),
(21,'2018-06-25 00:57:17','3','微信',1,'Added.',78,1),
(22,'2018-06-25 01:00:11','1','信用卡',3,'',78,1),
(23,'2018-06-25 01:00:11','3','微信',3,'',78,1),
(24,'2018-06-25 01:00:11','2','支付宝',3,'',78,1),
(25,'2018-06-25 01:00:31','1','信用卡',1,'Added.',46,1),
(26,'2018-06-25 01:00:36','2','支付宝',1,'Added.',46,1),
(27,'2018-06-25 01:00:39','3','微信',1,'Added.',46,1),
(28,'2018-06-25 01:22:22','4','信用卡支付',1,'Added.',46,1),
(29,'2018-06-25 01:22:27','5','货到付款',1,'Added.',46,1),
(30,'2018-06-25 01:22:33','6','支付宝',1,'Added.',46,1),
(31,'2018-06-25 01:22:37','7','微信支付',1,'Added.',46,1),
(32,'2018-06-25 01:26:55','4','支付宝',1,'Added.',78,1),
(33,'2018-06-25 01:27:04','5','微信支付',1,'Added.',78,1);

/*Table structure for table `django_content_type` */

DROP TABLE IF EXISTS `django_content_type`;

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) COLLATE utf8_bin NOT NULL,
  `model` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_3ec8c61c_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `django_content_type` */

insert  into `django_content_type`(`id`,`app_label`,`model`) values 
(8,'account','availablecity'),
(9,'account','availableshippingtime'),
(10,'account','indexpagedata'),
(13,'account','message'),
(11,'account','pickupinfo'),
(12,'account','verification'),
(20,'address','country'),
(19,'address','useraddress'),
(1,'admin','logentry'),
(15,'analytics','productrecord'),
(17,'analytics','userproductview'),
(16,'analytics','userrecord'),
(18,'analytics','usersearch'),
(3,'auth','group'),
(2,'auth','permission'),
(14,'authUser','user'),
(41,'basket','basket'),
(42,'basket','line'),
(43,'basket','lineattribute'),
(32,'catalogue','attributeoption'),
(31,'catalogue','attributeoptiongroup'),
(26,'catalogue','category'),
(33,'catalogue','option'),
(24,'catalogue','product'),
(29,'catalogue','productattribute'),
(30,'catalogue','productattributevalue'),
(27,'catalogue','productcategory'),
(25,'catalogue','productclass'),
(34,'catalogue','productimage'),
(28,'catalogue','productrecommendation'),
(4,'contenttypes','contenttype'),
(81,'customer','communicationeventtype'),
(80,'customer','email'),
(82,'customer','notification'),
(83,'customer','productalert'),
(7,'flatpages','flatpage'),
(60,'offer','absolutediscountbenefit'),
(49,'offer','benefit'),
(50,'offer','condition'),
(48,'offer','conditionaloffer'),
(56,'offer','countcondition'),
(55,'offer','coveragecondition'),
(64,'offer','fixedpricebenefit'),
(58,'offer','multibuydiscountbenefit'),
(63,'offer','percentagediscountbenefit'),
(51,'offer','range'),
(52,'offer','rangeproduct'),
(53,'offer','rangeproductfileupload'),
(62,'offer','shippingabsolutediscountbenefit'),
(61,'offer','shippingbenefit'),
(54,'offer','shippingfixedpricebenefit'),
(59,'offer','shippingpercentagediscountbenefit'),
(57,'offer','valuecondition'),
(71,'order','billingaddress'),
(69,'order','communicationevent'),
(72,'order','line'),
(74,'order','lineattribute'),
(73,'order','lineprice'),
(67,'order','order'),
(79,'order','orderdiscount'),
(68,'order','ordernote'),
(77,'order','paymentevent'),
(65,'order','paymenteventquantity'),
(78,'order','paymenteventtype'),
(70,'order','shippingaddress'),
(75,'order','shippingevent'),
(66,'order','shippingeventquantity'),
(76,'order','shippingeventtype'),
(100,'ott','ottorder'),
(101,'ott','ottrefund'),
(37,'partner','partner'),
(38,'partner','partneraddress'),
(40,'partner','stockalert'),
(39,'partner','stockrecord'),
(47,'payment','bankcard'),
(45,'payment','source'),
(46,'payment','sourcetype'),
(44,'payment','transaction'),
(92,'promotions','automaticproductlist'),
(90,'promotions','handpickedproductlist'),
(87,'promotions','image'),
(85,'promotions','keywordpromotion'),
(88,'promotions','multiimage'),
(91,'promotions','orderedproduct'),
(93,'promotions','orderedproductlist'),
(84,'promotions','pagepromotion'),
(86,'promotions','rawhtml'),
(89,'promotions','singleproduct'),
(94,'promotions','tabbedblock'),
(35,'reviews','productreview'),
(36,'reviews','vote'),
(5,'sessions','session'),
(21,'shipping','orderanditemcharges'),
(23,'shipping','weightband'),
(22,'shipping','weightbased'),
(6,'sites','site'),
(99,'thumbnail','kvstore'),
(95,'voucher','voucher'),
(96,'voucher','voucherapplication'),
(98,'wishlists','line'),
(97,'wishlists','wishlist');

/*Table structure for table `django_flatpage` */

DROP TABLE IF EXISTS `django_flatpage`;

CREATE TABLE `django_flatpage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(100) COLLATE utf8_bin NOT NULL,
  `title` varchar(200) COLLATE utf8_bin NOT NULL,
  `content` longtext COLLATE utf8_bin NOT NULL,
  `enable_comments` tinyint(1) NOT NULL,
  `template_name` varchar(70) COLLATE utf8_bin NOT NULL,
  `registration_required` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_flatpage_572d4e42` (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `django_flatpage` */

/*Table structure for table `django_flatpage_sites` */

DROP TABLE IF EXISTS `django_flatpage_sites`;

CREATE TABLE `django_flatpage_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flatpage_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `flatpage_id` (`flatpage_id`,`site_id`),
  KEY `django_flatpage_sites_site_id_3917af27_fk_django_site_id` (`site_id`),
  CONSTRAINT `django_flatpage_sites_flatpage_id_5c562ec6_fk_django_flatpage_id` FOREIGN KEY (`flatpage_id`) REFERENCES `django_flatpage` (`id`),
  CONSTRAINT `django_flatpage_sites_site_id_3917af27_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `django_flatpage_sites` */

/*Table structure for table `django_migrations` */

DROP TABLE IF EXISTS `django_migrations`;

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) COLLATE utf8_bin NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `django_migrations` */

insert  into `django_migrations`(`id`,`app`,`name`,`applied`) values 
(1,'contenttypes','0001_initial','2018-06-24 03:15:12'),
(2,'contenttypes','0002_remove_content_type_name','2018-06-24 03:15:12'),
(3,'auth','0001_initial','2018-06-24 03:15:12'),
(4,'auth','0002_alter_permission_name_max_length','2018-06-24 03:15:12'),
(5,'auth','0003_alter_user_email_max_length','2018-06-24 03:15:12'),
(6,'auth','0004_alter_user_username_opts','2018-06-24 03:15:12'),
(7,'auth','0005_alter_user_last_login_null','2018-06-24 03:15:12'),
(8,'auth','0006_require_contenttypes_0002','2018-06-24 03:15:12'),
(9,'authUser','0001_initial','2018-06-24 03:15:13'),
(10,'account','0001_initial','2018-06-24 03:15:13'),
(11,'account','0002_availablecity_slug','2018-06-24 03:15:13'),
(12,'account','0003_auto_20160508_0400','2018-06-24 03:15:13'),
(13,'account','0004_indexpagedata','2018-06-24 03:15:13'),
(14,'account','0005_pickupinfo','2018-06-24 03:15:13'),
(15,'account','0006_availablecity_shipping_fee','2018-06-24 03:15:13'),
(16,'account','0007_verification','2018-06-24 03:15:13'),
(17,'account','0008_message','2018-06-24 03:15:13'),
(18,'address','0001_initial','2018-06-24 03:15:14'),
(19,'admin','0001_initial','2018-06-24 03:15:14'),
(20,'catalogue','0001_initial','2018-06-24 03:15:16'),
(21,'analytics','0001_initial','2018-06-24 03:15:17'),
(22,'analytics','0002_auto_20140827_1705','2018-06-24 03:15:17'),
(23,'authUser','0002_user_points','2018-06-24 03:15:17'),
(24,'authUser','0003_user_inviter_id','2018-06-24 03:15:18'),
(25,'sites','0001_initial','2018-06-24 03:15:18'),
(26,'partner','0001_initial','2018-06-24 03:15:19'),
(27,'customer','0001_initial','2018-06-24 03:15:19'),
(28,'basket','0001_initial','2018-06-24 03:15:20'),
(29,'basket','0002_auto_20140827_1705','2018-06-24 03:15:21'),
(30,'order','0001_initial','2018-06-24 03:15:28'),
(31,'offer','0001_initial','2018-06-24 03:15:31'),
(32,'voucher','0001_initial','2018-06-24 03:15:32'),
(33,'basket','0003_basket_vouchers','2018-06-24 03:15:32'),
(34,'basket','0004_auto_20141007_2032','2018-06-24 03:15:32'),
(35,'basket','0005_auto_20150604_1450','2018-06-24 03:15:33'),
(36,'basket','0006_auto_20160111_1108','2018-06-24 03:15:33'),
(37,'catalogue','0002_auto_20150217_1221','2018-06-24 03:15:34'),
(38,'catalogue','0003_data_migration_slugs','2018-06-24 03:15:34'),
(39,'catalogue','0004_auto_20150217_1710','2018-06-24 03:15:34'),
(40,'catalogue','0005_auto_20150604_1450','2018-06-24 03:15:34'),
(41,'catalogue','0006_auto_20150807_1725','2018-06-24 03:15:34'),
(42,'catalogue','0007_auto_20151207_1440','2018-06-24 03:15:34'),
(43,'catalogue','0008_auto_20160304_1652','2018-06-24 03:15:35'),
(44,'catalogue','0009_auto_20160507_2110','2018-06-24 03:15:35'),
(45,'catalogue','0010_auto_20160507_2255','2018-06-24 03:15:36'),
(46,'catalogue','0011_product_properties','2018-06-24 03:15:36'),
(47,'catalogue','0012_product_published','2018-06-24 03:15:36'),
(48,'catalogue','0013_product_original_price','2018-06-24 03:15:37'),
(49,'catalogue','0014_product_primary_product','2018-06-24 03:15:37'),
(50,'customer','0002_auto_20150807_1725','2018-06-24 03:15:37'),
(51,'flatpages','0001_initial','2018-06-24 03:15:38'),
(52,'offer','0002_auto_20151210_1053','2018-06-24 03:15:38'),
(53,'order','0002_auto_20141007_2032','2018-06-24 03:15:38'),
(54,'order','0003_auto_20150113_1629','2018-06-24 03:15:38'),
(55,'order','0004_auto_20160111_1108','2018-06-24 03:15:39'),
(56,'order','0005_auto_20160511_0128','2018-06-24 03:15:39'),
(57,'order','0006_auto_20160716_1631','2018-06-24 03:15:40'),
(58,'order','0007_order_deliver_note','2018-06-24 03:15:40'),
(59,'order','0008_order_add_to_order','2018-06-24 03:15:40'),
(60,'order','0009_order_pickup_location','2018-06-24 03:15:41'),
(61,'partner','0002_auto_20141007_2032','2018-06-24 03:15:41'),
(62,'partner','0003_auto_20150604_1450','2018-06-24 03:15:42'),
(63,'partner','0004_auto_20160107_1755','2018-06-24 03:15:42'),
(64,'payment','0001_initial','2018-06-24 03:15:43'),
(65,'payment','0002_auto_20141007_2032','2018-06-24 03:15:43'),
(66,'promotions','0001_initial','2018-06-24 03:15:46'),
(67,'promotions','0002_auto_20150604_1450','2018-06-24 03:15:47'),
(68,'reviews','0001_initial','2018-06-24 03:15:48'),
(69,'sessions','0001_initial','2018-06-24 03:15:48'),
(70,'shipping','0001_initial','2018-06-24 03:15:49'),
(71,'shipping','0002_auto_20150604_1450','2018-06-24 03:15:50'),
(72,'wishlists','0001_initial','2018-06-24 03:15:52'),
(73,'wishlists','0002_auto_20160111_1108','2018-06-24 03:15:52'),
(74,'ott','0001_initial','2018-06-24 22:31:39');

/*Table structure for table `django_session` */

DROP TABLE IF EXISTS `django_session`;

CREATE TABLE `django_session` (
  `session_key` varchar(40) COLLATE utf8_bin NOT NULL,
  `session_data` longtext COLLATE utf8_bin NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `django_session` */

insert  into `django_session`(`session_key`,`session_data`,`expire_date`) values 
('5zdtxgzpf96k3ouvuhsvg7zno00qowl1','YjJjMWY2MGI1NmZhZmNhY2NjNTIwZjBjMDM2ZWY5Yjk5NTgxNjhhOTp7ImNoZWNrb3V0X2RhdGEiOnt9LCJfYXV0aF91c2VyX2hhc2giOiIxYzQ4MzY1MjI4ZTk0ODA5NWVlYjQ4MjhiY2YyYjA3M2IwN2YxNjRiIiwiX2F1dGhfdXNlcl9pZCI6IjEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJvc2Nhci5hcHBzLmN1c3RvbWVyLmF1dGhfYmFja2VuZHMuRW1haWxCYWNrZW5kIn0=','2018-07-08 04:52:07'),
('6ldhay1ys66au80u7n1qlcure5v43ip2','ZWViZDUxNGEzMzVjYzQxZTE1MzM4NzM0MTAyODM4NzQyZjgwODNhMjp7InBpY2t1cF9ub3RlIjoiIiwiX2F1dGhfdXNlcl9pZCI6IjEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJvc2Nhci5hcHBzLmN1c3RvbWVyLmF1dGhfYmFja2VuZHMuRW1haWxCYWNrZW5kIiwicGlja3VwX25hbWUiOiIiLCJwaWNrdXBfbG9jYXRpb24iOiJIb25nIEtvbmciLCJfYXV0aF91c2VyX2hhc2giOiIxYzQ4MzY1MjI4ZTk0ODA5NWVlYjQ4MjhiY2YyYjA3M2IwN2YxNjRiIiwicGlja3VwX3Bob25lIjoiIiwiY2hlY2tvdXRfZGF0YSI6eyJzaGlwcGluZyI6e319fQ==','2018-07-08 21:11:43'),
('dfkxtpu7gtnr2a43ejknvyyksjr1wviy','M2VlMWI2ZjI1MjhhY2RmZTJkYjFjODI3NWU3MmE5NGIzOWVkZGExMjp7InBpY2t1cF9ub3RlIjoiMSIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoib3NjYXIuYXBwcy5jdXN0b21lci5hdXRoX2JhY2tlbmRzLkVtYWlsQmFja2VuZCIsInBpY2t1cF9uYW1lIjoiMSIsInBheW1lbnRfdHlwZSI6IndlY2hhdCIsInBpY2t1cF9sb2NhdGlvbiI6IkhvbmcgS29uZyIsImNoZWNrb3V0X29yZGVyX2lkIjozLCJfYXV0aF91c2VyX2hhc2giOiIxYzQ4MzY1MjI4ZTk0ODA5NWVlYjQ4MjhiY2YyYjA3M2IwN2YxNjRiIiwicGlja3VwX3Bob25lIjoiMSIsImNoZWNrb3V0X2RhdGEiOnt9fQ==','2018-07-09 01:22:47'),
('kwl29zupf1jdifehykq91z43v9y0fk96','ZWViZDUxNGEzMzVjYzQxZTE1MzM4NzM0MTAyODM4NzQyZjgwODNhMjp7InBpY2t1cF9ub3RlIjoiIiwiX2F1dGhfdXNlcl9pZCI6IjEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJvc2Nhci5hcHBzLmN1c3RvbWVyLmF1dGhfYmFja2VuZHMuRW1haWxCYWNrZW5kIiwicGlja3VwX25hbWUiOiIiLCJwaWNrdXBfbG9jYXRpb24iOiJIb25nIEtvbmciLCJfYXV0aF91c2VyX2hhc2giOiIxYzQ4MzY1MjI4ZTk0ODA5NWVlYjQ4MjhiY2YyYjA3M2IwN2YxNjRiIiwicGlja3VwX3Bob25lIjoiIiwiY2hlY2tvdXRfZGF0YSI6eyJzaGlwcGluZyI6e319fQ==','2018-07-08 17:00:09'),
('x1eibxy8qfth6dbwxav9rbe8tjgl35iz','OTQ0MDA0NDJiNjYxYjMxNTUyN2E5ODYyN2EyMDk4YzA1NjEzM2NjNDp7ImRlbGl2ZXJfdGltZSI6IiIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoib3NjYXIuYXBwcy5jdXN0b21lci5hdXRoX2JhY2tlbmRzLkVtYWlsQmFja2VuZCIsImRlbGl2ZXJfbm90ZSI6IiIsIl9hdXRoX3VzZXJfaGFzaCI6IjFjNDgzNjUyMjhlOTQ4MDk1ZWViNDgyOGJjZjJiMDczYjA3ZjE2NGIiLCJjaGVja291dF9kYXRhIjp7fX0=','2018-07-08 06:58:52'),
('xtr2070g991by5bx6qjxm3dcu6igahc7','M2FhN2YwMDNlOGEwMTM4Y2I2Mjg2ODE4MzgxNGVjZjg5OWEyOTI1Mzp7Il9hdXRoX3VzZXJfaGFzaCI6IjFjNDgzNjUyMjhlOTQ4MDk1ZWViNDgyOGJjZjJiMDczYjA3ZjE2NGIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJvc2Nhci5hcHBzLmN1c3RvbWVyLmF1dGhfYmFja2VuZHMuRW1haWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjEifQ==','2018-07-08 03:18:21');

/*Table structure for table `django_site` */

DROP TABLE IF EXISTS `django_site`;

CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) COLLATE utf8_bin NOT NULL,
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `django_site` */

insert  into `django_site`(`id`,`domain`,`name`) values 
(2,'example.com','example.com');

/*Table structure for table `offer_benefit` */

DROP TABLE IF EXISTS `offer_benefit`;

CREATE TABLE `offer_benefit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(128) COLLATE utf8_bin NOT NULL,
  `value` decimal(12,2) DEFAULT NULL,
  `max_affected_items` int(10) unsigned DEFAULT NULL,
  `proxy_class` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `range_id` int(11),
  PRIMARY KEY (`id`),
  KEY `offer_benefit_ee6537b7` (`range_id`),
  CONSTRAINT `offer_benefit_range_id_62094d2d_fk_offer_range_id` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `offer_benefit` */

/*Table structure for table `offer_condition` */

DROP TABLE IF EXISTS `offer_condition`;

CREATE TABLE `offer_condition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(128) COLLATE utf8_bin NOT NULL,
  `value` decimal(12,2) DEFAULT NULL,
  `proxy_class` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `range_id` int(11),
  PRIMARY KEY (`id`),
  UNIQUE KEY `proxy_class` (`proxy_class`),
  KEY `offer_condition_ee6537b7` (`range_id`),
  CONSTRAINT `offer_condition_range_id_7a47188b_fk_offer_range_id` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `offer_condition` */

/*Table structure for table `offer_conditionaloffer` */

DROP TABLE IF EXISTS `offer_conditionaloffer`;

CREATE TABLE `offer_conditionaloffer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `slug` varchar(128) COLLATE utf8_bin NOT NULL,
  `description` longtext COLLATE utf8_bin NOT NULL,
  `offer_type` varchar(128) COLLATE utf8_bin NOT NULL,
  `status` varchar(64) COLLATE utf8_bin NOT NULL,
  `priority` int(11) NOT NULL,
  `start_datetime` datetime DEFAULT NULL,
  `end_datetime` datetime DEFAULT NULL,
  `max_global_applications` int(10) unsigned DEFAULT NULL,
  `max_user_applications` int(10) unsigned DEFAULT NULL,
  `max_basket_applications` int(10) unsigned DEFAULT NULL,
  `max_discount` decimal(12,2) DEFAULT NULL,
  `total_discount` decimal(12,2) NOT NULL,
  `num_applications` int(10) unsigned NOT NULL,
  `num_orders` int(10) unsigned NOT NULL,
  `redirect_url` varchar(200) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  `benefit_id` int(11) NOT NULL,
  `condition_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`),
  KEY `offer_conditionaloffer_benefit_id_195b8af3_fk_offer_benefit_id` (`benefit_id`),
  KEY `offer_conditionaloff_condition_id_1ffdbda5_fk_offer_condition_id` (`condition_id`),
  CONSTRAINT `offer_conditionaloff_condition_id_1ffdbda5_fk_offer_condition_id` FOREIGN KEY (`condition_id`) REFERENCES `offer_condition` (`id`),
  CONSTRAINT `offer_conditionaloffer_benefit_id_195b8af3_fk_offer_benefit_id` FOREIGN KEY (`benefit_id`) REFERENCES `offer_benefit` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `offer_conditionaloffer` */

/*Table structure for table `offer_range` */

DROP TABLE IF EXISTS `offer_range`;

CREATE TABLE `offer_range` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `slug` varchar(128) COLLATE utf8_bin NOT NULL,
  `description` longtext COLLATE utf8_bin NOT NULL,
  `is_public` tinyint(1) NOT NULL,
  `includes_all_products` tinyint(1) NOT NULL,
  `proxy_class` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`),
  UNIQUE KEY `proxy_class` (`proxy_class`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `offer_range` */

insert  into `offer_range`(`id`,`name`,`slug`,`description`,`is_public`,`includes_all_products`,`proxy_class`,`date_created`) values 
(1,'范围1','fan-wei-1','<h1 style=\"box-sizing: border-box; font-family: \'Open Sans\', Helvetica, Arial, sans-serif; margin: 0px 0px 10px; font-size: 30px; font-weight: normal; line-height: 1.1;\">范围</h1>',0,1,NULL,'2018-06-24 04:01:33');

/*Table structure for table `offer_range_classes` */

DROP TABLE IF EXISTS `offer_range_classes`;

CREATE TABLE `offer_range_classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range_id` int(11) NOT NULL,
  `productclass_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `range_id` (`range_id`,`productclass_id`),
  KEY `offer_rang_productclass_id_711eeec3_fk_catalogue_productclass_id` (`productclass_id`),
  CONSTRAINT `offer_rang_productclass_id_711eeec3_fk_catalogue_productclass_id` FOREIGN KEY (`productclass_id`) REFERENCES `catalogue_productclass` (`id`),
  CONSTRAINT `offer_range_classes_range_id_5dba3c7e_fk_offer_range_id` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `offer_range_classes` */

/*Table structure for table `offer_range_excluded_products` */

DROP TABLE IF EXISTS `offer_range_excluded_products`;

CREATE TABLE `offer_range_excluded_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `range_id` (`range_id`,`product_id`),
  KEY `offer_range_excluded__product_id_a81b141_fk_catalogue_product_id` (`product_id`),
  CONSTRAINT `offer_range_excluded__product_id_a81b141_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `offer_range_excluded_product_range_id_154aeb2b_fk_offer_range_id` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `offer_range_excluded_products` */

/*Table structure for table `offer_range_included_categories` */

DROP TABLE IF EXISTS `offer_range_included_categories`;

CREATE TABLE `offer_range_included_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `range_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `range_id` (`range_id`,`category_id`),
  KEY `offer_range_includ_category_id_37aba4cd_fk_catalogue_category_id` (`category_id`),
  CONSTRAINT `offer_range_includ_category_id_37aba4cd_fk_catalogue_category_id` FOREIGN KEY (`category_id`) REFERENCES `catalogue_category` (`id`),
  CONSTRAINT `offer_range_included_categor_range_id_262dc753_fk_offer_range_id` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `offer_range_included_categories` */

/*Table structure for table `offer_rangeproduct` */

DROP TABLE IF EXISTS `offer_rangeproduct`;

CREATE TABLE `offer_rangeproduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display_order` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `range_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `offer_rangeproduct_range_id_540d3d95_uniq` (`range_id`,`product_id`),
  KEY `offer_rangeproduct_product_id_6ee82a3d_fk_catalogue_product_id` (`product_id`),
  CONSTRAINT `offer_rangeproduct_product_id_6ee82a3d_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `offer_rangeproduct_range_id_904f621_fk_offer_range_id` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `offer_rangeproduct` */

/*Table structure for table `offer_rangeproductfileupload` */

DROP TABLE IF EXISTS `offer_rangeproductfileupload`;

CREATE TABLE `offer_rangeproductfileupload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filepath` varchar(255) COLLATE utf8_bin NOT NULL,
  `size` int(10) unsigned NOT NULL,
  `date_uploaded` datetime NOT NULL,
  `status` varchar(32) COLLATE utf8_bin NOT NULL,
  `error_message` varchar(255) COLLATE utf8_bin NOT NULL,
  `date_processed` datetime DEFAULT NULL,
  `num_new_skus` int(10) unsigned DEFAULT NULL,
  `num_unknown_skus` int(10) unsigned DEFAULT NULL,
  `num_duplicate_skus` int(10) unsigned DEFAULT NULL,
  `range_id` int(11) NOT NULL,
  `uploaded_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `offer_rangeproductfileupload_range_id_11133664_fk_offer_range_id` (`range_id`),
  KEY `offer_rangeproductfi_uploaded_by_id_1b3f0c59_fk_authUser_user_id` (`uploaded_by_id`),
  CONSTRAINT `offer_rangeproductfi_uploaded_by_id_1b3f0c59_fk_authUser_user_id` FOREIGN KEY (`uploaded_by_id`) REFERENCES `authuser_user` (`id`),
  CONSTRAINT `offer_rangeproductfileupload_range_id_11133664_fk_offer_range_id` FOREIGN KEY (`range_id`) REFERENCES `offer_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `offer_rangeproductfileupload` */

/*Table structure for table `order_billingaddress` */

DROP TABLE IF EXISTS `order_billingaddress`;

CREATE TABLE `order_billingaddress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) COLLATE utf8_bin NOT NULL,
  `first_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `last_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `line1` varchar(255) COLLATE utf8_bin NOT NULL,
  `line2` varchar(255) COLLATE utf8_bin NOT NULL,
  `line3` varchar(255) COLLATE utf8_bin NOT NULL,
  `line4` varchar(255) COLLATE utf8_bin NOT NULL,
  `state` varchar(255) COLLATE utf8_bin NOT NULL,
  `postcode` varchar(64) COLLATE utf8_bin NOT NULL,
  `search_text` longtext COLLATE utf8_bin NOT NULL,
  `country_id` varchar(2) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_billi_country_id_5677c2c1_fk_address_country_iso_3166_1_a2` (`country_id`),
  CONSTRAINT `order_billi_country_id_5677c2c1_fk_address_country_iso_3166_1_a2` FOREIGN KEY (`country_id`) REFERENCES `address_country` (`iso_3166_1_a2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_billingaddress` */

/*Table structure for table `order_communicationevent` */

DROP TABLE IF EXISTS `order_communicationevent`;

CREATE TABLE `order_communicationevent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created` datetime NOT NULL,
  `event_type_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ord_event_type_id_661cb614_fk_customer_communicationeventtype_id` (`event_type_id`),
  KEY `order_communicationevent_69dfcb07` (`order_id`),
  CONSTRAINT `ord_event_type_id_661cb614_fk_customer_communicationeventtype_id` FOREIGN KEY (`event_type_id`) REFERENCES `customer_communicationeventtype` (`id`),
  CONSTRAINT `order_communicationevent_order_id_3d455350_fk_order_order_id` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_communicationevent` */

/*Table structure for table `order_line` */

DROP TABLE IF EXISTS `order_line`;

CREATE TABLE `order_line` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `partner_name` varchar(128) COLLATE utf8_bin NOT NULL,
  `partner_sku` varchar(128) COLLATE utf8_bin NOT NULL,
  `partner_line_reference` varchar(128) COLLATE utf8_bin NOT NULL,
  `partner_line_notes` longtext COLLATE utf8_bin NOT NULL,
  `title` varchar(255) COLLATE utf8_bin NOT NULL,
  `upc` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `quantity` int(10) unsigned NOT NULL,
  `line_price_incl_tax` decimal(12,2) NOT NULL,
  `line_price_excl_tax` decimal(12,2) NOT NULL,
  `line_price_before_discounts_incl_tax` decimal(12,2) NOT NULL,
  `line_price_before_discounts_excl_tax` decimal(12,2) NOT NULL,
  `unit_cost_price` decimal(12,2) DEFAULT NULL,
  `unit_price_incl_tax` decimal(12,2) DEFAULT NULL,
  `unit_price_excl_tax` decimal(12,2) DEFAULT NULL,
  `unit_retail_price` decimal(12,2) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_bin NOT NULL,
  `est_dispatch_date` date DEFAULT NULL,
  `order_id` int(11) NOT NULL,
  `partner_id` int(11),
  `product_id` int(11),
  `stockrecord_id` int(11),
  PRIMARY KEY (`id`),
  KEY `order_line_69dfcb07` (`order_id`),
  KEY `order_line_4e98b6eb` (`partner_id`),
  KEY `order_line_9bea82de` (`product_id`),
  KEY `order_line_271c5733` (`stockrecord_id`),
  CONSTRAINT `order_line_order_id_54e4d3bc_fk_order_order_id` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`),
  CONSTRAINT `order_line_partner_id_236438_fk_partner_partner_id` FOREIGN KEY (`partner_id`) REFERENCES `partner_partner` (`id`),
  CONSTRAINT `order_line_product_id_8fdbe0d_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `order_line_stockrecord_id_2c3b3153_fk_partner_stockrecord_id` FOREIGN KEY (`stockrecord_id`) REFERENCES `partner_stockrecord` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_line` */

insert  into `order_line`(`id`,`partner_name`,`partner_sku`,`partner_line_reference`,`partner_line_notes`,`title`,`upc`,`quantity`,`line_price_incl_tax`,`line_price_excl_tax`,`line_price_before_discounts_incl_tax`,`line_price_before_discounts_excl_tax`,`unit_cost_price`,`unit_price_incl_tax`,`unit_price_excl_tax`,`unit_retail_price`,`status`,`est_dispatch_date`,`order_id`,`partner_id`,`product_id`,`stockrecord_id`) values 
(1,'partner1','pro1','','','product_gitar1','gitar',1,10000.00,10000.00,10000.00,10000.00,NULL,10000.00,10000.00,NULL,'等待處理',NULL,1,1,3,1),
(2,'partner1','pro1','','','product_gitar1','gitar',2,20000.00,20000.00,20000.00,20000.00,NULL,10000.00,10000.00,NULL,'等待處理',NULL,2,1,3,1),
(3,'partner1','pro1','','','product_gitar1','gitar',1,10000.00,10000.00,10000.00,10000.00,NULL,10000.00,10000.00,NULL,'等待處理',NULL,3,1,3,1);

/*Table structure for table `order_lineattribute` */

DROP TABLE IF EXISTS `order_lineattribute`;

CREATE TABLE `order_lineattribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(128) COLLATE utf8_bin NOT NULL,
  `value` varchar(255) COLLATE utf8_bin NOT NULL,
  `line_id` int(11) NOT NULL,
  `option_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_lineattribute_line_id_36789384_fk_order_line_id` (`line_id`),
  KEY `order_lineattribute_option_id_26a67b5b_fk_catalogue_option_id` (`option_id`),
  CONSTRAINT `order_lineattribute_line_id_36789384_fk_order_line_id` FOREIGN KEY (`line_id`) REFERENCES `order_line` (`id`),
  CONSTRAINT `order_lineattribute_option_id_26a67b5b_fk_catalogue_option_id` FOREIGN KEY (`option_id`) REFERENCES `catalogue_option` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_lineattribute` */

/*Table structure for table `order_lineprice` */

DROP TABLE IF EXISTS `order_lineprice`;

CREATE TABLE `order_lineprice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quantity` int(10) unsigned NOT NULL,
  `price_incl_tax` decimal(12,2) NOT NULL,
  `price_excl_tax` decimal(12,2) NOT NULL,
  `shipping_incl_tax` decimal(12,2) NOT NULL,
  `shipping_excl_tax` decimal(12,2) NOT NULL,
  `line_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_lineprice_line_id_2bd792af_fk_order_line_id` (`line_id`),
  KEY `order_lineprice_69dfcb07` (`order_id`),
  CONSTRAINT `order_lineprice_line_id_2bd792af_fk_order_line_id` FOREIGN KEY (`line_id`) REFERENCES `order_line` (`id`),
  CONSTRAINT `order_lineprice_order_id_3877d7c_fk_order_order_id` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_lineprice` */

insert  into `order_lineprice`(`id`,`quantity`,`price_incl_tax`,`price_excl_tax`,`shipping_incl_tax`,`shipping_excl_tax`,`line_id`,`order_id`) values 
(1,1,10000.00,10000.00,0.00,0.00,1,1),
(2,2,10000.00,10000.00,0.00,0.00,2,2),
(3,1,10000.00,10000.00,0.00,0.00,3,3);

/*Table structure for table `order_order` */

DROP TABLE IF EXISTS `order_order`;

CREATE TABLE `order_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(128) COLLATE utf8_bin NOT NULL,
  `currency` varchar(12) COLLATE utf8_bin NOT NULL,
  `total_incl_tax` decimal(12,2) NOT NULL,
  `total_excl_tax` decimal(12,2) NOT NULL,
  `shipping_incl_tax` decimal(12,2) NOT NULL,
  `shipping_excl_tax` decimal(12,2) NOT NULL,
  `shipping_method` varchar(128) COLLATE utf8_bin NOT NULL,
  `shipping_code` varchar(128) COLLATE utf8_bin NOT NULL,
  `status` varchar(100) COLLATE utf8_bin NOT NULL,
  `guest_email` varchar(75) COLLATE utf8_bin NOT NULL,
  `date_placed` datetime NOT NULL,
  `basket_id` int(11) DEFAULT NULL,
  `billing_address_id` int(11) DEFAULT NULL,
  `shipping_address_id` int(11),
  `site_id` int(11),
  `user_id` int(11),
  `deliver_date` datetime,
  `deliver_time` varchar(255) COLLATE utf8_bin,
  `pickup_name` varchar(255) COLLATE utf8_bin,
  `pickup_note` longtext COLLATE utf8_bin,
  `pickup_phone` varchar(255) COLLATE utf8_bin,
  `deliver_note` varchar(1024) COLLATE utf8_bin,
  `add_to_order_id` int(11),
  `pickup_location` longtext COLLATE utf8_bin,
  PRIMARY KEY (`id`),
  UNIQUE KEY `number` (`number`),
  KEY `order_order_basket_id_2fd34c64_fk_basket_basket_id` (`basket_id`),
  KEY `order_ord_billing_address_id_2bf53d01_fk_order_billingaddress_id` (`billing_address_id`),
  KEY `order_order_90e84921` (`date_placed`),
  KEY `order_order_8fb9ffec` (`shipping_address_id`),
  KEY `order_order_9365d6e7` (`site_id`),
  KEY `order_order_e8701ad4` (`user_id`),
  KEY `order_order_3086d265` (`add_to_order_id`),
  CONSTRAINT `order_o_shipping_address_id_63113a4d_fk_order_shippingaddress_id` FOREIGN KEY (`shipping_address_id`) REFERENCES `order_shippingaddress` (`id`),
  CONSTRAINT `order_ord_billing_address_id_2bf53d01_fk_order_billingaddress_id` FOREIGN KEY (`billing_address_id`) REFERENCES `order_billingaddress` (`id`),
  CONSTRAINT `order_order_add_to_order_id_2f1402b2_fk_order_order_id` FOREIGN KEY (`add_to_order_id`) REFERENCES `order_order` (`id`),
  CONSTRAINT `order_order_basket_id_2fd34c64_fk_basket_basket_id` FOREIGN KEY (`basket_id`) REFERENCES `basket_basket` (`id`),
  CONSTRAINT `order_order_site_id_68cddff7_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`),
  CONSTRAINT `order_order_user_id_3b4b7f2f_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_order` */

insert  into `order_order`(`id`,`number`,`currency`,`total_incl_tax`,`total_excl_tax`,`shipping_incl_tax`,`shipping_excl_tax`,`shipping_method`,`shipping_code`,`status`,`guest_email`,`date_placed`,`basket_id`,`billing_address_id`,`shipping_address_id`,`site_id`,`user_id`,`deliver_date`,`deliver_time`,`pickup_name`,`pickup_note`,`pickup_phone`,`deliver_note`,`add_to_order_id`,`pickup_location`) values 
(1,'100006','CNY',10000.00,10000.00,0.00,0.00,'到店自取','getByYourSelf','等待處理','','2018-06-25 01:01:59',6,NULL,NULL,2,1,NULL,NULL,'1','1','1',NULL,NULL,'Hong Kong'),
(2,'100007','CNY',20000.00,20000.00,0.00,0.00,'到店自取','getByYourSelf','等待處理','','2018-06-25 01:05:34',7,NULL,NULL,2,1,NULL,NULL,'1112131','123123','123123',NULL,NULL,'Hong Kong'),
(3,'100008','CNY',10000.00,10000.00,0.00,0.00,'到店自取','getByYourSelf','等待處理','','2018-06-25 01:22:47',8,NULL,NULL,2,1,NULL,NULL,'1','1','1',NULL,NULL,'Hong Kong');

/*Table structure for table `order_orderdiscount` */

DROP TABLE IF EXISTS `order_orderdiscount`;

CREATE TABLE `order_orderdiscount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(64) COLLATE utf8_bin NOT NULL,
  `offer_id` int(10) unsigned DEFAULT NULL,
  `offer_name` varchar(128) COLLATE utf8_bin NOT NULL,
  `voucher_id` int(10) unsigned DEFAULT NULL,
  `voucher_code` varchar(128) COLLATE utf8_bin NOT NULL,
  `frequency` int(10) unsigned DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `message` longtext COLLATE utf8_bin NOT NULL,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_orderdiscount_order_id_364cd680_fk_order_order_id` (`order_id`),
  KEY `order_orderdiscount_9eeed246` (`offer_name`),
  KEY `order_orderdiscount_08e4f7cd` (`voucher_code`),
  CONSTRAINT `order_orderdiscount_order_id_364cd680_fk_order_order_id` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_orderdiscount` */

/*Table structure for table `order_ordernote` */

DROP TABLE IF EXISTS `order_ordernote`;

CREATE TABLE `order_ordernote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `note_type` varchar(128) COLLATE utf8_bin NOT NULL,
  `message` longtext COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_ordernote_order_id_18771857_fk_order_order_id` (`order_id`),
  KEY `order_ordernote_user_id_7459bb83_fk_authUser_user_id` (`user_id`),
  CONSTRAINT `order_ordernote_order_id_18771857_fk_order_order_id` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`),
  CONSTRAINT `order_ordernote_user_id_7459bb83_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_ordernote` */

/*Table structure for table `order_paymentevent` */

DROP TABLE IF EXISTS `order_paymentevent`;

CREATE TABLE `order_paymentevent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(12,2) NOT NULL,
  `reference` varchar(128) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  `event_type_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `shipping_event_id` int(11),
  PRIMARY KEY (`id`),
  KEY `order_paymentevent_5e891baf` (`event_type_id`),
  KEY `order_paymentevent_69dfcb07` (`order_id`),
  KEY `order_paymentevent_78cafb71` (`shipping_event_id`),
  CONSTRAINT `order_payme_shipping_event_id_4c55ca00_fk_order_shippingevent_id` FOREIGN KEY (`shipping_event_id`) REFERENCES `order_shippingevent` (`id`),
  CONSTRAINT `order_paymen_event_type_id_1e297d0c_fk_order_paymenteventtype_id` FOREIGN KEY (`event_type_id`) REFERENCES `order_paymenteventtype` (`id`),
  CONSTRAINT `order_paymentevent_order_id_5f81dbe8_fk_order_order_id` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_paymentevent` */

/*Table structure for table `order_paymenteventquantity` */

DROP TABLE IF EXISTS `order_paymenteventquantity`;

CREATE TABLE `order_paymenteventquantity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quantity` int(10) unsigned NOT NULL,
  `event_id` int(11) NOT NULL,
  `line_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_paymenteventquantity_event_id_30ef1d57_uniq` (`event_id`,`line_id`),
  KEY `order_paymenteventquantity_line_id_31e00d64_fk_order_line_id` (`line_id`),
  CONSTRAINT `order_paymenteventqua_event_id_24d461f7_fk_order_paymentevent_id` FOREIGN KEY (`event_id`) REFERENCES `order_paymentevent` (`id`),
  CONSTRAINT `order_paymenteventquantity_line_id_31e00d64_fk_order_line_id` FOREIGN KEY (`line_id`) REFERENCES `order_line` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_paymenteventquantity` */

/*Table structure for table `order_paymenteventtype` */

DROP TABLE IF EXISTS `order_paymenteventtype`;

CREATE TABLE `order_paymenteventtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `code` varchar(128) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_paymenteventtype` */

insert  into `order_paymenteventtype`(`id`,`name`,`code`) values 
(4,'支付宝','zhi-fu-bao'),
(5,'微信支付','wei-xin-zhi-fu');

/*Table structure for table `order_shippingaddress` */

DROP TABLE IF EXISTS `order_shippingaddress`;

CREATE TABLE `order_shippingaddress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) COLLATE utf8_bin NOT NULL,
  `first_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `last_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `line1` varchar(255) COLLATE utf8_bin NOT NULL,
  `line2` varchar(255) COLLATE utf8_bin NOT NULL,
  `line3` varchar(255) COLLATE utf8_bin NOT NULL,
  `line4` varchar(255) COLLATE utf8_bin NOT NULL,
  `state` varchar(255) COLLATE utf8_bin NOT NULL,
  `postcode` varchar(64) COLLATE utf8_bin NOT NULL,
  `search_text` longtext COLLATE utf8_bin NOT NULL,
  `phone_number` varchar(128) COLLATE utf8_bin NOT NULL,
  `notes` longtext COLLATE utf8_bin NOT NULL,
  `country_id` varchar(2) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_shipp_country_id_282d4fcf_fk_address_country_iso_3166_1_a2` (`country_id`),
  CONSTRAINT `order_shipp_country_id_282d4fcf_fk_address_country_iso_3166_1_a2` FOREIGN KEY (`country_id`) REFERENCES `address_country` (`iso_3166_1_a2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_shippingaddress` */

/*Table structure for table `order_shippingevent` */

DROP TABLE IF EXISTS `order_shippingevent`;

CREATE TABLE `order_shippingevent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notes` longtext COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  `event_type_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_shippingevent_5e891baf` (`event_type_id`),
  KEY `order_shippingevent_69dfcb07` (`order_id`),
  CONSTRAINT `order_shippi_event_type_id_69b8ebf_fk_order_shippingeventtype_id` FOREIGN KEY (`event_type_id`) REFERENCES `order_shippingeventtype` (`id`),
  CONSTRAINT `order_shippingevent_order_id_41faff1d_fk_order_order_id` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_shippingevent` */

/*Table structure for table `order_shippingeventquantity` */

DROP TABLE IF EXISTS `order_shippingeventquantity`;

CREATE TABLE `order_shippingeventquantity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quantity` int(10) unsigned NOT NULL,
  `event_id` int(11) NOT NULL,
  `line_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_shippingeventquantity_event_id_671b075e_uniq` (`event_id`,`line_id`),
  KEY `order_shippingeventquantity_line_id_5f54109_fk_order_line_id` (`line_id`),
  CONSTRAINT `order_shippingeventq_event_id_70caea64_fk_order_shippingevent_id` FOREIGN KEY (`event_id`) REFERENCES `order_shippingevent` (`id`),
  CONSTRAINT `order_shippingeventquantity_line_id_5f54109_fk_order_line_id` FOREIGN KEY (`line_id`) REFERENCES `order_line` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_shippingeventquantity` */

/*Table structure for table `order_shippingeventtype` */

DROP TABLE IF EXISTS `order_shippingeventtype`;

CREATE TABLE `order_shippingeventtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `code` varchar(128) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `order_shippingeventtype` */

/*Table structure for table `ott_ottorder` */

DROP TABLE IF EXISTS `ott_ottorder`;

CREATE TABLE `ott_ottorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(256) COLLATE utf8_bin NOT NULL,
  `out_trade_no` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `product_code` varchar(64) COLLATE utf8_bin NOT NULL,
  `total_amount` varchar(64) COLLATE utf8_bin NOT NULL,
  `body` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `trade_no` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `busname` varchar(16) COLLATE utf8_bin DEFAULT NULL,
  `time_end` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `biz_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `apitype` varchar(64) COLLATE utf8_bin NOT NULL,
  `code_url` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `ott_ottorder` */

insert  into `ott_ottorder`(`id`,`subject`,`out_trade_no`,`product_code`,`total_amount`,`body`,`trade_no`,`busname`,`time_end`,`status`,`create_time`,`update_time`,`biz_type`,`apitype`,`code_url`) values 
(1,'test','21232','QUICK_MSECURITY_PAY','1',NULL,NULL,NULL,NULL,0,'2018-06-25 00:22:14','2018-06-25 00:22:14','ALIPAY','ACTIVEPAY','code_url'),
(2,'test','21232','QUICK_MSECURITY_PAY','1',NULL,NULL,NULL,NULL,0,'2018-06-25 00:28:28','2018-06-25 00:28:28','ALIPAY','ACTIVEPAY','code_url'),
(3,'test','ttt21232','QUICK_MSECURITY_PAY','1',NULL,NULL,NULL,NULL,0,'2018-06-25 00:29:17','2018-06-25 00:29:17','ALIPAY','ACTIVEPAY','code_url'),
(4,'GITAR','wechat_100007','QUICK_MSECURITY_PAY','20000',NULL,NULL,NULL,NULL,0,'2018-06-25 01:14:19','2018-06-25 01:14:19','WECHATPAY','ACTIVEPAY','code_url'),
(5,'GITAR','alipay_100007','QUICK_MSECURITY_PAY','20000',NULL,NULL,NULL,NULL,0,'2018-06-25 01:14:28','2018-06-25 01:14:28','ALIPAY','ACTIVEPAY','code_url'),
(6,'GITAR','wechat_100008','QUICK_MSECURITY_PAY','10000',NULL,NULL,NULL,NULL,0,'2018-06-25 01:22:55','2018-06-25 01:22:55','WECHATPAY','ACTIVEPAY','code_url'),
(7,'GITAR','alipay_100008','QUICK_MSECURITY_PAY','10000',NULL,NULL,NULL,NULL,0,'2018-06-25 01:23:02','2018-06-25 01:23:02','ALIPAY','ACTIVEPAY','code_url');

/*Table structure for table `ott_ottrefund` */

DROP TABLE IF EXISTS `ott_ottrefund`;

CREATE TABLE `ott_ottrefund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(64) COLLATE utf8_bin NOT NULL,
  `refund_amt` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `ott_ottrefund` */

/*Table structure for table `partner_partner` */

DROP TABLE IF EXISTS `partner_partner`;

CREATE TABLE `partner_partner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(128) COLLATE utf8_bin NOT NULL,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `partner_partner` */

insert  into `partner_partner`(`id`,`code`,`name`) values 
(1,'partner1','partner1');

/*Table structure for table `partner_partner_users` */

DROP TABLE IF EXISTS `partner_partner_users`;

CREATE TABLE `partner_partner_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `partner_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `partner_id` (`partner_id`,`user_id`),
  KEY `partner_partner_users_user_id_741d5a52_fk_authUser_user_id` (`user_id`),
  CONSTRAINT `partner_partner_users_partner_id_392680b6_fk_partner_partner_id` FOREIGN KEY (`partner_id`) REFERENCES `partner_partner` (`id`),
  CONSTRAINT `partner_partner_users_user_id_741d5a52_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `partner_partner_users` */

/*Table structure for table `partner_partneraddress` */

DROP TABLE IF EXISTS `partner_partneraddress`;

CREATE TABLE `partner_partneraddress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) COLLATE utf8_bin NOT NULL,
  `first_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `last_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `line1` varchar(255) COLLATE utf8_bin NOT NULL,
  `line2` varchar(255) COLLATE utf8_bin NOT NULL,
  `line3` varchar(255) COLLATE utf8_bin NOT NULL,
  `line4` varchar(255) COLLATE utf8_bin NOT NULL,
  `state` varchar(255) COLLATE utf8_bin NOT NULL,
  `postcode` varchar(64) COLLATE utf8_bin NOT NULL,
  `search_text` longtext COLLATE utf8_bin NOT NULL,
  `country_id` varchar(2) COLLATE utf8_bin NOT NULL,
  `partner_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `partner_par_country_id_338f14c2_fk_address_country_iso_3166_1_a2` (`country_id`),
  KEY `partner_partneraddress_partner_id_35ed76ae_fk_partner_partner_id` (`partner_id`),
  CONSTRAINT `partner_par_country_id_338f14c2_fk_address_country_iso_3166_1_a2` FOREIGN KEY (`country_id`) REFERENCES `address_country` (`iso_3166_1_a2`),
  CONSTRAINT `partner_partneraddress_partner_id_35ed76ae_fk_partner_partner_id` FOREIGN KEY (`partner_id`) REFERENCES `partner_partner` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `partner_partneraddress` */

/*Table structure for table `partner_stockalert` */

DROP TABLE IF EXISTS `partner_stockalert`;

CREATE TABLE `partner_stockalert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `threshold` int(10) unsigned NOT NULL,
  `status` varchar(128) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  `date_closed` datetime DEFAULT NULL,
  `stockrecord_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `partner_stockalert_271c5733` (`stockrecord_id`),
  CONSTRAINT `partner_stockal_stockrecord_id_d4e8adb_fk_partner_stockrecord_id` FOREIGN KEY (`stockrecord_id`) REFERENCES `partner_stockrecord` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `partner_stockalert` */

/*Table structure for table `partner_stockrecord` */

DROP TABLE IF EXISTS `partner_stockrecord`;

CREATE TABLE `partner_stockrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `partner_sku` varchar(128) COLLATE utf8_bin NOT NULL,
  `price_currency` varchar(12) COLLATE utf8_bin NOT NULL,
  `price_excl_tax` decimal(12,2) DEFAULT NULL,
  `price_retail` decimal(12,2) DEFAULT NULL,
  `cost_price` decimal(12,2) DEFAULT NULL,
  `num_in_stock` int(10) unsigned DEFAULT NULL,
  `num_allocated` int(11) DEFAULT NULL,
  `low_stock_threshold` int(10) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `partner_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `partner_stockrecord_partner_id_ce15682_uniq` (`partner_id`,`partner_sku`),
  KEY `partner_stockrecord_product_id_62757f5_fk_catalogue_product_id` (`product_id`),
  KEY `partner_stockrecord_9474e4b5` (`date_updated`),
  CONSTRAINT `partner_stockrecord_partner_id_484097aa_fk_partner_partner_id` FOREIGN KEY (`partner_id`) REFERENCES `partner_partner` (`id`),
  CONSTRAINT `partner_stockrecord_product_id_62757f5_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `partner_stockrecord` */

insert  into `partner_stockrecord`(`id`,`partner_sku`,`price_currency`,`price_excl_tax`,`price_retail`,`cost_price`,`num_in_stock`,`num_allocated`,`low_stock_threshold`,`date_created`,`date_updated`,`partner_id`,`product_id`) values 
(1,'pro1','CNY',10000.00,NULL,NULL,10000,4,NULL,'2018-06-24 04:09:06','2018-06-25 01:22:47',1,3);

/*Table structure for table `payment_bankcard` */

DROP TABLE IF EXISTS `payment_bankcard`;

CREATE TABLE `payment_bankcard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_type` varchar(128) COLLATE utf8_bin NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `number` varchar(32) COLLATE utf8_bin NOT NULL,
  `expiry_date` date NOT NULL,
  `partner_reference` varchar(255) COLLATE utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_bankcard_user_id_33509bfa_fk_authUser_user_id` (`user_id`),
  CONSTRAINT `payment_bankcard_user_id_33509bfa_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `payment_bankcard` */

/*Table structure for table `payment_source` */

DROP TABLE IF EXISTS `payment_source`;

CREATE TABLE `payment_source` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currency` varchar(12) COLLATE utf8_bin NOT NULL,
  `amount_allocated` decimal(12,2) NOT NULL,
  `amount_debited` decimal(12,2) NOT NULL,
  `amount_refunded` decimal(12,2) NOT NULL,
  `reference` varchar(128) COLLATE utf8_bin NOT NULL,
  `label` varchar(128) COLLATE utf8_bin NOT NULL,
  `order_id` int(11) NOT NULL,
  `source_type_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_source_order_id_52550a9f_fk_order_order_id` (`order_id`),
  KEY `payment_source_ed5cb66b` (`source_type_id`),
  CONSTRAINT `payment_source_order_id_52550a9f_fk_order_order_id` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`),
  CONSTRAINT `payment_source_source_type_id_701a48d_fk_payment_sourcetype_id` FOREIGN KEY (`source_type_id`) REFERENCES `payment_sourcetype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `payment_source` */

insert  into `payment_source`(`id`,`currency`,`amount_allocated`,`amount_debited`,`amount_refunded`,`reference`,`label`,`order_id`,`source_type_id`) values 
(3,'CNY',0.00,10000.00,0.00,'','',3,7);

/*Table structure for table `payment_sourcetype` */

DROP TABLE IF EXISTS `payment_sourcetype`;

CREATE TABLE `payment_sourcetype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `code` varchar(128) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `payment_sourcetype` */

insert  into `payment_sourcetype`(`id`,`name`,`code`) values 
(4,'信用卡支付','xin-yong-qia-zhi-fu'),
(5,'货到付款','huo-dao-fu-kuan'),
(6,'支付宝','zhi-fu-bao'),
(7,'微信支付','wei-xin-zhi-fu');

/*Table structure for table `payment_transaction` */

DROP TABLE IF EXISTS `payment_transaction`;

CREATE TABLE `payment_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `txn_type` varchar(128) COLLATE utf8_bin NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `reference` varchar(128) COLLATE utf8_bin NOT NULL,
  `status` varchar(128) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  `source_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_transaction_source_id_72114bb9_fk_payment_source_id` (`source_id`),
  CONSTRAINT `payment_transaction_source_id_72114bb9_fk_payment_source_id` FOREIGN KEY (`source_id`) REFERENCES `payment_source` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `payment_transaction` */

/*Table structure for table `promotions_automaticproductlist` */

DROP TABLE IF EXISTS `promotions_automaticproductlist`;

CREATE TABLE `promotions_automaticproductlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` longtext COLLATE utf8_bin NOT NULL,
  `link_url` varchar(200) COLLATE utf8_bin NOT NULL,
  `link_text` varchar(255) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  `method` varchar(128) COLLATE utf8_bin NOT NULL,
  `num_products` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `promotions_automaticproductlist` */

/*Table structure for table `promotions_handpickedproductlist` */

DROP TABLE IF EXISTS `promotions_handpickedproductlist`;

CREATE TABLE `promotions_handpickedproductlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` longtext COLLATE utf8_bin NOT NULL,
  `link_url` varchar(200) COLLATE utf8_bin NOT NULL,
  `link_text` varchar(255) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `promotions_handpickedproductlist` */

/*Table structure for table `promotions_image` */

DROP TABLE IF EXISTS `promotions_image`;

CREATE TABLE `promotions_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `link_url` varchar(200) COLLATE utf8_bin NOT NULL,
  `image` varchar(255) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `promotions_image` */

/*Table structure for table `promotions_keywordpromotion` */

DROP TABLE IF EXISTS `promotions_keywordpromotion`;

CREATE TABLE `promotions_keywordpromotion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(10) unsigned NOT NULL,
  `position` varchar(100) COLLATE utf8_bin NOT NULL,
  `display_order` int(10) unsigned NOT NULL,
  `clicks` int(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `keyword` varchar(200) COLLATE utf8_bin NOT NULL,
  `filter` varchar(200) COLLATE utf8_bin NOT NULL,
  `content_type_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `promotions_ke_content_type_id_17f7f542_fk_django_content_type_id` (`content_type_id`),
  CONSTRAINT `promotions_ke_content_type_id_17f7f542_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `promotions_keywordpromotion` */

/*Table structure for table `promotions_multiimage` */

DROP TABLE IF EXISTS `promotions_multiimage`;

CREATE TABLE `promotions_multiimage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `promotions_multiimage` */

/*Table structure for table `promotions_multiimage_images` */

DROP TABLE IF EXISTS `promotions_multiimage_images`;

CREATE TABLE `promotions_multiimage_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `multiimage_id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `multiimage_id` (`multiimage_id`,`image_id`),
  KEY `promotions_multiimage_im_image_id_8b2f050_fk_promotions_image_id` (`image_id`),
  CONSTRAINT `promotions_mu_multiimage_id_478f73ce_fk_promotions_multiimage_id` FOREIGN KEY (`multiimage_id`) REFERENCES `promotions_multiimage` (`id`),
  CONSTRAINT `promotions_multiimage_im_image_id_8b2f050_fk_promotions_image_id` FOREIGN KEY (`image_id`) REFERENCES `promotions_image` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `promotions_multiimage_images` */

/*Table structure for table `promotions_orderedproduct` */

DROP TABLE IF EXISTS `promotions_orderedproduct`;

CREATE TABLE `promotions_orderedproduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display_order` int(10) unsigned NOT NULL,
  `list_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `promotions_orderedproduct_list_id_38e849e0_uniq` (`list_id`,`product_id`),
  KEY `promotions_orderedproduct_4da3e820` (`list_id`),
  KEY `promotions_orderedproduct_9bea82de` (`product_id`),
  CONSTRAINT `promotio_list_id_58ce046a_fk_promotions_handpickedproductlist_id` FOREIGN KEY (`list_id`) REFERENCES `promotions_handpickedproductlist` (`id`),
  CONSTRAINT `promotions_orderedpr_product_id_3088b4cc_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `promotions_orderedproduct` */

/*Table structure for table `promotions_orderedproductlist` */

DROP TABLE IF EXISTS `promotions_orderedproductlist`;

CREATE TABLE `promotions_orderedproductlist` (
  `handpickedproductlist_ptr_id` int(11) NOT NULL,
  `display_order` int(10) unsigned NOT NULL,
  `tabbed_block_id` int(11) NOT NULL,
  PRIMARY KEY (`handpickedproductlist_ptr_id`),
  KEY `promotions_orderedproductlist_1f46f425` (`tabbed_block_id`),
  CONSTRAINT `D1cad5413fb1fb78a065957da6ac7b0c` FOREIGN KEY (`handpickedproductlist_ptr_id`) REFERENCES `promotions_handpickedproductlist` (`id`),
  CONSTRAINT `promotions_tabbed_block_id_3ca7677a_fk_promotions_tabbedblock_id` FOREIGN KEY (`tabbed_block_id`) REFERENCES `promotions_tabbedblock` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `promotions_orderedproductlist` */

/*Table structure for table `promotions_pagepromotion` */

DROP TABLE IF EXISTS `promotions_pagepromotion`;

CREATE TABLE `promotions_pagepromotion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(10) unsigned NOT NULL,
  `position` varchar(100) COLLATE utf8_bin NOT NULL,
  `display_order` int(10) unsigned NOT NULL,
  `clicks` int(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `page_url` varchar(128) COLLATE utf8_bin NOT NULL,
  `content_type_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `promotions_pa_content_type_id_2c509351_fk_django_content_type_id` (`content_type_id`),
  KEY `promotions_pagepromotion_072c6e88` (`page_url`),
  CONSTRAINT `promotions_pa_content_type_id_2c509351_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `promotions_pagepromotion` */

/*Table structure for table `promotions_rawhtml` */

DROP TABLE IF EXISTS `promotions_rawhtml`;

CREATE TABLE `promotions_rawhtml` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `display_type` varchar(128) COLLATE utf8_bin NOT NULL,
  `body` longtext COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `promotions_rawhtml` */

/*Table structure for table `promotions_singleproduct` */

DROP TABLE IF EXISTS `promotions_singleproduct`;

CREATE TABLE `promotions_singleproduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `description` longtext COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `promotions_singlepro_product_id_41987a2a_fk_catalogue_product_id` (`product_id`),
  CONSTRAINT `promotions_singlepro_product_id_41987a2a_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `promotions_singleproduct` */

/*Table structure for table `promotions_tabbedblock` */

DROP TABLE IF EXISTS `promotions_tabbedblock`;

CREATE TABLE `promotions_tabbedblock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `promotions_tabbedblock` */

/*Table structure for table `reviews_productreview` */

DROP TABLE IF EXISTS `reviews_productreview`;

CREATE TABLE `reviews_productreview` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `score` smallint(6) NOT NULL,
  `title` varchar(255) COLLATE utf8_bin NOT NULL,
  `body` longtext COLLATE utf8_bin NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(75) COLLATE utf8_bin NOT NULL,
  `homepage` varchar(200) COLLATE utf8_bin NOT NULL,
  `status` smallint(6) NOT NULL,
  `total_votes` int(11) NOT NULL,
  `delta_votes` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reviews_productreview_product_id_7f68dc33_uniq` (`product_id`,`user_id`),
  KEY `reviews_productreview_user_id_232e1877_fk_authUser_user_id` (`user_id`),
  KEY `reviews_productreview_979acfd1` (`delta_votes`),
  CONSTRAINT `reviews_productreview_product_id_f9d099a_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `reviews_productreview_user_id_232e1877_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `reviews_productreview` */

/*Table structure for table `reviews_vote` */

DROP TABLE IF EXISTS `reviews_vote`;

CREATE TABLE `reviews_vote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delta` smallint(6) NOT NULL,
  `date_created` datetime NOT NULL,
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reviews_vote_user_id_3178559b_uniq` (`user_id`,`review_id`),
  KEY `reviews_vote_review_id_42064f7e_fk_reviews_productreview_id` (`review_id`),
  CONSTRAINT `reviews_vote_review_id_42064f7e_fk_reviews_productreview_id` FOREIGN KEY (`review_id`) REFERENCES `reviews_productreview` (`id`),
  CONSTRAINT `reviews_vote_user_id_4046a805_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `reviews_vote` */

/*Table structure for table `shipping_orderanditemcharges` */

DROP TABLE IF EXISTS `shipping_orderanditemcharges`;

CREATE TABLE `shipping_orderanditemcharges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(128) COLLATE utf8_bin NOT NULL,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `description` longtext COLLATE utf8_bin NOT NULL,
  `price_per_order` decimal(12,2) NOT NULL,
  `price_per_item` decimal(12,2) NOT NULL,
  `free_shipping_threshold` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `shipping_orderanditemcharges` */

/*Table structure for table `shipping_orderanditemcharges_countries` */

DROP TABLE IF EXISTS `shipping_orderanditemcharges_countries`;

CREATE TABLE `shipping_orderanditemcharges_countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderanditemcharges_id` int(11) NOT NULL,
  `country_id` varchar(2) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderanditemcharges_id` (`orderanditemcharges_id`,`country_id`),
  KEY `shipping_or_country_id_16333ddc_fk_address_country_iso_3166_1_a2` (`country_id`),
  CONSTRAINT `b7bee63d04bf404b8834129b8f568365` FOREIGN KEY (`orderanditemcharges_id`) REFERENCES `shipping_orderanditemcharges` (`id`),
  CONSTRAINT `shipping_or_country_id_16333ddc_fk_address_country_iso_3166_1_a2` FOREIGN KEY (`country_id`) REFERENCES `address_country` (`iso_3166_1_a2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `shipping_orderanditemcharges_countries` */

/*Table structure for table `shipping_weightband` */

DROP TABLE IF EXISTS `shipping_weightband`;

CREATE TABLE `shipping_weightband` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `upper_limit` decimal(12,3) NOT NULL,
  `charge` decimal(12,2) NOT NULL,
  `method_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shipping_weightband_836f12fb` (`method_id`),
  CONSTRAINT `shipping_weightban_method_id_2a731ac8_fk_shipping_weightbased_id` FOREIGN KEY (`method_id`) REFERENCES `shipping_weightbased` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `shipping_weightband` */

/*Table structure for table `shipping_weightbased` */

DROP TABLE IF EXISTS `shipping_weightbased`;

CREATE TABLE `shipping_weightbased` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(128) COLLATE utf8_bin NOT NULL,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `description` longtext COLLATE utf8_bin NOT NULL,
  `default_weight` decimal(12,3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `shipping_weightbased` */

/*Table structure for table `shipping_weightbased_countries` */

DROP TABLE IF EXISTS `shipping_weightbased_countries`;

CREATE TABLE `shipping_weightbased_countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weightbased_id` int(11) NOT NULL,
  `country_id` varchar(2) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `weightbased_id` (`weightbased_id`,`country_id`),
  KEY `shipping_we_country_id_5da153c8_fk_address_country_iso_3166_1_a2` (`country_id`),
  CONSTRAINT `shipping_we_country_id_5da153c8_fk_address_country_iso_3166_1_a2` FOREIGN KEY (`country_id`) REFERENCES `address_country` (`iso_3166_1_a2`),
  CONSTRAINT `shipping_weigh_weightbased_id_bc293ab_fk_shipping_weightbased_id` FOREIGN KEY (`weightbased_id`) REFERENCES `shipping_weightbased` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `shipping_weightbased_countries` */

/*Table structure for table `thumbnail_kvstore` */

DROP TABLE IF EXISTS `thumbnail_kvstore`;

CREATE TABLE `thumbnail_kvstore` (
  `key` varchar(200) COLLATE utf8_bin NOT NULL,
  `value` longtext COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `thumbnail_kvstore` */

insert  into `thumbnail_kvstore`(`key`,`value`) values 
('sorl-thumbnail||image||06917cb6a7378915f8c7a90427660b37','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/fc/4b/fc4b7293314e47e036524cac6c8423cb.jpg\", \"size\": [683, 1024]}'),
('sorl-thumbnail||image||11c54f9de1c54ca28694a99e32ba9994','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/73/7d/737d225d74087030f1bedefcd715f982.jpg\", \"size\": [1024, 512]}'),
('sorl-thumbnail||image||11f5b627cf300d0c41d2b60adc85282b','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/7e/cc/7ecc565bd20d50773239818d131a0df4.jpg\", \"size\": [200, 100]}'),
('sorl-thumbnail||image||5d5f27d6b25ae0e2ac8cd97e9fb95277','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/00/de/00de30afc93baf91a49d5d23a8ec7037.jpg\", \"size\": [67, 100]}'),
('sorl-thumbnail||image||811ebd4822da5189d0407d39a8107b98','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/d1/ab/d1abd89df1914400be4a8ceff9661849.jpg\", \"size\": [430, 215]}'),
('sorl-thumbnail||image||8e5e4252634e853210cb7287b1f24790','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/df/e4/dfe4f9f65eaab1bbf2ffcae1316a81c0.jpg\", \"size\": [133, 200]}'),
('sorl-thumbnail||image||94b0df7b69888b20a10031e79de79973','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"images/products/2018/06/item-2.JPG\", \"size\": [1920, 960]}'),
('sorl-thumbnail||image||a80e21d197feae7e82a5cb0ae5bb3815','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/05/d5/05d5ecd42ad56ff6506cb8b012b423bd.jpg\", \"size\": [287, 430]}'),
('sorl-thumbnail||image||ad144ef64ce1b1433ab95a4752bb7fc0','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"images/products/2018/06/item-1.JPG\", \"size\": [1280, 1920]}'),
('sorl-thumbnail||image||f29a40bef92b493f25656dd1d074f957','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/1f/aa/1faa3ba5f394ce629a80c8d767080c5f.jpg\", \"size\": [87, 130]}'),
('sorl-thumbnail||image||f8e9b5f63db38fc927711ab377f8cad6','{\"storage\": \"django.core.files.storage.FileSystemStorage\", \"name\": \"cache/52/74/5274ab41d1073226ca454fb369363b1f.jpg\", \"size\": [267, 400]}'),
('sorl-thumbnail||thumbnails||94b0df7b69888b20a10031e79de79973','[\"11f5b627cf300d0c41d2b60adc85282b\"]'),
('sorl-thumbnail||thumbnails||ad144ef64ce1b1433ab95a4752bb7fc0','[\"8e5e4252634e853210cb7287b1f24790\"]');

/*Table structure for table `voucher_voucher` */

DROP TABLE IF EXISTS `voucher_voucher`;

CREATE TABLE `voucher_voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_bin NOT NULL,
  `code` varchar(128) COLLATE utf8_bin NOT NULL,
  `usage` varchar(128) COLLATE utf8_bin NOT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `num_basket_additions` int(10) unsigned NOT NULL,
  `num_orders` int(10) unsigned NOT NULL,
  `total_discount` decimal(12,2) NOT NULL,
  `date_created` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `voucher_voucher` */

/*Table structure for table `voucher_voucher_offers` */

DROP TABLE IF EXISTS `voucher_voucher_offers`;

CREATE TABLE `voucher_voucher_offers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_id` int(11) NOT NULL,
  `conditionaloffer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `voucher_id` (`voucher_id`,`conditionaloffer_id`),
  KEY `vouche_conditionaloffer_id_234f6931_fk_offer_conditionaloffer_id` (`conditionaloffer_id`),
  CONSTRAINT `vouche_conditionaloffer_id_234f6931_fk_offer_conditionaloffer_id` FOREIGN KEY (`conditionaloffer_id`) REFERENCES `offer_conditionaloffer` (`id`),
  CONSTRAINT `voucher_voucher_offers_voucher_id_4a38e6d4_fk_voucher_voucher_id` FOREIGN KEY (`voucher_id`) REFERENCES `voucher_voucher` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `voucher_voucher_offers` */

/*Table structure for table `voucher_voucherapplication` */

DROP TABLE IF EXISTS `voucher_voucherapplication`;

CREATE TABLE `voucher_voucherapplication` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created` date NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `voucher_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `voucher_voucherapplication_order_id_5f8e76d0_fk_order_order_id` (`order_id`),
  KEY `voucher_voucherapplication_user_id_12c6555c_fk_authUser_user_id` (`user_id`),
  KEY `voucher_voucherapplicat_voucher_id_fd56660_fk_voucher_voucher_id` (`voucher_id`),
  CONSTRAINT `voucher_voucherapplicat_voucher_id_fd56660_fk_voucher_voucher_id` FOREIGN KEY (`voucher_id`) REFERENCES `voucher_voucher` (`id`),
  CONSTRAINT `voucher_voucherapplication_order_id_5f8e76d0_fk_order_order_id` FOREIGN KEY (`order_id`) REFERENCES `order_order` (`id`),
  CONSTRAINT `voucher_voucherapplication_user_id_12c6555c_fk_authUser_user_id` FOREIGN KEY (`user_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `voucher_voucherapplication` */

/*Table structure for table `wishlists_line` */

DROP TABLE IF EXISTS `wishlists_line`;

CREATE TABLE `wishlists_line` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quantity` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_bin NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `wishlist_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wishlists_line_wishlist_id_453dfacc_uniq` (`wishlist_id`,`product_id`),
  KEY `wishlists_line_product_id_3a0a47d_fk_catalogue_product_id` (`product_id`),
  KEY `wishlists_line_e2f8e270` (`wishlist_id`),
  CONSTRAINT `wishlists_line_product_id_3a0a47d_fk_catalogue_product_id` FOREIGN KEY (`product_id`) REFERENCES `catalogue_product` (`id`),
  CONSTRAINT `wishlists_line_wishlist_id_1e137c90_fk_wishlists_wishlist_id` FOREIGN KEY (`wishlist_id`) REFERENCES `wishlists_wishlist` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `wishlists_line` */

/*Table structure for table `wishlists_wishlist` */

DROP TABLE IF EXISTS `wishlists_wishlist`;

CREATE TABLE `wishlists_wishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `key` varchar(6) COLLATE utf8_bin NOT NULL,
  `visibility` varchar(20) COLLATE utf8_bin NOT NULL,
  `date_created` datetime NOT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`),
  KEY `wishlists_wishlist_owner_id_75490f56_fk_authUser_user_id` (`owner_id`),
  CONSTRAINT `wishlists_wishlist_owner_id_75490f56_fk_authUser_user_id` FOREIGN KEY (`owner_id`) REFERENCES `authuser_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `wishlists_wishlist` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

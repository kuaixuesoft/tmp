#coding=utf-8
from base64 import b64decode
from base64 import b64encode
from Crypto.Cipher import AES
import base64
import json
import requests

# PKCS5Padding
BLOCK_SIZE = 16  # Bytes

# Padding for the input string --not
# related to encryption itself.
pad = lambda s: s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * \
                chr(BLOCK_SIZE - len(s) % BLOCK_SIZE)
unpad = lambda s: s[:-ord(s[len(s) - 1:])]

class AESCipher:
    """
    Tested under Python 3.x and PyCrypto 2.6.1.
    """

    def __init__(self, key):
        #加密需要的key值
        self.key=key.encode('utf-8')
    def encrypt(self, raw):
        raw = pad(raw)
        cipher = AES.new(self.key, AES.MODE_ECB)
        return base64.b64encode(cipher.encrypt(raw.encode('utf8'))).decode('utf8')

    def decrypt(self, enc):
        enc = b64decode(enc)
        cipher = AES.new(self.key, AES.MODE_ECB)
        return unpad(cipher.decrypt(enc)).decode('utf8')

if __name__ == '__main__':
    test_data ='{"amount":"1","biz_type":"WECHATPAY","order_id":"ACT1529443511537","call_back_url":"http://www.kiwinano.info"}'

    #key length:16, AES 128
    key = '3FE5F59A8E13D962'

    test_data = AESCipher(key).encrypt(test_data)
    print(test_data)

    decrypted_text = AESCipher(key).decrypt(test_data)
    print('--------------------decrypt---------------------')
    print(decrypted_text)
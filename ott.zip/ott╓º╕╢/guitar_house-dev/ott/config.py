MERCHANTID = 'BC00003477'
MERCHANTKEY = '20B86D02DAB7CFFD'

CALL_BACK_URL = 'http://www.example.com:8000/ott/notify/'
INTERNAL_CALL_BACK_URL = 'http://www.example.com:8000/checkout/paymentnotification/'
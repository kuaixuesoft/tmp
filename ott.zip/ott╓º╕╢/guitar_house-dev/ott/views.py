#!/usr/bin/env python
# -*- coding: utf8 -*-
from django.utils import timezone
from datetime import datetime

from rest_framework.generics import GenericAPIView
from rest_framework.response import Response
from rest_framework import permissions

import json
#from urllib.parse import quote_plus

from .utils import signByMD5,sortStringByMap
from .aes import AESCipher

#from .config import NOTIFY_URL, RETURN_URL, APP_ID, RSA_PRIVATE, ALIPAY_PUBLIC_KEY, PAY_URL
from .config import MERCHANTID, MERCHANTKEY, CALL_BACK_URL, INTERNAL_CALL_BACK_URL

from .models import OTTOrder, OTTRefund
from .serializers import OrderSerializer, RefundSerializer
import requests

from django.views.decorators.csrf import csrf_exempt

# ott pay request, get qr link
class PayView(GenericAPIView):
    serializer_class = OrderSerializer
    permission_classes = (permissions.IsAuthenticated,)

    @csrf_exempt
    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        user = self.request.user
        instance = OTTOrder.objects.create(**request.data)
        #instance.out_trade_no = timezone.now().strftime('%Y%m%d') +'{}'.format(instance.id)
        instance.save()

        #import 2 parameter
        amount = serializer.validated_data.get('total_amount')
        order_id = serializer.validated_data.get('out_trade_no')
        biz_type = serializer.validated_data.get('biz_type')
        apitype = serializer.validated_data.get('apitype')

        #type = 'ACTIVEPAY'
        #biz_type = 'WECHATPAY'
        #biz_type = 'ALIPAY'

        bo = {}
        bo['order_id'] = order_id
        bo['call_back_url'] = CALL_BACK_URL
        bo['biz_type'] = biz_type
        bo['amount'] = amount

        md5 = signByMD5(sortStringByMap(bo))
        AESKEY = signByMD5(md5+MERCHANTKEY.upper())[8:-8]

        #aes and base64
        jsonstr = json.dumps(bo)
        encrypted = AESCipher(AESKEY).encrypt(jsonstr)

        vo = dict()
        vo['action'] = apitype
        vo['version'] = "1.0"
        vo['merchant_id'] = MERCHANTID
        vo['data'] = encrypted
        vo['md5'] = md5

        print(vo)

        #post
        #json
        #headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        headers = {'Content-type': 'application/json', 'Accept': 'application/json'}
        r = requests.post('https://frontapi.ottpay.com:443/process', json=vo, headers=headers, verify=False)

        print(r.text)
        print(r)

        #-- ott -- response scheme
        #rsp_code
        #rsp_msg
        #data:code_url
        #data:order_id
        #md5

        #if return success, decrypt it
        json_content = json.loads(r.text)
        if r.status_code == 200:
            jsonstr = json_content['data']
            #print(jsonstr)

            md5 = json_content['md5']
            AESKEY = signByMD5(md5+MERCHANTKEY.upper())[8:-8]
            decrypted = AESCipher(AESKEY).decrypt(jsonstr)

            #print(decrypted)
            json_content['data'] = json.loads(decrypted)

            #save code_url in order table
            if 'code_url' in json_content.keys():
                instance.code_url = json_content['code_url']
                instance.save()

            print(json_content)

        response = Response(json_content)
        response.status_code = r.status_code
        return response

# ottcall back
class PayNotifyView(GenericAPIView):

    def post(self, request, *args, **kwargs):
        data = request.data
        # print(jsonstr)

        headers = {'Content-type': 'application/json', 'Accept': 'application/json'}

        #payment confirm page in oscar
        r = requests.post(INTERNAL_CALL_BACK_URL, json=data, headers=headers, verify=False)

        #is oscar receive call back, reponse 200 to ott
        if r.status_code==200:
            #response success to ott
            return Response('success')# 有效数据需要返回 'success'

# ott refund api
class RefundView(GenericAPIView):
    serializer_class = RefundSerializer
    permission_classes = (permissions.AllowAny,)

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        #instance = OTTOrder.objects.create(**request.data)
        #instance.out_trade_no = timezone.now().strftime('%Y%m%d') +'{}'.format(instance.id)
        #instance.save()

        #import 2 parameter
        #order_id = serializer.validated_data.get('out_trade_no')
        #refund_amt = serializer.validated_data.get('total_amount')
        order_id = request.data['out_trade_no']
        refund_amt = request.data['total_amount']
        apitype = 'REFUND'

        #-- ott -- request scheme
        #action
        #version
        #merchant_id
        #data:order_id - orderid of return
        #data:ori_order_id
        #data:refund_amt
        #md5

        bo = {}
        bo['order_id'] = 'return_'+order_id
        bo['ori_order_id'] = order_id
        bo['refund_amt'] = refund_amt

        md5 = signByMD5(sortStringByMap(bo))
        AESKEY = signByMD5(md5+MERCHANTKEY.upper())[8:-8]

        #aes and base64
        jsonstr = json.dumps(bo)
        encrypted = AESCipher(AESKEY).encrypt(jsonstr)

        vo = dict()
        vo['action'] = apitype
        vo['version'] = "1.0"
        vo['merchant_id'] = MERCHANTID
        vo['data'] = encrypted
        vo['md5'] = md5
        print(vo)

        #post
        #json
        #headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        headers = {'Content-type': 'application/json', 'Accept': 'application/json'}
        r = requests.post('https://frontapi.ottpay.com:443/process', json=vo, headers=headers, verify=False)
        print(r.text)
        print(r)

        #-- ott -- response scheme
        #rsp_code
        #rsp_msg
        #data:order_status
        #data:trade_time
        #data:order_id
        #data:refund_amt
        #md5

        #if return success, decrypt it
        json_content = json.loads(r.text)
        if r.status_code == 200:
            jsonstr = json_content['data']
            #print(jsonstr)

            md5 = json_content['md5']
            AESKEY = signByMD5(md5+MERCHANTKEY.upper())[8:-8]
            decrypted = AESCipher(AESKEY).decrypt(jsonstr)

            #print(decrypted)
            json_content['data'] = json.loads(decrypted)
            print(json_content)

        response = Response(json_content)
        response.status_code = r.status_code
        return response

# ott Query transaction
class QueryTransactionView(GenericAPIView):
    serializer_class = RefundSerializer
    permission_classes = (permissions.AllowAny,)

    def post(self, request):
        #serializer = self.get_serializer(data=request.data)
        #serializer.is_valid(raise_exception=True)

        #instance = OTTOrder.objects.create(**request.data)
        #instance.out_trade_no = timezone.now().strftime('%Y%m%d') +'{}'.format(instance.id)
        #instance.save()

        #import 2 parameter
        #order_id = serializer.validated_data.get('out_trade_no')
        order_id = request.data['out_trade_no']
        apitype = 'STATUS_QUERY'

        #action
        #version
        #merchant_id
        #data:order_id
        #md5

        bo = {}
        bo['ori_order_id'] = order_id

        md5 = signByMD5(sortStringByMap(bo))
        AESKEY = signByMD5(md5+MERCHANTKEY.upper())[8:-8]

        #aes and base64
        jsonstr = json.dumps(bo)
        encrypted = AESCipher(AESKEY).encrypt(jsonstr)

        vo = dict()
        vo['action'] = apitype
        vo['version'] = "1.0"
        vo['merchant_id'] = MERCHANTID
        vo['data'] = encrypted
        vo['md5'] = md5
        print(vo)

        #post
        #json
        #headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        headers = {'Content-type': 'application/json', 'Accept': 'application/json'}
        r = requests.post('https://frontapi.ottpay.com:443/process', json=vo, headers=headers, verify=False)
        print(r.text)
        print(r)

        #-- ott -- response scheme
        #rsp_code
        #rsp_msg
        #data:order_status
        #data:trade_time
        #data:order_id
        #data:buyer_login_id
        #data:total_amount
        #data:receive_amount
        #data:pay_amount
        #data:refund_fee
        #md5

        #if return success, decrypt it
        json_content = json.loads(r.text)
        if r.status_code == 200:
            jsonstr = json_content['data']
            #print(jsonstr)

            md5 = json_content['md5']
            AESKEY = signByMD5(md5+MERCHANTKEY.upper())[8:-8]
            decrypted = AESCipher(AESKEY).decrypt(jsonstr)

            #print(decrypted)
            json_content['data'] = json.loads(decrypted)
            print(json_content)

        response = Response(json_content)
        response.status_code = r.status_code
        return response

# ott Query refund
class QueryRefundView(GenericAPIView):
    serializer_class = RefundSerializer
    permission_classes = (permissions.AllowAny,)

    def post(self, request):
        #serializer = self.get_serializer(data=request.data)
        #serializer.is_valid(raise_exception=True)

        #instance = OTTOrder.objects.create(**request.data)
        #instance.out_trade_no = timezone.now().strftime('%Y%m%d') +'{}'.format(instance.id)
        #instance.save()

        #import 2 parameter
        #order_id = serializer.validated_data.get('out_trade_no')
        order_id = request.data['out_trade_no']
        apitype = 'REFUND_STATUS_QUERY'

        #action
        #version
        #merchant_id
        #data:order_id
        #md5

        bo = {}
        bo['ori_order_id'] = order_id

        md5 = signByMD5(sortStringByMap(bo))
        AESKEY = signByMD5(md5+MERCHANTKEY.upper())[8:-8]

        #aes and base64
        jsonstr = json.dumps(bo)
        encrypted = AESCipher(AESKEY).encrypt(jsonstr)

        vo = dict()
        vo['action'] = apitype
        vo['version'] = "1.0"
        vo['merchant_id'] = MERCHANTID
        vo['data'] = encrypted
        vo['md5'] = md5
        print(vo)

        #post
        #json
        #headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        headers = {'Content-type': 'application/json', 'Accept': 'application/json'}
        r = requests.post('https://frontapi.ottpay.com:443/process', json=vo, headers=headers, verify=False)
        print(r.text)
        print(r)

        #-- ott -- response scheme
        #rsp_code
        #rsp_msg
        #data:order_id
        #data:order_status
        #data:refund_amt
        #md5

        #if return success, decrypt it
        json_content = json.loads(r.text)
        if r.status_code == 200:
            jsonstr = json_content['data']
            #print(jsonstr)

            md5 = json_content['md5']
            AESKEY = signByMD5(md5+MERCHANTKEY.upper())[8:-8]
            decrypted = AESCipher(AESKEY).decrypt(jsonstr)

            #print(decrypted)
            json_content['data'] = json.loads(decrypted)
            print(json_content)

        response = Response(json_content)
        response.status_code = r.status_code
        return response
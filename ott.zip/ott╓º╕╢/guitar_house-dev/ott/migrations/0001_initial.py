# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='OTTOrder',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('subject', models.CharField(max_length=256, verbose_name=b'\xe8\xae\xa2\xe5\x8d\x95\xe6\xa0\x87\xe9\xa2\x98')),
                ('out_trade_no', models.CharField(max_length=64, null=True, verbose_name=b'\xe5\x95\x86\xe6\x88\xb7\xe7\xbd\x91\xe7\xab\x99\xe5\x94\xaf\xe4\xb8\x80\xe8\xae\xa2\xe5\x8d\x95\xe5\x8f\xb7', blank=True)),
                ('product_code', models.CharField(default=b'QUICK_MSECURITY_PAY', max_length=64, verbose_name=b'\xe9\x94\x80\xe5\x94\xae\xe4\xba\xa7\xe5\x93\x81\xe7\xa0\x81')),
                ('total_amount', models.CharField(help_text=b'\xe5\x8d\x95\xe4\xbd\x8d\xe4\xb8\xba\xe5\x85\x83\xef\xbc\x8c\xe7\xb2\xbe\xe7\xa1\xae\xe5\x88\xb0\xe5\xb0\x8f\xe6\x95\xb0\xe7\x82\xb9\xe5\x90\x8e\xe4\xb8\xa4\xe4\xbd\x8d\xef\xbc\x8c\xe5\x8f\x96\xe5\x80\xbc\xe8\x8c\x83\xe5\x9b\xb4[0.01,100000000]', max_length=64, verbose_name=b'\xe8\xae\xa2\xe5\x8d\x95\xe6\x80\xbb\xe9\x87\x91\xe9\xa2\x9d')),
                ('body', models.CharField(max_length=128, null=True, verbose_name=b'\xe8\xae\xa2\xe5\x8d\x95\xe6\x8f\x8f\xe8\xbf\xb0', blank=True)),
                ('trade_no', models.CharField(max_length=64, null=True, verbose_name=b'\xe6\x94\xaf\xe4\xbb\x98\xe5\xae\x9d\xe7\xb3\xbb\xe7\xbb\x9f\xe4\xb8\xad\xe7\x9a\x84\xe4\xba\xa4\xe6\x98\x93\xe6\xb5\x81\xe6\xb0\xb4\xe5\x8f\xb7', blank=True)),
                ('busname', models.CharField(max_length=16, null=True, verbose_name=b'\xe4\xb8\x9a\xe5\x8a\xa1', blank=True)),
                ('time_end', models.DateTimeField(null=True, verbose_name=b'\xe6\x94\xaf\xe4\xbb\x98\xe5\xae\x8c\xe6\x88\x90\xe6\x97\xb6\xe9\x97\xb4', blank=True)),
                ('status', models.BooleanField(default=False, verbose_name=b'\xe6\x94\xaf\xe4\xbb\x98\xe5\xae\x8c\xe6\x88\x90\xe7\x8a\xb6\xe6\x80\x81')),
                ('create_time', models.DateTimeField(auto_now_add=True)),
                ('update_time', models.DateTimeField(auto_now=True)),
                ('biz_type', models.CharField(default=b'biz_type', max_length=64, verbose_name=b'\xe6\x94\xaf\xe4\xbb\x98\xe6\xb8\xa0\xe9\x81\x93')),
                ('apitype', models.CharField(default=b'apitype', max_length=64, verbose_name=b'api\xe7\xb1\xbb\xe5\x9e\x8b')),
                ('code_url', models.CharField(default=b'code_url', max_length=64, verbose_name=b'\xe6\x94\xaf\xe4\xbb\x98\xe9\x93\xbe\xe6\x8e\xa5')),
            ],
        ),
        migrations.CreateModel(
            name='OTTRefund',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('order_id', models.CharField(default=b'order_id', max_length=64, verbose_name=b'\xe9\x80\x80\xe6\xac\xbe\xe8\xae\xa2\xe5\x8d\x95')),
                ('refund_amt', models.CharField(default=b'refund_amt', max_length=64, verbose_name=b'\xe9\x80\x80\xe6\xac\xbe\xe9\x87\x91\xe9\xa2\x9d')),
            ],
        ),
    ]

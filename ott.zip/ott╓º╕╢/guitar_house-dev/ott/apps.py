from django.apps import AppConfig

class ottConfig(AppConfig):
    name = 'ott'

__author__ = 'steve'

import raven
from settings import *

''' Production Stripe key '''
# STRIPE_API_KEY = 'sk_live'
STATIC_URL = 'https://vanfruits.com/static/'
#STATIC_URL = 'http://52.33.238.157/static/'


DEBUG = False

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': '',
        'USER': '',
        'PASSWORD': '',
        'HOST': '',
        'PORT': '',
    },
}

# RAVEN (SENTRY)
RAVEN_CONFIG = {
    'dsn': 'https://200fff45e58a45afa33359528999c947:121ca401dda14b63b51d9678fc5d125f@sentry.io/166606',
    # If you are using git, you can also automatically configure the
    # release based on the git info.
    'release': raven.fetch_git_sha(os.path.dirname(os.pardir)),
}
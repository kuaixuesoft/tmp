/**
 * Created by et on 10/07/17.
 */

/*
* multi_print
* For user to bulk download order emails as pdf in a zip
*
* active()                      - change action value of the form then post the form
* getOrderNumbers()             - get all the selected order numbers as string and concat with -
* */
var multi_print = {
    active: function () {
        $('.multi-print-btn').on('click', function(e){
            e.preventDefault();

            var orderNumbers = multi_print.getOrderNumbers();
            // if order numbers are empty, return false
            if (!orderNumbers){
                return false;
            }

            // change the action of the form and submit the form
            $(this).closest('form').attr('action', '/dashboard/orders/email/download/' + orderNumbers);
            $('#download-pdf-form').submit();
        })
    },
    getOrderNumbers: function () {
        var output = '';
        $('.selected_order:checked').each(function () {
            output += $(this).data('order-number') + '-';
        });
        return output.slice(0,-1);
    }
};
//leon 10/10/2017

//nav-bar set
// Navbar hover effect
$( document ).ready(function() {

    var $el, leftPos, newWidth;
    $mainNav2 = $("#NavbarEffect");

    $("#NavbarEffect").append("<li id='magic-line'></li>");

    var $magicLine = $("#magic-line");

    $magicLine
        .width($(".current_page_item").width())
        .css("left", $(".current_page_item a").position().left)
        .data("origLeft", $magicLine.position().left)
        .data("origWidth", $magicLine.width());


    $("#NavbarEffect li").find("a").hover(function() {
        $el = $(this);
        leftPos = $el.position().left;
        newWidth = $el.width();

        $magicLine.stop().animate({
            left: leftPos,
            width: newWidth
        });
    }, function() {
        $magicLine.stop().animate({
            left: $magicLine.data("origLeft"),
            width: $magicLine.data("origWidth")
        });
    });

    $.get("/basket/getLength/", function(result){
        if(result.length>0)
            $("#nav-cart-num-item").html(result.length);
        else
            $("#nav-cart-num-item").hide();
      });
});

//hamburger effect
$('.hamburger').on('click', function(){
    var scroll_start = window.pageYOffset;
    var offset = 150;
    if($('.menu').hasClass('open') && scroll_start < offset){
        $('.menu').removeClass('open');
        $('.nav-bar').removeClass('navIndex');
        $('.bg-video').removeClass('addHeight');
    } else if($('.menu').hasClass('open') && scroll_start > offset){
        $('.menu').removeClass('open');
    } else {
        $('.menu').addClass('open');
        $('.nav-bar').addClass('navIndex');
        $('.bg-video').addClass('addHeight');
    }

});
//end of nav-bar set

//loading item effect
(function($) {
    $.fn.visible = function(partial) {

        var $t            = $(this),
            $w            = $(window),
            viewTop       = $w.scrollTop(),
            viewBottom    = viewTop + $w.height(),
            _top          = $t.offset().top,
            _bottom       = _top + $t.height(),
            compareTop    = partial === true ? _bottom : _top,
            compareBottom = partial === true ? _top : _bottom;

        return ((compareBottom <= viewBottom) && (compareTop >= viewTop));

    };

})(jQuery);

var win = $(window);

var allMods = $(".module-row");

allMods.each(function(i, el) {
    var el = $(el);
    if (el.visible(true)) {
        el.addClass("already-visible");
    }
});

win.scroll(function(event) {

    allMods.each(function(i, el) {
        var el = $(el);
        if (el.visible(true)) {
            el.addClass("come-in");
        }
    });

});
//end of loading item effect

//Filter for products
var checkboxFilter = {
    $filters: null,
    $reset: null,
    groups: [],
    outputArray: [],
    outputString: '',

    init: function(){
        var self = this;

        self.$filters = $('#Filters');
        self.$reset = $('#Reset');
        self.$container = $('#containerMix');

        self.$filters.find('fieldset').each(function(){
            self.groups.push({
                $inputs: $(this).find('input'),
                active: [],
                tracker: false
            });
        });

        self.bindHandlers();
    },

    bindHandlers: function(){
        var self = this;

        self.$filters.on('change', function(){
            self.parseFilters();
        });

        self.$reset.on('click', function(e){
            e.preventDefault();
            self.$filters[0].reset();
            self.parseFilters();
        });
    },

    parseFilters: function(){
        var self = this;

        for(var i = 0, group; group = self.groups[i]; i++){
            group.active = []; // reset arrays
            group.$inputs.each(function(){
                $(this).is(':checked') && group.active.push(this.value);
            });
            group.active.length && (group.tracker = 0);
        }

        self.concatenate();
    },

    concatenate: function(){
        var self = this,
            cache = '',
            crawled = false,
            checkTrackers = function(){
                var done = 0;

                for(var i = 0, group; group = self.groups[i]; i++){
                    (group.tracker === false) && done++;
                }

                return (done < self.groups.length);
            },
            crawl = function(){
                for(var i = 0, group; group = self.groups[i]; i++){
                    group.active[group.tracker] && (cache += group.active[group.tracker]);

                    if(i === self.groups.length - 1){
                        self.outputArray.push(cache);
                        cache = '';
                        updateTrackers();
                    }
                }
            },
            updateTrackers = function(){
                for(var i = self.groups.length - 1; i > -1; i--){
                    var group = self.groups[i];

                    if(group.active[group.tracker + 1]){
                        group.tracker++;
                        break;
                    } else if(i > 0){
                        group.tracker && (group.tracker = 0);
                    } else {
                        crawled = true;
                    }
                }
            };

        self.outputArray = [];

        do{
            crawl();
        }
        while(!crawled && checkTrackers());

        self.outputString = self.outputArray.join();

        !self.outputString.length && (self.outputString = 'all');

        if(self.$container.mixItUp('isLoaded')){
            self.$container.mixItUp('filter', self.outputString);
        }
    }
};

$(function(){
    checkboxFilter.init();

    $('#containerMix').mixItUp({
        controls: {
            enable: false
        },
        animation: {
            easing: 'cubic-bezier(0.86, 0, 0.07, 1)',
            duration: 600
        }
    });
});


//product-detail carousel
$('#itemCarousel').carousel({
    interval: 3500
});

// This event fires immediately when the slide instance method is invoked.
$('#itemCarousel').on('slide.bs.carousel', function (e) {
    var id = $('.item.active').data('slide-number');

    // Added a statement to make sure the carousel loops correct
    if(e.direction == 'right'){
        id = parseInt(id) - 1;
        if(id == -1) id = 7;
    } else{
        id = parseInt(id) + 1;
        if(id == $('[id^=carousel-thumb-]').length) id = 0;
    }

    $('[id^=carousel-thumb-]').removeClass('selected');
    $('[id=carousel-thumb-' + id + ']').addClass('selected');
});

// Thumb control
$('[id^=carousel-thumb-]').click( function(){
    var id_selector = $(this).attr("id");
    var id = id_selector.substr(id_selector.length -1);
    id = parseInt(id);
    $('#itemCarousel').carousel(id);
    $('[id^=carousel-thumb-]').removeClass('selected');
    $(this).addClass('selected');
});

//number input
// (function() {
//
//     window.inputNumber = function(el) {
//
//         var min = el.attr('min') || false;
//         var max = el.attr('max') || false;
//
//         var els = {};
//
//         els.dec = el.prev();
//         els.inc = el.next();
//
//         el.each(function() {
//             init($(this));
//         });
//
//         function init(el) {
//
//             els.dec.on('click', decrement);
//             els.inc.on('click', increment);
//
//             function decrement() {
//                 var value = el[0].value;
//                 value--;
//                 if(!min || value >= min) {
//                     el[0].value = value;
//                 }
//             }
//
//             function increment() {
//                 var value = el[0].value;
//                 value++;
//                 if(!max || value <= max) {
//                     el[0].value = value++;
//                 }
//             }
//         }
//     }
// })();
// inputNumber($('.input-number'));




(function (win, doc) {
    'use strict';
    if (!doc.querySelector || !win.addEventListener || !doc.documentElement.classList) {
        return;
    }

    var Spinner = function(rootElement) {
        //Add button selector
        var addButtonSelector = '.js_spin-add';
        //Remove button selector
        var removeButtonSelector = '.js_spin-remove';
        //Number input selector
        var numberInputSelector = '.js_spin-input';
        //A variable to store the markup for the add button
        var addButtonMarkup = '<button type="button" class="FormUnit-quantity FormUnit-quantity--add js_spin-add Icon Icon--isClosed input-number-increment">+</button>';
        //A variable to store the markup for the remove button
        var removeButtonMarkup = '<button type="button" class="FormUnit-quantity FormUnit-quantity--remove js_spin-remove Icon Icon--remove input-number-decrement">-</button>';
        //Variable to store the root's container
        var container;
        //A variable for the markup of the number input pattern
        var markup;
        //A variable to store a number input
        var numberInput;
        //Variable to store the add button
        var addButton;
        //Variable to store the remove button
        var removeButton;
        //Store max value
        var maxValue;
        //Store min value
        var minValue;
        //Store step value
        var step;
        //Store new value
        var newValue;
        //Variable to store the loop counter
        var i;

        //Initialisation function
        this.init = function() {
            container = rootElement;
            //Get the markup inside the number input container
            markup = container.innerHTML;
            //Create a button to decrese the value by 1
            markup += removeButtonMarkup;
            //Create a button to increase the value by 1
            markup += addButtonMarkup;
            //Update the container with the new markup
            container.innerHTML = markup;

            //Get the add and remove buttons
            addButton = rootElement.querySelector(addButtonSelector);
            removeButton = rootElement.querySelector(removeButtonSelector);

            //Get the number input element
            numberInput = rootElement.querySelector(numberInputSelector);

            //Get min, max and step values
            if (numberInput.hasAttribute('max')) {
                maxValue = parseInt(numberInput.getAttribute('max'), 10);
            } else {
                maxValue = 99999;
            }
            if (numberInput.hasAttribute('min')) {
                minValue = parseInt(numberInput.getAttribute('min'), 10);
            } else {
                minValue = 0;
            }
            if (numberInput.hasAttribute('step')) {
                step = parseInt(numberInput.getAttribute('step'), 10);
            } else {
                step = 1;
            }

            //Change the number input type to text
            numberInput.setAttribute('type', 'text');

            //If there is there no pattern attribute, set it to only accept numbers
            if (!numberInput.hasAttribute('pattern')) {
                numberInput.setAttribute('pattern', '[0-9]');
            }

            //Add click events to the add and remove buttons
            addButton.addEventListener('click', add, false);
            removeButton.addEventListener('click', remove, false);
        };

        //Methods for setting values
        this.setAddButtonMarkup = function(markup) {
            addButtonMarkup = markup;
        };

        this.setRemoveButtonMarkup = function(markup) {
            removeButtonMarkup = markup;
        };

        this.setAddButtonSelector = function(selector) {
            addButtonSelector = selector;
        };

        this.setRemoveSelector = function(selector) {
            removeButtonSelector = selector;
        };

        this.setNumberInputSelector = function(selector) {
            numberInputSelector = selector;
        };

        //Function to add one to the quantity value
        var add = function(ev) {
            newValue = parseInt(numberInput.value, 10) + step;
            //If the value is less than the max value
            if (newValue <= maxValue) {
                //Add one to the number input value
                numberInput.value = newValue;
                //Button is active
                removeButton.disabled = false;
            }
            //If the value is equal to the max value
            if (numberInput.value == maxValue || newValue > maxValue) {
                //Disable the button
                addButton.disabled = true;
            }
            ev.preventDefault();
        };
        //Function to subtract one from the quantity value
        var remove = function(ev) {
            newValue = parseInt(numberInput.value, 10) - step;
            //If the number input value is bigger than the min value, reduce the the value by 1
            if (newValue >= minValue) {
                numberInput.value = newValue;
                addButton.disabled = false;
            }
            //If the input value is the min value, add disabled property to the button
            if (numberInput.value == minValue || newValue < minValue) {
                removeButton.disabled = true;
            }
            ev.preventDefault();
        };
    };

    //Get all of the number input elements
    var spins = doc.querySelectorAll('.js_spin');
    //Store the total number of number inputs
    var spinsTotal = spins.length;
    //A variable to store one number inputs
    var spin;
    //A counter for the loop
    var i;
    //Loop through each number input
    for ( i = 0; i < spinsTotal; i = i + 1 ) {
        //Create a new Spin object for each number input
        spin = new Spinner(spins[i]);
        //Start the initialisation function
        spin.init();
    }

}(this, this.document));




//remove span tag space
var inputIndex = $('.input-number-div');
inputIndex.contents().filter(function() { return this.nodeType === 3; }).remove();
$('.user-div-all').contents().filter(function() { return this.nodeType === 3; }).remove();
$('.tab-content').contents().filter(function() { return this.nodeType === 3; }).remove();

//add total num.
$(function(){
    var shoppingCart = $('.shopping-cart');
    $.each(shoppingCart, function(){
        var norPrice = $(this).children('.nor-price-div').find('span').text();
        var priceNum = $(this).children('.input-number-div').find('input').val();


        $(this).children('.total-price-div').find('span').text(norPrice * priceNum);
    });
});

$(document).ready(function() {
    var sumPrice = 0;
    var totalPriceDiv = $('.total-price-div');
    var totalPriceAll = $('#totalPriceAll');
    var shippingFree = $('.shipping-free');

    $.each($(".total-price-div span"),function(index,item){
        //parsetFloat()
        sumPrice += parseInt($.trim($(item).text()));
    });

    var totalPriceAllSpan = totalPriceDiv.find('span').html();
    // totalPriceAll.find('span').html(sumPrice);

    if (totalPriceAllSpan > 0 ) {
        shippingFree.css('display', 'block');
        totalPriceAll.find('span').html(sumPrice + 50);
    }else {
        shippingFree.css('display', 'none');
        totalPriceAll.find('span').html(0);
    }
});





inputIndex.find('button').click(function(){

    var inputNum = $(this).siblings('input').val();
    var norPrice = $(this).parent('div').prev('.nor-price-div').find('span').html();

    $(this).parent('div').next('.total-price-div').find('span').html(inputNum * norPrice);
    $(document).ready(function() {
        var sumPrice = 0;
        $.each($(".total-price-div span"),function(index,item){
            //parsetFloat()
            sumPrice += parseInt($.trim($(item).text()));
        });

        $('#totalPriceAll').find('span').html(sumPrice + 50);
    });

});



/**
 * Created by et-asus on 15/04/16.
 */
var cartHeader = $(".adds.cart-pop-div h1");
var cartMessage = $(".add-cart-message");
var cart = $(".shop-cart");


/*
* home              - get the dropbox select in homepage
* product           - get the dropbox select in product detail page
* onChange          - do variety of things when selecting different variations
* */
var variation = {
    home  : '.product-homepage-variations',
    product: '#product-detailPage-variations',
    onChange: function (selector) {
        $(selector).on('change', function () {
            // get the price from data-price attribute of each option element
            var price = $(this).find(':selected').data('price');

            // get the price and the short descrition if there is any
            var split_price_description = price.split('/');
            var price_split = split_price_description[0];
            var description_split = split_price_description.slice(1);

            var id = $(this).find(':selected').val();

            switch (selector){
                case variation.home:

                    // console.log($(this).closest('.stable'));
                    // if used in homepage loop through the closest .add-to-cart-ajax and add id attribute to them
                    $.each($(this).closest('.stable').find('.add-to-cart-ajax'), function () {
                        // somehow changing data-id doesn't work so I am adding in id myself
                        $(this).attr('id', id);
                    });

                    $(this).closest('.stable').find('.sprice').find('p').text(price); // for regular prices
                    $(this).closest('.stable').find('.strike-div').find('span').text(price);  // for on sales
                    break;
                case variation.product:
                    // because the price in homepage would include details which we do not need here
                    var $product_details = $('.pull-right.productDetails');
                    $product_details.find('h1').text(price_split);
                    $product_details.find('.secondTitle').text(description_split.join('/'));
                    $('.to-cart-ajax, .to-checkout-ajax').attr('id', id);
                    break;
            }
        });

    }
};

/*
* hideCart()
* When the X image in the shopping pop up info div is clicked, pop up hides with info still stored
* Also lighten up the background back to normal
* Puts the pop up ui back to the original one, eg. if people clicked add order then input the wrong order number then close the pop up, once they click on the cart again they will be asked add order / new order instead of staying on the same add order input ui
* This is outside of $(function()) because this function is also used in 'static/oscar/js/oscar/ui.js' when people change quantity in basket.html page
* */
function hideCart(){
    $(".cart-popup-hide, .fr-buy").on('click', function(){
        $(".shop-cart").hide();
        $('.cart-pop-div-main').show().siblings().hide();
        $('.addToInvoiceInput').val("");
        $('.shop-content').removeClass('acknowledgeInfo');
        //Lighten up the body background of the page and images
        $('.cover').hide();
    });
}

$(function() {
    //Hide the shopping cart pop up info div
    $(".shop-cart").hide();

    /*
    * getCookie()
    * From django documentation to get the CSRF Token from cookies
    * */
    function getCookie(name) {
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    } // end getCookie()

    /*
    * toCartOrCheckout()
    * invoking this will use ajax to pass product id and qty to the back-end and return success / failure
    * success will have a pop up with messages including items already in cart and total value with the option to continue shopping or go to cart directly
    * failure would be used in the products' page which would either let user know product is out of stock or there's only max available in stock that the user choose to much
    *
    * @param cartOrCheckoutJSelector    selector which is most likely a button - example: $(".add-to-cart-ajax")
    * @param cartOrCheckout             string to tell the function if item goes into cart and continue shopping or goes to checkout page
    * @param homeOrProduct              string to tell the function if button clicked is in homepage or product page
    * */
    function toCartOrCheckout(cartOrCheckoutJSelector, cartOrCheckout, homeOrProduct){
        cartOrCheckoutJSelector.on("click", function(e){
            //Prevent Default action which would reload the page
            e.preventDefault();

            //Variables to pass into the ajax
            var csrftoken = getCookie('csrftoken');
            var qty, selectValue = $("#numbers").val();         //selectValue is the number value user enters which is used in product's page
            //Variables used for ajax if has attr id then use the id else use the data-id
            var productID = ($(this).attr('id')) ? $(this).attr('id'): $(this).attr("data-id");
            // var jsonURL = "/basket/add/" + productID + "/";
            var ajaxResultMessage = ["success", "failure"];    //result property value returned

            //When the X image in the shopping pop up info div is clicked, pop up hides with info still stored
            hideCart();

            //Check if add cart is in homepage or product page to set the qty
            switch(homeOrProduct){
                case "home":
                    qty = 1;
                    break;
                case "product":
                     if((!selectValue) || (selectValue <= 0) || (selectValue > 1000) ){
                         $('.cover').show();
                         cartHeader.text("數量不能少於0，並且不能多餘1000");
                         cartMessage.hide();
                         cart.show();
                         return;
                     } else {
                         qty = selectValue;
                     }
                     break;
            }

            var jsonURL = "/basket/add/" + productID + "/";

            //Dim the body background of the page and images
            $('.cover').show();

            //run ajax
            $.ajax({
                method: "post",
                url: jsonURL,
                dataType: "json",
                data: { csrfmiddlewaretoken: csrftoken,
                        quantity: qty},
                success: function (data) {
                    var dataResult = data["result"];
                    var dataMessage = data["message"];


                    //if the result is success
                    //else if result is failure
                    //else alert contact admin
                    if(dataResult == ajaxResultMessage[0]){
                        //Check if cart goes to checkout directly or continue shopping
                        switch(cartOrCheckout){
                            case "cart":
                                cartHeader.text("成功加入購物車！");
                                $(".cartcount").text(data["num"]);
                                $(".cartprice").text("$" + data["price"]);

                                //Show pop up info div
                                cart.show();
                                cartMessage.show();
                                break;
                            case "checkout":
                                $(".shop-cart").hide();
                                window.location.href = "/basket/";
                                break;
                        }
                    }else if(dataResult == ajaxResultMessage[1]){
                        //Check if failure message tells no stock or there's a maximum stock available that user choose too much
                        var noStockMessage  = "no stock available";
                        var maxStockMessage = "maximum";
                        var fieldRequired   = "This field is required.";

                        /*Change cart's header depending on what failure message is returned*/
                        //if no stock
                        //else if the message contains the required message;
                        //else if the message contains the string "maximum"
                        if(dataMessage == noStockMessage){
                            cartHeader.text("產品缺貨");
                        }else if(dataMessage.indexOf(fieldRequired) != -1){
                            cartHeader.text("數量不能為空或者少於0");
                        }else if(dataMessage.indexOf(maxStockMessage) != -1){
                            var maxStockNumberAvailable = dataMessage.replace(/[^0-9]/g, '');
                            cartHeader.text("本産品最多只能買" + maxStockNumberAvailable + "個");
                        }

                        //Hide the detailed cart message and show cart with only the cart's header which tells the user what the error is
                        cartMessage.hide();
                        cart.show();
                    }else{
                        alert("Please contact admin for this error");
                    }
                }
            }); // End ajax
        }); // End add-to-cart-ajax click
    }// end toCartOrCheckout()

    /*
    * addOrderOrNewOrder()
    * this changes the pop up cart ui
    * customers can use this ui to choose items to existing order or placing a new order
    * if add order, then an input will show for customers to enter the existing order number
    *
    * @param select                  selector which is most likely a button - example: $('.go-basket-btn')
    * @param btn                     just the name of the button
    * */
    function addOrderOrNewOrder(selector, btn) {
        // 去結算 clicked, next ui ask if 加单 / 新单.  If 新单 clicked, go checkout directly
        // 去結算 > 加单 clicked, cart ui changes and able to input the invoice number to add the order into
        // 去結算 > 加单 > 加单 clicked again after input entered, runs the ajax call
        selector.on('click', function () {
            switch (btn) {
                case 'addOrderOption':
                    if ($(this).hasClass('addOrderOption')) {
                        $(this).closest('.cart-pop-div').find('.addItemsOnExistInvoice').show().siblings().hide();
                    } else {
                        window.location.href = "/basket/";
                    }
                    break;
                case 'addItemsOnExistInvoice-btn':
                    $('.addToInvoiceInput-div').show().siblings().hide();
                    break;
                case 'addToInvoiceInput-btn':
                    // ajax call to check if the invoice number is valid to add order
                    // if valid, runs the hidden form which would submit the add order info
                    $('.addToInvoiceInput-error').text("").hide();
                    var orgInvoiceNum = $('.addToInvoiceInput').val();        // Original Invoice Number

                    // fail messages if add order did not success
                    var failure = {
                        dataMessages: ["invalid request", "You can only add products to your own order.", "The order is handled. You cannot add new products.", "Please add to the original order."],
                        outputMessages: ["單號不正確", "只可以給當前賬戶的訂單加單", "訂單已處理,不能加單", "只能用原訂單號加單"],
                        errorMsg: function(msg){
                            msg = (msg === undefined) ? "加單失敗，請聯絡管理員" : msg;
                            $('.addToInvoiceInput-error').text(msg).show();
                        }
                    };

                    $.ajax({
                        method: "post",
                        url: "/basket/add_order",
                        dataType: "json",
                        data: {order_id: orgInvoiceNum},
                        success: function (data) {
                            if (data.result === 'success') {
                                $(".shop-cart").hide();
                                $('#user-pickup-info-form-addOrderShipping').trigger('submit');
                            } else {
                                // check which error message is returned from backend
                                switch (data.message) {
                                    case failure.dataMessages[0]:
                                        // print "單號不正確"
                                        failure.errorMsg(failure.outputMessages[0]);
                                        break;
                                    case failure.dataMessages[1]:
                                        // print "只可以給當前賬戶的訂單價單"
                                        failure.errorMsg(failure.outputMessages[1]);
                                        break;
                                    case failure.dataMessages[2]:
                                        // print "訂單已處理,不能加單"
                                        failure.errorMsg(failure.outputMessages[2]);
                                        break;
                                    case failure.dataMessages[3]:
                                        // print "只能用原訂單號加單"
                                        failure.errorMsg(failure.outputMessages[3]);
                                        break;
                                    default:
                                        // print "加單失敗，請聯絡管理員" which should never happen
                                        failure.errorMsg();
                                        break;
                                }
                            }
                        }
                    });
                    break;
            } // end switch statement
        });
    } // end addOrderOrNewOrder()

    /*
    *** 首页加入购物车 click
     */
    toCartOrCheckout($(".add-to-cart-ajax"), "cart", "home");

    /*
    *** Product Detail 加入购物车 click
     */
    toCartOrCheckout($(".to-cart-ajax"), "cart", "product");

    /*
    *** 立刻购买 click
     */
    toCartOrCheckout($(".to-checkout-ajax"), "checkout", "product");

    /*
    *** 去結算 click
     */
    addOrderOrNewOrder($('.go-basket-btn'), 'addOrderOption');

    /*
    *** first 加单 click which brings up the input ui
     */
    addOrderOrNewOrder($('.addItemsOnExistInvoice-btn'), 'addItemsOnExistInvoice-btn');

    /*
    *** second 加单 click which validates the input to check if 加单 is available
     */
    addOrderOrNewOrder($('.addToInvoiceInput-btn'), 'addToInvoiceInput-btn');


});
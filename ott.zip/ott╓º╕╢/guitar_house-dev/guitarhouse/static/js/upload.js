/**
 * Created by et-asus on 04/05/16.
 */
$(function(){
    /**
     * use FileReader() to read the image file and output previews of images before actual upload
     * @param input         //file input
     * @param preview       //either $('#banner-image-preview') or $('#coupon-image-preview') depend which file upload is used
     */
    function readImage(input, preview, url) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                preview.attr('src', e.target.result);
                preview.show();
                url.show();
            };

            reader.readAsDataURL(input.files[0]);
        }
    }

    /**
     * After choosing file, use readImage() to read and output the images
     */
    $("#upload-banner-input, #upload-coupon-input").on('change', function(){
        var whichPreview = ($(this).attr('id'));
        var preview, url;
        switch (whichPreview){
            case 'upload-banner-input':
                preview = $('#banner-image-preview');
                url = $('.banner-add-url');
                break;
            case 'upload-coupon-input':
                preview = $('#coupon-image-preview');
                url = $('.coupon-add-url');
                break;

        }
        readImage(this, preview, url);
    });

    /**
     * When change button is clicked (if there is one)
     * Changes the image
     */
    $('.banner-image-list').on('click', '.change-btn', function () {

    });

    /**
     * When url button is clicked (if there is one)
     * Changes the url for the image
     */
    $('.banner-image-list').on('click', '.url-btn', function () {
        // var askURL = prompt("Please enter URL without http://");
        // var $closestLI = $(this).closest('li');
        // $closestLI.find(">:first-child").attr('href', "http://" + askURL);
        // $closestLI.find('span').text("http://" + askURL);
    });

    /**
     * When delete button is clicked (if there is one)
     * The row of the image will be deleted
     */
    $('.banner-image-list').on('click', '.delete-btn', function () {
        $(this).closest('li').remove();
    });

    /**
     * When mouse focusout in the text field, the value will entered will be set into the value attr
     */
    $('#banner-url, #coupon-url').on('focusout', function(){
        var value = $(this).val();
        $(this).attr('value', value);
    });
});
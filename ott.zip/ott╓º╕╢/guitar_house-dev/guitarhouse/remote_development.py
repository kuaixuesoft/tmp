__author__ = 'mikeG'

from settings import *

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'guitarhouse_dev',
        'USER': 'guitarhouse',
        'PASSWORD': 'Bochao123!',
        'HOST': 'localhost',
        'PORT': '3306',
    },
}

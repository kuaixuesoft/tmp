#!/usr/bin/env python
# -*- coding: utf-8 -*-
from django_tables2 import A, Column, LinkColumn, TemplateColumn

from oscar.core.loading import get_class

DashboardTable = get_class('dashboard.tables', 'DashboardTable')


class UserTable(DashboardTable):
    check = TemplateColumn(
        template_name='dashboard/users/user_row_checkbox.html',
        verbose_name=' ', orderable=False)
    email = LinkColumn('dashboard:user-detail', args=[A('id')],
                       verbose_name=u'電郵地址',
                       accessor='email')
    name = Column(accessor='get_full_name',
                  verbose_name=u'名字',
                  order_by=('last_name', 'first_name'))
    active = Column(accessor='is_active', verbose_name=u'狀態')
    staff = Column(accessor='is_staff', verbose_name=u'員工狀態')
    date_registered = Column(accessor='date_joined', verbose_name=u'註冊日期')
    num_orders = Column(accessor='orders.count', orderable=False, verbose_name=u'訂單數量')
    actions = TemplateColumn(
        template_name='dashboard/users/user_row_actions.html',
        verbose_name=u'處理')
    get_caption_display = u'客戶總數'

    icon = "group"

    class Meta(DashboardTable.Meta):
        template = 'dashboard/users/table.html'

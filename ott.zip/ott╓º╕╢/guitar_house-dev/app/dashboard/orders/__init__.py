default_app_config = 'oscar.apps.dashboard.orders.config.OrdersDashboardConfig'

#!/usr/bin/env python
# -*- coding: utf-8 -*-
import re

from django import forms
from django.db.models import Q
from django.utils.translation import ugettext_lazy as _

from oscar.core.loading import get_model

Product = get_model('catalogue', 'Product')
Range = get_model('offer', 'Range')


class RangeForm(forms.ModelForm):

    class Meta:
        model = Range
        fields = [
            'name', 'description',
            'includes_all_products', 'included_categories'
        ]


class RangeProductForm(forms.Form):
    query = forms.CharField(
        max_length=1024, label=_(u"产品编号"),
        widget=forms.Textarea, required=False,
        help_text=_(u"可以一次添加多个产品编号，每个一行"))
    file_upload = forms.FileField(
        label=_(u"产品编号文件"), required=False, max_length=255,
        help_text=_(u'可以通过文件上传一批产品编号，每个一行'))

    def __init__(self, range, *args, **kwargs):
        self.range = range
        super(RangeProductForm, self).__init__(*args, **kwargs)

    def clean(self):
        clean_data = super(RangeProductForm, self).clean()
        if not clean_data.get('query') and not clean_data.get('file_upload'):
            raise forms.ValidationError(
                _(u"必须输入至少一个产品"))
        return clean_data

    def clean_query(self):
        raw = self.cleaned_data['query']
        if not raw:
            return raw

        # Check that the search matches some products
        ids = set(re.compile(r'[\w-]+').findall(raw))
        products = self.range.all_products()
        existing_skus = set(products.values_list(
            'stockrecords__partner_sku', flat=True))
        existing_upcs = set(products.values_list('upc', flat=True))
        existing_ids = existing_skus.union(existing_upcs)
        new_ids = ids - existing_ids

        if len(new_ids) == 0:
            raise forms.ValidationError(
                _(u"编号 %s 产品已存在"
                  u" 这个范围中") % (', '.join(ids)))

        self.products = Product._default_manager.filter(
            Q(stockrecords__partner_sku__in=new_ids) |
            Q(upc__in=new_ids))
        if len(self.products) == 0:
            raise forms.ValidationError(
                _(u"没有产品是这个编号 %s")
                % u", ".join(ids))

        found_skus = set(self.products.values_list(
            'stockrecords__partner_sku', flat=True))
        found_upcs = set(self.products.values_list('upc', flat=True))
        found_ids = found_skus.union(found_upcs)
        self.missing_skus = new_ids - found_ids
        self.duplicate_skus = existing_ids.intersection(ids)

        return raw

    def get_products(self):
        return self.products if hasattr(self, 'products') else []

    def get_missing_skus(self):
        return self.missing_skus

    def get_duplicate_skus(self):
        return self.duplicate_skus

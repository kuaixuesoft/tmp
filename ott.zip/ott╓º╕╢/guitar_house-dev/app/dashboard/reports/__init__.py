default_app_config = (
    'oscar.apps.dashboard.reports.config.ReportsDashboardConfig')

from oscar.apps.shipping.admin import *  # noqa

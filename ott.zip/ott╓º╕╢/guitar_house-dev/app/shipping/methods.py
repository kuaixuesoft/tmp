#!/usr/bin/env python
# -*- coding: utf-8 -*-
from decimal import Decimal as D
from django.template.loader import render_to_string

from oscar.apps.shipping import methods
from oscar.core import prices
from guitarhouse import vanfruits_messages
from oscar.core.loading import get_model
from account.models import AvailableCity
from django import http
UserAddress = get_model('address', 'UserAddress')


class Standard(methods.Base):
    code = 'standard'
    name = '送貨到家'

    charge_per_item = D('0.0')
    threshold = D('88.00')

    description = vanfruits_messages.SHIPPING_METHOD_DECLARATION
    '''TODO
    description = render_to_string(
        'shipping/standard.html', {
            'charge_per_item': charge_per_item,
            'threshold': threshold})
    '''

    def calculate(self, basket):
        # Free for orders over some threshold
        # if basket.total_incl_tax >= self.threshold:
        #     return prices.Price(
        #         currency=basket.currency,
        #         excl_tax=D('0.00'),
        #         incl_tax=D('0.00'))

        city = ''
        try:
            # new address
            city = basket.strategy.request.session['checkout_data']['shipping']['new_address_fields']['line4']
        except:
            try:
                # old address
                #address_id = basket.strategy.request.session['checkout_data']['shipping']['user_address_id']
                address = UserAddress._default_manager.get(user=basket.strategy.request.user)
                city = address.city
            except:
                raise http.Http404("Invalid Address 1: " + city)

        if city:
            city = AvailableCity.objects.filter(slug=city)
            total = 5
            if city:
                total = city[0].shipping_fee
            total = D(total)
            return prices.Price(
                currency=basket.currency,
                excl_tax=total,
                incl_tax=total)
        else:
            raise http.Http404("Invalid Address 2" + city)


class GetByYourself(methods.NoShippingRequired):
    code = 'getByYourSelf'
    name = '到店自取'

    charge_per_item = D('0.0')

    description = vanfruits_messages.GET_BY_YOUR_SELF_SHIPPING_DECLARATION
    '''TODO
    description = render_to_string(
        'shipping/standard.html', {
            'charge_per_item': charge_per_item,
            'threshold': threshold})
    '''


class AddOrder(methods.NoShippingRequired):
    code = 'addOrderShipping'
    name = '追加訂單'

    charge_per_item = D('0.0')

    description = vanfruits_messages.ADD_ORDER_SHIPPING
    '''TODO
    description = render_to_string(
        'shipping/standard.html', {
            'charge_per_item': charge_per_item,
            'threshold': threshold})
    '''

from oscar.apps.shipping import config


class ShippingConfig(config.ShippingConfig):
    name = 'app.shipping'

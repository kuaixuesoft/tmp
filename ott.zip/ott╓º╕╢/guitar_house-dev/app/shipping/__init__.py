default_app_config = 'app.shipping.config.ShippingConfig'

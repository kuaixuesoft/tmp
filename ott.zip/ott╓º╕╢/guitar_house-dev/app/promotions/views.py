from django.core.urlresolvers import reverse
from django.views.generic import RedirectView, TemplateView
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import ensure_csrf_cookie

from oscar.core.loading import get_class, get_model
from account.models import IndexPageData

import json

get_product_search_handler_class = get_class(
    'catalogue.search_handlers', 'get_product_search_handler_class')

Category = get_model('catalogue', 'category')
Product = get_model('catalogue', 'product')
HandPickedProductList = get_model('promotions', 'HandPickedProductList')
PromotionsImage = get_model('promotions', 'Image')
PromotionsRawHTML = get_model('promotions', 'RawHTML')

class SaleView(TemplateView):
    template_name = 'promotions/sale.html'

    @method_decorator(ensure_csrf_cookie)
    def dispatch(self, *args, **kwargs):
        return super(SaleView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(SaleView, self).get_context_data(**kwargs)

        products = Product.objects.filter(original_price__isnull=False).order_by('-date_updated')[:10]
        context['products'] = products

        hand_picked_products = HandPickedProductList.objects.filter(name__startswith='Picked')[0]
        context['hand_picked_products'] = hand_picked_products.products.all()

        index_data = IndexPageData.objects.all()[0]
        banners = json.loads(index_data.banners)
        coupons = json.loads(index_data.coupons)

        context['banners'] = banners
        context['coupons'] = coupons

        return context


class HomeView(TemplateView):
    """
    This is the home page and will typically live at /
    """
    template_name = 'promotions/home.html'

    @method_decorator(ensure_csrf_cookie)
    def dispatch(self, *args, **kwargs):
        return super(HomeView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        categories = Category.objects.all()
        data = {}
        for category in categories:
            products = Product.objects.filter(categories__id=category.id, published=True, primary_product__isnull=True).prefetch_related('variations').order_by('-date_updated')[:9]
            if products:
                data[category] = products

        # specialOfferSuggestion
        recommendations = Product.objects.filter(categories__slug="specialOfferSuggestion", published=True,
                                                 primary_product__isnull=True).order_by('-date_updated')[:10]
        if recommendations:
            data["recommendations"] = recommendations

        # guidelines
        guidelines = PromotionsImage.objects.filter(name__startswith="Guidelines").order_by('-date_created')[:3]
        if guidelines:
            data["guidelines"] = guidelines

        # news
        news = PromotionsImage.objects.filter(name__startswith="News").order_by('-date_created')[:3]
        if news:
            data["news"] = news

        context = super(HomeView, self).get_context_data(**kwargs)
        context['data'] = data

        # get index page data
        index_data = IndexPageData.objects.all()[0]
        banners = json.loads(index_data.banners)
        coupons = json.loads(index_data.coupons)

        context['banners'] = banners
        context['coupons'] = coupons

        return context

class AboutView(TemplateView):
    template_name = 'promotions/about.html'

    @method_decorator(ensure_csrf_cookie)
    def dispatch(self, *args, **kwargs):
        return super(AboutView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        data = {}

        # Images
        guidelines = PromotionsImage.objects.filter(name__startswith="About").order_by('-date_created')
        if guidelines:
            data["images"] = guidelines[:3]

        # Wording
        wording = PromotionsRawHTML.objects.filter(name__startswith="About").order_by('-date_created')
        if wording:
            data["wording"] = wording[0]

        context = super(AboutView, self).get_context_data(**kwargs)
        context['data'] = data

        index_data = IndexPageData.objects.all()[0]
        banners = json.loads(index_data.banners)
        coupons = json.loads(index_data.coupons)

        context['banners'] = banners
        context['coupons'] = coupons

        return context


class RecordClickView(RedirectView):
    """
    Simple RedirectView that helps recording clicks made on promotions
    """
    permanent = False
    model = None

    def get_redirect_url(self, **kwargs):
        try:
            prom = self.model.objects.get(pk=kwargs['pk'])
        except self.model.DoesNotExist:
            return reverse('promotions:home')

        if prom.promotion.has_link:
            prom.record_click()
            return prom.link_url
        return reverse('promotions:home')

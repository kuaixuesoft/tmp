from oscar.apps.catalogue import config


class CatalogueConfig(config.CatalogueConfig):
    name = 'app.catalogue'

default_app_config = 'app.catalogue.config.CatalogueConfig'

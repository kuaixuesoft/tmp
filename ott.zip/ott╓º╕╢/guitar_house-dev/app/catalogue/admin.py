from oscar.apps.catalogue.admin import *  # noqa

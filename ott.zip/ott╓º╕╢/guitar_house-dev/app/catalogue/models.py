# yourproject/catalogue/models.py

from django.db import models
from oscar.apps.catalogue.abstract_models import AbstractProduct


class Product(AbstractProduct):
    short_description = models.CharField(blank=True, max_length=255)
    flag_image_url = models.CharField(blank=True, max_length=255)
    properties = models.TextField(blank=True, help_text='property pair in json format')
    published = models.BooleanField(default=True, help_text='whether the product is published')
    original_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True, help_text="original_price")
    primary_product = models.ForeignKey('self', blank=True, null=True, help_text='the primary product', related_name='variations')


from oscar.apps.catalogue.models import *

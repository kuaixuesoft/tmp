# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('order', '0007_order_deliver_note'),
    ]

    operations = [
        migrations.AddField(
            model_name='order',
            name='add_to_order',
            field=models.ForeignKey(to='order.Order', null=True),
        ),
    ]

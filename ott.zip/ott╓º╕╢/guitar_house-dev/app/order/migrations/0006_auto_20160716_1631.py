# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('order', '0005_auto_20160511_0128'),
    ]

    operations = [
        migrations.AddField(
            model_name='order',
            name='pickup_name',
            field=models.CharField(help_text=b'pickup name', max_length=255, null=True),
        ),
        migrations.AddField(
            model_name='order',
            name='pickup_note',
            field=models.TextField(help_text=b'pickup note', null=True),
        ),
        migrations.AddField(
            model_name='order',
            name='pickup_phone',
            field=models.CharField(help_text=b'pickup phone', max_length=255, null=True),
        ),
    ]

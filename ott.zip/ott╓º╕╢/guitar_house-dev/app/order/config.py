from oscar.apps.order import config


class OrderConfig(config.OrderConfig):
    name = 'app.order'

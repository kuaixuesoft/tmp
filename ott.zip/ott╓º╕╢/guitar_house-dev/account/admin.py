from django.contrib import admin

# Register your models here.
from models import *
from app.authUser.models import *

admin.site.register(AvailableCity)
admin.site.register(AvailableShippingTime)
admin.site.register(IndexPageData)
admin.site.register(User)

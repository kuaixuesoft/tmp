# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('account', '0003_auto_20160508_0400'),
    ]

    operations = [
        migrations.CreateModel(
            name='IndexPageData',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('banners', models.TextField(help_text='json array of banners with its image url and link', null=True, blank=True)),
                ('coupons', models.TextField(help_text='json array of coupons with its image url and link', null=True, blank=True)),
            ],
        ),
    ]

# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('account', '0006_availablecity_shipping_fee'),
    ]

    operations = [
        migrations.CreateModel(
            name='Verification',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('number', models.TextField(help_text='verification number', null=True, blank=True)),
                ('phone', models.TextField(help_text='telephone', null=True, blank=True)),
                ('last_sent', models.DateTimeField(help_text='last datetime to send sms', null=True, blank=True)),
                ('verified', models.BooleanField(default=False, help_text="whether the user' phone number has been verified")),
                ('user', models.OneToOneField(to=settings.AUTH_USER_MODEL)),
            ],
        ),
    ]

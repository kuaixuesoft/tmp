#!/usr/bin/env python
# -*- coding: utf8 -*-
from twilio.rest import Client
from models import Verification
import random
from datetime import datetime


def send_sms(to, body):
    account = "AC5d2bfdd29f759aa7f13fb394930012a3"
    token = "45d1f517084b41166b29d727c8c3f0a2"
    client = Client(account, token)
    client.messages.create(to=to, from_="+16042398184", body=body)


def generate_sms(order):
    # message = '您的溫鮮生訂單' + str(order.number) + '已被確認，請點擊下方鏈接查看訂單詳情，感謝您使用溫鮮生。' + str(
    #     order.site.domain) + '/accounts/orders/' + str(order.number) + '/'

    message = '我們已收到您的溫鮮生訂單，您的訂單正在處理當中 ，請點擊以下鏈接 查看訂單詳情 謝謝。https://' + str(
        order.site.domain) + '/accounts/orders/' + str(order.number) + '/'
    # add order info, url detail or other information in message
    # use Traditional Chinese and English
    return message


def generate_verification_sms(user, phone):
    number = generate_verification_number()
    # message = 'Your verification number is ' + str(number)
    message = '歡迎使用溫鮮生訂單平台，您的手機綁定驗證碼是' + str(number) + ' ，請盡快登錄平台完成手機綁定以便接收訂單明細. 謝謝'
    verifications = Verification.objects.filter(phone=phone)
    if verifications:
        verification = verifications[0]
        if verification.user != user:
            raise Exception('PHONE_USED')
        else:
            verification.number = number
            verification.last_sent = datetime.now()
            verification.save()
    else:
        # user maybe previously verified another phone number
        verifications = Verification.objects.filter(user=user)
        if verifications:
            verification = verifications[0]
            verification.phone = phone
            verification.number = number
            verification.last_sent = datetime.now()
            verification.save()
        else:
            Verification.objects.create(number=number, phone=phone, last_sent=datetime.now(), user=user)
    return message


def generate_verification_number():
    while True:
        number = random.randint(100000, 999999)
        verification = Verification.objects.filter(number=number)
        if not verification:
            return number


def verify_code(user, number):
    verifications = Verification.objects.filter(user=user, number=number)
    if verifications:
        verification = verifications[0]
        verification.verified = True
        verification.number = 0
        verification.save()
        return True
    return False


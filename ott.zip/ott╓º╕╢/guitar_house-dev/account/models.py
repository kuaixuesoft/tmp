from __future__ import unicode_literals

__author__ = 'steve'

from django.db import models
from datetime import date, timedelta
from app.authUser.models import User


class AvailableCity(models.Model):
    name = models.CharField(max_length=255, help_text='name of the available city')
    slug = models.CharField(max_length=255, help_text='slug/choice of the available city', null=True)
    shipping_fee = models.FloatField(null=False, default=5, help_text='shipping fee of this city')

    def __unicode__(self):
        return 'Delivery City: ' + self.name


DAYS = ((0, 'Monday'), (1, 'Tuesday'), (2, 'Wednesday'), (3, 'Thursday'),
        (4, 'Friday'), (5, 'Saturday'), (6, 'Sunday'))


class AvailableShippingTime(models.Model):
    city = models.ForeignKey('AvailableCity', related_name='time_slots')
    description = models.CharField(max_length=255, help_text='description of shipping time slot')
    day = models.IntegerField(choices=DAYS, help_text='On which day can be delivered')

    def __unicode__(self):
        return 'Delivery Timeslot of City ' + self.city.name + ' on ' + DAYS[self.day][1]\
               + ' ' + self.description

    def get_next_available_date_and_description(self, length=7):
        current_time = date.today()
        for days in range(1, length + 1):
            delta = timedelta(days=days)
            temp_date = current_time + delta
            if temp_date.weekday() == self.day:
                return temp_date, temp_date.strftime("%d/%m/%Y") + ' ' + self.description

    def get_weekday(self):
        return DAYS[self.day][1]


class IndexPageData(models.Model):
    banners = models.TextField(null=True, blank=True, help_text='json array of banners with its image url and link')
    coupons = models.TextField(null=True, blank=True, help_text='json array of coupons with its image url and link')


class PickUpInfo(models.Model):
    data = models.TextField(help_text='pick up location or time')


class Verification(models.Model):
    number = models.TextField(null=True, blank=True, help_text='verification number')
    phone = models.TextField(null=True, blank=True, help_text='telephone')
    last_sent = models.DateTimeField(null=True, blank=True, help_text='last datetime to send sms')
    user = models.OneToOneField(User)
    verified = models.BooleanField(default=False, help_text='whether the user\' phone number has been verified')


class Message(models.Model):
    order_id = models.IntegerField(help_text='order id')
    subject = models.CharField(max_length=256, null=True, blank=True)
    body = models.TextField(null=True, blank=True)
    html = models.TextField(null=True, blank=True)

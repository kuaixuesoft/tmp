# guitar-house

wkhtmltopdf need to be available in the system for pdf convert to work

run this command below in command line

`sudo apt-get install wkhtmltopdf`


documentation for wkhtmltopdf:
http://ourcodeworld.com/articles/read/241/how-to-create-a-pdf-from-html-in-django
	$(function(){
        //Delete the row in table
		$('body').on('click', '.btn-del', function(){
			$(this).closest('tr').empty();
		});

        //Add description
        $('.btn-add-shipping-time').on('click', function(e){
            e.preventDefault();
            var getCity = $( ".shipping-time-city option:selected" ).text();
            var getDes = $(".shipping-time-des input").val();
            var getDay = $( ".shipping-time-day option:selected" ).text();

            var newTR = $("caption:contains("+getCity+")").closest('table').find('tbody').append('<tr>');
            var newTD = newTR.children().last().append('<td>');
            var newButton = "<button class='btn btn-danger float-right btn-del'>Delete</button>";
            var newData = getDay + " " + getDes + newButton;
            newTD.children().html(newData);
            // console.log(newData);
        });

        //Add City
        $('.btn-add-city').on('click', function(e){
        	e.preventDefault();

        	//Add new option to the dropdown box
        	var name = $('input[name="city-name"]').val();  //Get name of city

        	name = name.toLowerCase().replace(/\b[a-z]/g, function(letter) {
    			return letter.toUpperCase();		//Makes first letter of city capitalized even if city is with two words
			});

        	var first3CharOfName = name.slice(0,3).toLowerCase();  //only use the first 3 letters of the city all lower case

        	var newOptionRow = "<option value='" + first3CharOfName +"'>";
        	newOptionRow 	+= name;
        	newOptionRow 	+= "</option>";

        	$("form.add-shipping-time-form").find('select').append(newOptionRow);


        	//Add new table
            var newDiv   = '<div class="city-content table-responsive">';
            newDiv      += '<table class="city-whole-table table table-striped table-hover">';
            newDiv      += '<caption>' + name + '</caption>';
            newDiv      += '<tbody></tbody>';
        });
	});




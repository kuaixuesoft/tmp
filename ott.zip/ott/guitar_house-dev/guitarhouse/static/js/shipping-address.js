/**
 * Created by et-asus on 05/02/17.
 */

/* 到店自取 姓名/電話 validation */
$('#user-pickup-info-form').validate({
    // Set validations for specific fields
    rules         : {
        pickup_name   : {
            required : true,
            minlength: 1
        },
        pickup_phone  : {
            required : true,
            digits   : true,
            minlength: 1,
            maxlength: 10
        },
        pickupLocation: {
            required: true
        }
    },
    // Change default error messages
    messages      : {
        pickup_name   : {
            required : "姓名不能為空",
            minlength: "不能少于2個字符"
        },
        pickup_phone  : {
            required : "電話不能為空",
            digits   : "只能輸入數字",
            minlength: "至少需要10位數字",
            maxlength: "最多10位數字"
        },
        pickupLocation: {
            required: "請選一個地址"
        }
    },
    // Where to place the error message
    errorPlacement: function (error, element) {
        error.appendTo(element.prev('.errorMsg'));
    },
    // change default class for the error message
    errorClass    : "user-pickup-info-form-error"
}); // End #user-pickup-info-form validation

/* Make sure if there's error while filling 到店自取, submit will be stopped*/
$('.user-pickup-btn').on('click', function () {
    var empText = $('.errorMsg').find('label').text();
    if (empText != "") {
        console.log(empText);
        return false;
    }
    console.log("user-pickup-btn click return true");
    return true;
});

/* When using multiple pick up location, add / remove active and remove the jQuery validation error */
$('.pickup-location-label').on('click', function () {
    $('input[name="pickupLocation"]').removeAttr('checked');
    $('.pickupLocationErr').empty();
    $(this).addClass('active').siblings('.active').removeClass('active');
    // $(this).siblings('.active').removeClass('active');
    $(this).prev('input').prop('checked', 'checked');
});

/* Make sure if selecting a different delivery address, the continue button will be disabled again to force user choose deliver-time again */
$('.address-radio').on('change', function () {
    $('.delivery-btn').prop('disabled', 'disabled')
});

/* When clicking the continue btn, make sure if delivery time is selected and deliver_time value is not empty else return false,
 if true find the closest form and submit */
$('.delivery-btn').on('click', function (e) {
    e.preventDefault();
    $('.deliver-time').each(function () {
        if ($(this).hasClass('active') && $(this).next('input[name="deliver_time"]').val()) {
            $(this).closest('form').submit();
        }
    });
    return false;
});

/*
 *  Created to active the radio automatically if there's only one pickup / delivery address
 * */
var autoActive = {
    length      : 1,
    pickup      : $('.pickup-location-label'),
    deliver     : $('.address-radio'),
    pickupErrMsg: $('.pickupLocationErr'),
    enable      : function (method) {
        if (method.length === this.length) {
            switch (method) {
                case this.deliver:
                    method.click();
                    break;
                case this.pickup:
                    method.prev('input').prop('checked', 'checked');
                    this.pickupErrMsg.empty();
                    method.addClass('active').find('h5').addClass('white-txt');
                    break;
            }
        }
    }
};


/*
 * counter                   - seconds until 'send code' can be pressed again
 * show()                    - show the phone notification pop up and the opacity cover
 * hide()                    - hide the phone notification pop up and the opacity cover
 * clearErrorMsg()           - clears the error message if there is any
 * timer()                   - runs the countdown for 'send code' button
 * verified()                - get the hidden field value of phone_verified
 * getPhoneInput()           - get phone verify input field
 * getCodeInput()            - get code verfiy input field
 * getCsrfToken()            - get the csrf token for submit purose
 * submitCode()              - ajax to send the code submitted to back end to check if the code is correct or not
 * sendCode()                - send the code to the user's phone for verification purpose
 * checkInput()              - check if the input length is the either same as submitLength or sendCodeLength, if one matches, one of the button will be enabled else both disables
 * runVerificationCheck()    - check if verified is true or not, if false show the cover and notification pop up
 * init()                    - runs the whole phone notification
 * */
var phone = {
    notification: {
        counter             : 60,
        show                : function () {
            $('.cover').show();
            $('.phone-notification').show();
        },
        hide                : function () {
            $('.cover').hide();
            $('.phone-notification').hide();
        },
        clearErrorMsg       : function () {
            $('.code-error').text('');
        },
        timer               : function (counter, __this) {
            setInterval(function () {
                counter--;
                if (counter >= 0) {
                    console.log(counter);
                    __this.prop('disabled', true);
                    __this.text('Resend ' + counter);
                }
                if (counter === 0) {
                    clearInterval(counter);
                    __this.prop('disabled', false);
                    __this.text('Resend Code');
                }
            }, 1000);
        },
        // verified            : function () {
        //     return $('#phone_verified').val();
        // },
        getPhoneInput       : function () {
            return $('.phone-verify-input').val();
        },
        getCodeInput       : function () {
            return $('.code-verify-input').val();
        },
        getCsrfToken        : function (name) {
            var csrftoken = null;
            if (document.cookie && document.cookie != '') {
                var cookies = document.cookie.split(';');
                for (var i = 0; i < cookies.length; i++) {
                    var cookie = jQuery.trim(cookies[i]);
                    // Does this cookie string begin with the name we want?
                    if (cookie.substring(0, name.length + 1) == (name + '=')) {
                        csrftoken = decodeURIComponent(cookie.substring(name.length + 1));
                        break;
                    }
                }
            }
            return csrftoken;
        },
        submitCode          : function () {
            this.validateCodeInput();

            var code = this.getCodeInput;
            var ajaxUrl = '/accounts/verify_code';
            var csrftoken = this.getCsrfToken('csrftoken');
            var errorMsg = this.clearErrorMsg;
            var sendCodeMsg = this.sendCodeMsg;
            var messageSelector = $('.code-verify-input-msg');
            var hideNotification = this.hide;

            $('.phone-submit-code').on('click', function (e) {
                e.preventDefault();

                var errorCSS = 'color-red';
                var successMSG = '驗證碼錯誤/號碼已驗證';
                var msgFadeoutTime = 3000;

                errorMsg();

                $.ajax({
                    method  : "post",
                    url     : ajaxUrl,
                    dataType: "json",
                    data    : {
                        csrfmiddlewaretoken: csrftoken,
                        verify_code        : code()
                    },
                    success : function (data) {
                        //TODO 1. if success, refresh the page
                        // Done ^
                        if (data.result === 'success') {
                            location.reload();
                        }else if (data.result === 'failure'){
                            sendCodeMsg(messageSelector, errorCSS, successMSG, msgFadeoutTime);
                        }

                        //if code error .code-error will be showing an error message
                        //else close the pop up and let user continue
                        //run this.hide() to hide the over and pop up
                    },
                    error   : function (error) {
                        console.log(error);
                    }
                }); // End ajax
            });
        },
        validateCodeInput: function () {
            $('#submit-code').validate({
                rules   : {
                    'code-verify-input': {
                        digits   : true
                    }
                },
                messages: {
                    'code-verify-input': {
                        digits   : "只能輸入數字"
                    }
                },
              errorPlacement: function (error, element) {
                  error.appendTo(element.prev().find('.code-error'));
              }
          })
        },
        sendCode            : function () {
            this.validatePhoneInput();

            var ajaxUrl = '/accounts/send_code';
            var csrftoken = this.getCsrfToken('csrftoken');
            var timer = this.timer;
            var counter = this.counter;
            var errorMsg = this.clearErrorMsg;
            var phone = this.getPhoneInput;
            var sendCodeMsg = this.sendCodeMsg;
            var messageSelector = $('.send-verify-input-msg');

            $('.phone-send-code').on('click', function (e) {
                e.preventDefault();

                var successCSS = 'color-success';
                var errorCSS = 'color-red';
                var successMSG = '驗證碼已送出，60秒後可重發';
                var errorMSGs = ['號碼已驗證，60秒後可重發', '號碼錯誤，60秒後可重發'];
                var msgFadeoutTime = 3000;

                errorMsg();
                timer(counter, $(this));

                // TODO: let user input his phone, check phone's format: must be started with +1
                // Done ^
                $.ajax({
                    method  : "post",
                    url     : ajaxUrl,
                    dataType: "json",
                    data   : {csrfmiddlewaretoken: csrftoken, phone: '+1' + phone()},
                    success: function (data) {
                        if (data.result === 'success') {
                            sendCodeMsg(messageSelector, successCSS, successMSG, msgFadeoutTime);
                            return true;
                        } else if (data.result === 'failure') {
                            sendCodeMsg(messageSelector, errorCSS, errorMSGs[0], msgFadeoutTime)
                        }
                    },
                    error  : function (error) {
                        if (error.status === 400) {
                            sendCodeMsg(messageSelector, errorCSS, errorMSGs[1], msgFadeoutTime);
                            return false;
                        }
                    }
                }); // End ajax
            });
        },
        sendCodeMsg: function (selector, cssClass, msg, time) {
            selector.show().addClass(cssClass).text(msg).fadeOut(time, function () {
                $(this).removeClass(cssClass);
            });
        },
        validatePhoneInput: function () {
            $('#submit-phone-notification').validate({
                rules   : {
                    'phone-verify-input': {
                        digits   : true,
                        minlength: 10,
                        maxlength: 10
                    }
                },
                messages: {
                    'phone-verify-input': {
                        digits   : "只能輸入數字",
                        minlength: "至少需要10位數字",
                        maxlength: "最多10位數字"
                    }
                },
              errorPlacement: function (error, element) {
                  error.appendTo(element.prev().find('.code-error'));
              }
          })
        },
        // runVerificationCheck: function () {
        //     if (this.verified() == 'false') {
        //         this.show();
        //     }
        // },
        showVerification: function () {
            var showVerfiyPopUp = this.show;

            $('.show-verify').on('click', function (e) {
                e.preventDefault();
                showVerfiyPopUp();
            })
        },
        closeVerification: function () {
            var hideVerfiyPopUp = this.hide;
          $('.close-verify').on('click', function () {
              hideVerfiyPopUp();
          })
        },
        init                : function () {
            this.showVerification();
            this.closeVerification();
            this.submitCode();
            this.sendCode();
        }
    }
};

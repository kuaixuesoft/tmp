/**
 * Created by et-asus on 03/05/16.
 */
$(function(){
    $('.coupon-tab').hide();

    $('.banner-tab-click').on('click', function(){
        $('span.tab-active').removeClass('tab-active');
        $(this).addClass('tab-active');
        $('.banner-tab').show();
        $('.coupon-tab').hide();
    });

    $('.coupon-tab-click').on('click', function(){
        $('span.tab-active').removeClass('tab-active');
        $(this).addClass('tab-active');
        $('.banner-tab').hide();
        $('.coupon-tab').show();
    })
});
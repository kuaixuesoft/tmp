/**
 * Created by et-asus on 05/02/17.
 */
/**
 * matchDomain()    - checks if the current hostname matches one of the existing domains and return 0/1
 * insertURL()        - inputs the href and text field
 * renderSwap()        - using the return value from matchDomain to determain what to input *1 = true, 0 = false*
 */
var swapDomainUrl = {
    existingDomains: ['vanfruits.com', 'victoria.vanfruits.com'],
    swapText       : ['溫哥華站', '維多利亞站'],
    currentDomain  : window.location.hostname,
    urlPrefix      : window.location.protocol + '//',
    matchDomain    : function () {
        return $.inArray(this.currentDomain, this.existingDomains)
    },
    insertURL      : function (index) {
        return $('.swapDomainUrl').attr('href', this.urlPrefix + this.existingDomains[index]).text(this.swapText[index]);
    },
    renderSwap     : function () {
        var index = Number(!this.matchDomain());
        (this.matchDomain()) ? this.insertURL(index) : this.insertURL(index);
    }
};
// swapDomainUrl.renderSwap();
/**
 * Created by et-ubuntu-pc on 08/09/16.
 */

/*
 * getProductNames()
 * @param {object} offOrNostock - offline or no stock uses the classes to determine if it's error message of no stock or offline product. Example of the input would be $(".availability.outofstock")
 * Return list of the product's name or empty string
 * */
function getProductNames(offOrNostock){
    var nameList = "";
    offOrNostock.each(function(){
        var message = $(this).text();
        var productName = $(this).closest(".basket-items").find(".product-name").text();
        if(message != ""){
            nameList += productName + "<br>";
        }
    });
    return nameList;
}

/* When "去結算 / Proceed to checkout" is clicked, run the following before going to /checkout*/
$(".processed-checkout-btn").on('click', function(){
    var productOutOfStock = getProductNames($(".availability.outofstock")); // Names for products out of stock
    var productOffline = getProductNames($(".availability.instock"));       // Names for products offline

    // If none of the name list has empty string run ths code
    if(productOutOfStock != "" || productOffline != ""){
        // Prints the names with message of no stock or offline and use them in the pop up cart header
        var printOutOfStockMsg = (productOutOfStock == "") ? "" : ("<p class='out-off-stock-msg'>" + productOutOfStock + "</p><h3>存貨不足</h3>");
        var printStockOfflineMsg = (productOffline == "") ? "" : ("<p class='out-off-stock-msg'>" + productOffline + "</p><h3>已下線</h3>");
        
        // Adds a line break if there are both products out of stock and offline
        var lineBreak = (productOutOfStock != "" && productOffline != "") ? "<hr style='border: 1px solid black;'>" : "";

        //gets the script from shopping-cart-ajax.js and uses some of it's code to show the pop up cart info
        $.getScript("{/../../static/js/shopping-cart-ajax.js", function(){
            $('.cover').show();
            cartHeader.html(printOutOfStockMsg + lineBreak + printStockOfflineMsg);
            $('.choosed.clearfix.cart-pop-div').hide();
            cartMessage.hide();
            cart.show();
            hideCart();
        });
        return false;
    }else{
        $.getScript("{/../../static/js/shopping-cart-ajax.js", function(){
            $('.cover').show();
            cart.show();
            cartHeader.html("");
            cartMessage.hide();
            $('.go-basket-btn').addClass("addOrderOption");
            hideCart();
        });        
        // return true;
    }
});

/*
 * additionalInfo()
 * Using the pop up cart to output additional info content requested by the client
 * This info only pops are at a certain page
 * */
function additionalInfo() {
    $.getScript("/../../static/js/shopping-cart-ajax.js", function () {
        $('.cover').show();
        cart.show();
        var renderCloseBtn = '<div class="cart-close-btn"><img class="cart-popup-hide cart-pop-div" alt="" src="/static/images/x.png"></div>';
        var renderInfoContents = '<p style="clear: both;">為確保向各位客戶提供更加優質的購物體驗，煩請選擇送貨到家的客人在下單前務必確保所選擇的送貨時間段內家中有人收貨，並註意保持手機，電話或微信等通訊方式順暢.如有特殊情況需要更改送貨時間或地址，請提前聯繫我們客服人員告知情況. 若送貨時家中無人收貨，我們會首先嘗試將貨品留在您家門口，客服人員會隨後與您聯繫處理付款事宜。對於家中無人收貨且通訊不暢的公寓住戶，我們會在您住所處等候5分鐘無果後離開，以確保不耽誤餘下的送單任務。而該訂單擇日再次補送時客人需要支付額外運費。</p>';
        var renderAcknowledgedBtn = '<button class="cart-popup-hide btn btn-primary">明白了</button>';

        $('.shop-content').empty().append([renderCloseBtn, renderInfoContents, renderAcknowledgedBtn]).addClass('acknowledgeInfo');

        hideCart();
    });
}


/** displayPointRedeemTable object
 * points                   - which stores how much points needed in order to redeem
 * redeemPercentage         - each redeem has a different percentage calculation
 * redeemAmount             - total amount of $ can be redeemed (calculated using number of points * the percentage)
 * redeemCodePrefix         - in case if the code need a prefix, enter it hee
 * numberOfRedeemOptions    - total number of redeem optoin available
 * output                   - store the tr going to be appended to the redeem info table
 * redeemCalculation()      - loops through gets the points and redeemPercentage and calculate the redeemAmount
 * printOutput()            - runs redeemCalculation() then forms the tr and appended it
 *
 * */
var displayPointRedeemTable = {
    points: [500, 1000, 3000],
    redeemPercentage: [1,2,4],
    redeemAmount: [],
    redeemCodePrefix: "REDEEM",
    numberOfRedeemOptions: 3,
    output: "",
    redeemCalculation: function () {
        for(var i = 0, x = this.redeemPercentage.length; i < x; i++){
            this.redeemAmount.push(this.points[i]*this.redeemPercentage[i]/100);
        }
    },
    printOutput: function () {
        this.redeemCalculation();
        for (var i = 0; i < this.numberOfRedeemOptions; i++) {
            this.output += "<tr><td>" + this.points[i] + "</td><td>$" + this.redeemAmount[i] + "</td><td>" + this.redeemCodePrefix + this.points[i] + "</td></tr>";
        }
        $('.redeem-points-info').find('table').append(this.output)
    }
};

displayPointRedeemTable.printOutput();
window.onload = function() {

  var showingImage = $("#showingImage");

  function show(src) {
    if (showingImage.attr('src') != src) {
      showingImage.fadeOut(500, function () {
        showingImage.attr("src", src).fadeIn(500);
      });
    }
  }
  

  $("img.smallimages").mouseover(function() {
    show($(this).attr("src"));
  })

}
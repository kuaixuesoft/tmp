__author__ = 'steve'
from django.conf import settings
from django.http import HttpResponse
import random
import hashlib
from string import digits, ascii_lowercase, ascii_uppercase
import boto


def amazon_upload_or_update_file(filename, file):
    a3 = boto.connect_s3(aws_access_key_id='',
                         aws_secret_access_key='')

    bucket = a3.get_bucket('description-image')
    key = bucket.new_key(filename)
    if isinstance(file, basestring):
        key.set_contents_from_string(file)
    else:
        key.set_contents_from_file(file)


def rand_fname(suffix=None, length=16, ext=None):
    chars = digits + ascii_lowercase + ascii_uppercase
    fname = ''
    for i in range(length):
        fname += random.choice(chars)
    if ext: fname += '.' + ext
    if suffix: fname = suffix + '-' + fname
    return fname


def upload(request):
    if request.FILES and request.FILES.get('image'):
        image = request.FILES.get('image')
        fname = rand_fname() + '.jpg'
        amazon_upload_or_update_file(fname, image)
        url = 'https://s3-us-west-2.amazonaws.com/description-image/' + fname
        return HttpResponse("<script>top.$('.mce-btn.mce-open').parent().find('.mce-textbox').val('%s').closest('.mce-window').find('.mce-primary').click();</script>" % url)
    return HttpResponse("<script>alert('%s');</script>" % 'something wrong')

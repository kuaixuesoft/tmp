#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' for shipping app '''
SHIPPING_METHOD_DECLARATION = u"折後消費滿88免運費"

GET_BY_YOUR_SELF_SHIPPING_DECLARATION = u"<p class='pickup-address'>" \
                                        u"<strong>取貨地址</strong><br>" \
                                        u"211-669 Ridley Place Delta (Annacis Island)" \
                                        u"取貨時間為次日9am至5pm之間</p>"

ADD_ORDER_SHIPPING = u"追加訂單免運費 僅加單用戶可選（只有還未處理的訂單才可加單）"


''' API constants '''
SUCCESS = 'success'
FAILURE = 'failure'

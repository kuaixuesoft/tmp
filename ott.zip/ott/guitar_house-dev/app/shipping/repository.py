__author__ = 'steve'

from oscar.apps.shipping import repository

from . import methods


# Override shipping repository in order to provide our own one
# custom method
class Repository(repository.Repository):
    methods = (methods.GetByYourself(), methods.Standard(), methods.AddOrder())

    #Override
    def get_default_shipping_method(
            self, basket, user=None, shipping_addr=None,
            request=None, **kwargs):
        return methods.Standard()
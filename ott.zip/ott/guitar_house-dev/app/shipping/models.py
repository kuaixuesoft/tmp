from oscar.apps.shipping.models import *  # noqa

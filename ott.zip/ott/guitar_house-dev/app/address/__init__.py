default_app_config = 'oscar.apps.address.config.AddressConfig'

#!/usr/bin/env python
# -*- coding: utf-8 -*-
from django import forms
from django.conf import settings

from oscar.core.loading import get_model
from oscar.views.generic import PhoneNumberMixin

from account.models import AvailableCity

UserAddress = get_model('address', 'useraddress')
Country = get_model('address', 'Country')


class AbstractAddressForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        """
        Set fields in OSCAR_REQUIRED_ADDRESS_FIELDS as required.
        """
        super(AbstractAddressForm, self).__init__(*args, **kwargs)
        field_names = (set(self.fields) &
                       set(settings.OSCAR_REQUIRED_ADDRESS_FIELDS))
        for field_name in field_names:
            self.fields[field_name].required = True


class UserAddressForm(PhoneNumberMixin, AbstractAddressForm):

    class Meta:
        model = UserAddress
        fields = [
            'title', 'first_name', 'last_name',
            'line1', 'line2', 'line3', 'line4',
            'state', 'postcode', 'country',
            'phone_number', 'notes',
        ]

    def __init__(self, user, *args, **kwargs):
        super(UserAddressForm, self).__init__(*args, **kwargs)
        self.instance.user = user
        self.fields['title'].label = u'稱呼 / Title'
        self.fields['first_name'].label = u'名 / First Name'
        self.fields['last_name'].label = u'姓 / Last Name'
        self.fields['line1'].label = u'運送地址（第一行） / First line of address'
        self.fields['line2'].label = u'運送地址（第二行） / Second line of address'
        self.fields['line3'].label = u'運送地址（第三行） / Third line of address'
        self.fields.pop('state', None)
        self.instance.state = 'BC'
        self.fields['postcode'].label = u'郵編 / Postal Code'
        self.fields['phone_number'].label = u'電話 / Phone number'
        self.fields['notes'].label = u'備註 / Notes'
        self.fields['line4'].label = u'城市 / City'
        self.fields['phone_number'].required = True
        cities = AvailableCity.objects.all()
        city_choice = []
        for city in cities:
            city_choice.append((city.slug, city.name))

        self.fields['line4'].widget = forms.Select(choices=city_choice)

        countries = Country._default_manager.filter(
            is_shipping_country=True)

        # No need to show country dropdown if there is only one option
        if len(countries) == 1:
            self.fields.pop('country', None)
            self.instance.country = countries[0]
        else:
            self.fields['country'].queryset = countries
            self.fields['country'].empty_label = None



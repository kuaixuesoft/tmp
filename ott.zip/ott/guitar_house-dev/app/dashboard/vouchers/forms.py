#!/usr/bin/env python
# -*- coding: utf-8 -*-
from django import forms
from django.utils.translation import ugettext_lazy as _

from oscar.core.loading import get_model
from oscar.forms import widgets

Voucher = get_model('voucher', 'Voucher')
Benefit = get_model('offer', 'Benefit')
Range = get_model('offer', 'Range')


# dashboard/vouchers/update/{voucher-id}/
# 管理台 > 优惠券 > voucher-name > 编辑
class VoucherForm(forms.Form):
    """
    A specialised form for creating a voucher and offer
    model.
    """
    name = forms.CharField(label=_(u"優惠名稱"))
    code = forms.CharField(label=_(u"優惠碼"))

    start_datetime = forms.DateTimeField(
        widget=widgets.DateTimePickerInput(),
        label=_(u"創建日"))
    end_datetime = forms.DateTimeField(
        label=_(u"結束日"), widget=widgets.DateTimePickerInput())
    usage = forms.ChoiceField(choices=Voucher.USAGE_CHOICES, label=_(u"用法"))

    benefit_range = forms.ModelChoiceField(
        label=_(u'哪個產品有折扣?'),
        queryset=Range.objects.all(),
    )
    type_choices = (
        (Benefit.PERCENTAGE, _(u'指定的產品內可用百分比折扣 / Percentage off of products in range')),
        (Benefit.FIXED, _(u'指定的產品內可用折扣 / Fixed amount off of products in range')),
        (Benefit.SHIPPING_PERCENTAGE,
         _(u"運輸費的百分比 / Discount is a percentage off of the shipping cost")),
        (Benefit.SHIPPING_ABSOLUTE,
         _(u"固定的運輸費折扣 / Discount is a fixed amount of the shipping cost")),
        (Benefit.SHIPPING_FIXED_PRICE, _(u"固定運輸費 / Get shipping for a fixed price")),
    )
    benefit_type = forms.ChoiceField(
        choices=type_choices,
        label=_(u'折扣類型'),
    )
    benefit_value = forms.DecimalField(
        label=_(u'折扣價'))

    def __init__(self, voucher=None, *args, **kwargs):
        self.voucher = voucher
        super(VoucherForm, self).__init__(*args, **kwargs)

    def clean_name(self):
        name = self.cleaned_data['name']
        try:
            voucher = Voucher.objects.get(name=name)
        except Voucher.DoesNotExist:
            pass
        else:
            if (not self.voucher) or (voucher.id != self.voucher.id):
                raise forms.ValidationError(_(u"優惠名 '%s' 已"
                                              u" 存在") % name)
        return name

    def clean_code(self):
        code = self.cleaned_data['code'].strip().upper()
        if not code:
            raise forms.ValidationError(_(u"請輸入優惠碼"))
        try:
            voucher = Voucher.objects.get(code=code)
        except Voucher.DoesNotExist:
            pass
        else:
            if (not self.voucher) or (voucher.id != self.voucher.id):
                raise forms.ValidationError(_(u"優惠碼 '%s' 已"
                                              u" 存在") % code)
        return code

    def clean(self):
        cleaned_data = super(VoucherForm, self).clean()
        start_datetime = cleaned_data.get('start_datetime')
        end_datetime = cleaned_data.get('end_datetime')
        if start_datetime and end_datetime and end_datetime < start_datetime:
            raise forms.ValidationError(_(u"創建日一定要在結束日之前"))
        return cleaned_data


class VoucherSearchForm(forms.Form):
    name = forms.CharField(required=False, label=_("Name"))
    code = forms.CharField(required=False, label=_("Code"))
    is_active = forms.BooleanField(required=False, label=_("Is Active?"))

    def clean_code(self):
        return self.cleaned_data['code'].upper()

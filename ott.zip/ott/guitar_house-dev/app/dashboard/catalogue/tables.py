#!/usr/bin/env python
# -*- coding: utf-8 -*-
from django.utils.safestring import mark_safe
from django.utils.translation import ugettext_lazy as _
from django.utils.translation import ungettext_lazy
from django_tables2 import A, Column, LinkColumn, TemplateColumn

from oscar.core.loading import get_class, get_model

DashboardTable = get_class('dashboard.tables', 'DashboardTable')
Product = get_model('catalogue', 'Product')
Category = get_model('catalogue', 'Category')


class ProductTable(DashboardTable):
    title = TemplateColumn(
        verbose_name=_(u'產品名'),
        template_name='dashboard/catalogue/product_row_title.html',
        order_by='title', accessor=A('title'))
    upc = Column(
        verbose_name=_(u'唯一產品編號')
    )
    image = TemplateColumn(
        verbose_name=_(u'圖片'),
        template_name='dashboard/catalogue/product_row_image.html',
        orderable=False)
    product_class = Column(
        verbose_name=_(u'產品類別'),
        accessor=A('product_class'),
        order_by='product_class__name')
    # variants = TemplateColumn(
    #     verbose_name=_("Variants"),
    #     template_name='dashboard/catalogue/product_row_variants.html',
    #     orderable=False
    # )
    published = TemplateColumn(
        verbose_name=_(u'是否上線'),
        template_name='dashboard/catalogue/product_row_published.html',
        orderable=False)
    stock_records = TemplateColumn(
        verbose_name=_(u'库存'),
        template_name='dashboard/catalogue/product_row_stockrecords.html',
        orderable=False)
    num_allocated = TemplateColumn(
        verbose_name=_(u'已分配'),
        template_name='dashboard/catalogue/product_row_allocated.html',
        orderable=False)
    actions = TemplateColumn(
        verbose_name=_(u'處理'),
        template_name='dashboard/catalogue/product_row_actions.html',
        orderable=False)

    icon = "sitemap"
    get_caption_display = u"產品"

    class Meta(DashboardTable.Meta):
        model = Product
        fields = ('upc', 'date_updated')
        sequence = ('title', 'upc', 'image', 'product_class', 'published',
                    'stock_records', 'num_allocated', '...', 'date_updated', 'actions')
        order_by = '-date_updated'


class CategoryTable(DashboardTable):
    name = LinkColumn('dashboard:catalogue-category-update', args=[A('pk')], verbose_name=_(u'分類名'))
    description = TemplateColumn(
        verbose_name=_(u'描述類別'),
        template_code='{{ record.description|default:""|striptags'
                      '|cut:"&nbsp;"|truncatewords:6 }}')
    # mark_safe is needed because of
    # https://github.com/bradleyayers/django-tables2/issues/187
    num_children = LinkColumn(
        'dashboard:catalogue-category-detail-list', args=[A('pk')],
        verbose_name=mark_safe(_(u'子類數 / Number of child categories')),
        accessor='get_num_children',
        orderable=False)
    actions = TemplateColumn(
        verbose_name=_(u'處理'),
        template_name='dashboard/catalogue/category_row_actions.html',
        orderable=False)

    icon = "sitemap"
    caption = ungettext_lazy(u"%s 個分類", u"%s 個分類")

    class Meta(DashboardTable.Meta):
        model = Category
        fields = ('name', 'description')

    # def __init__(self, *args, **kwargs):
    #     super(CategoryTable, self).__init__(*args, **kwargs)
    #     self.fields['name'].label = u'产品类别'
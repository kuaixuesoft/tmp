from django.db import models

class ottpayment(models.Model):
    order_id = models.CharField(max_length=20, verbose_name=u"order_id")
    qrimg = models.CharField(max_length=20, verbose_name=u"qrimg")
    xxxx= models.CharField(max_length=20, verbose_name=u"qrimg")

    class Meta:
        app_label = 'checkout'
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('order', '0008_order_add_to_order'),
    ]

    operations = [
        migrations.AddField(
            model_name='order',
            name='pickup_location',
            field=models.TextField(null=True),
        ),
    ]

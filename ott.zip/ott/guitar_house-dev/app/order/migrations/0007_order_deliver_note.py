# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('order', '0006_auto_20160716_1631'),
    ]

    operations = [
        migrations.AddField(
            model_name='order',
            name='deliver_note',
            field=models.CharField(help_text=b'deliver notes', max_length=1024, null=True),
        ),
    ]

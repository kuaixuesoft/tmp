# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('order', '0004_auto_20160111_1108'),
    ]

    operations = [
        migrations.AddField(
            model_name='order',
            name='deliver_date',
            field=models.DateTimeField(help_text=b'deliver date', null=True),
        ),
        migrations.AddField(
            model_name='order',
            name='deliver_time',
            field=models.CharField(help_text=b'deliver time slot', max_length=255, null=True),
        ),
    ]

from oscar.apps.order.abstract_models import *
from django.db import models


class Order(AbstractOrder):
    deliver_date = models.DateTimeField(null=True, help_text='deliver date')
    deliver_time = models.CharField(null=True, max_length=255, help_text='deliver time slot')
    deliver_note = models.CharField(null=True, max_length=1024, help_text='deliver notes')
    pickup_name = models.CharField(null=True, max_length=255, help_text='pickup name')
    pickup_phone = models.CharField(null=True, max_length=255, help_text='pickup phone')
    pickup_note = models.TextField(null=True, help_text='pickup note')
    pickup_location = models.TextField(null=True)
    add_to_order = models.ForeignKey('self', null=True)

from oscar.apps.order.models import *  # noqa

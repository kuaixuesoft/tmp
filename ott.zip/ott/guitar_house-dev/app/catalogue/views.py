from django.utils.decorators import method_decorator
from django.views.decorators.csrf import ensure_csrf_cookie
from oscar.apps.catalogue.views import CatalogueView as CoreCatalogueView

class CatalogueView(CoreCatalogueView):
    @method_decorator(ensure_csrf_cookie)
    def dispatch(self, *args, **kwargs):
        return super(CatalogueView, self).dispatch(*args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(CatalogueView, self).get_context_data(**kwargs)

        products = context['products']

        return context

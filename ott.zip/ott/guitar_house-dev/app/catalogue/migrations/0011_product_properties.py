# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('catalogue', '0010_auto_20160507_2255'),
    ]

    operations = [
        migrations.AddField(
            model_name='product',
            name='properties',
            field=models.TextField(help_text=b'property pair in json format', blank=True),
        ),
    ]

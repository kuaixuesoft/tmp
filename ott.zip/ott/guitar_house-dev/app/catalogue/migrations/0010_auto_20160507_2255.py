# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('catalogue', '0009_auto_20160507_2110'),
    ]

    operations = [
        migrations.AddField(
            model_name='product',
            name='flag_image_url',
            field=models.CharField(max_length=255, blank=True),
        ),
        migrations.AddField(
            model_name='product',
            name='short_description',
            field=models.CharField(max_length=255, blank=True),
        ),
    ]

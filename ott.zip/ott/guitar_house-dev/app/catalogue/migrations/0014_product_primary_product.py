# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('catalogue', '0013_product_original_price'),
    ]

    operations = [
        migrations.AddField(
            model_name='product',
            name='primary_product',
            field=models.ForeignKey(related_name='variations', blank=True, to='catalogue.Product', help_text=b'the primary product', null=True),
        ),
    ]

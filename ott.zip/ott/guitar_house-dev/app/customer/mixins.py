#!/usr/bin/env python
# -*- coding: utf8 -*-
import logging
import hashlib
import random

from django.conf import settings
from django.contrib.auth import login as auth_login
from django.contrib.auth import authenticate
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import get_template
from django.core.mail import EmailMessage, send_mail
from django.template import Context

from oscar.apps.customer.signals import user_registered
from oscar.core.compat import get_user_model
from oscar.core.loading import get_class, get_model

User = get_user_model()
CommunicationEventType = get_model('customer', 'CommunicationEventType')
Dispatcher = get_class('customer.utils', 'Dispatcher')

logger = logging.getLogger('oscar.customer')


class PageTitleMixin(object):
    """
    Passes page_title and active_tab into context, which makes it quite useful
    for the accounts views.

    Dynamic page titles are possible by overriding get_page_title.
    """
    page_title = None
    active_tab = None

    # Use a method that can be overridden and customised
    def get_page_title(self):
        return self.page_title

    def get_context_data(self, **kwargs):
        ctx = super(PageTitleMixin, self).get_context_data(**kwargs)
        ctx.setdefault('page_title', self.get_page_title())
        ctx.setdefault('active_tab', self.active_tab)
        return ctx


class RegisterUserMixin(object):
    communication_type_code = 'REGISTRATION'

    def register_user(self, form):
        """
        Create a user instance and send a new registration email (if configured
        to).
        """
        user = form.save()
        user.is_active = False

        inviter = form.cleaned_data.get('invitation')
        if inviter:
            user.inviter_id = inviter

        # Raise signal robustly (we don't want exceptions to crash the request
        # handling).
        user_registered.send_robust(
            sender=self, request=self.request, user=user)

        num = str(random.randint(1, 100000000))
        activation_code = hashlib.sha1(num).hexdigest()
        user.activation_code = activation_code
        user.save()

        # send activation email
        # should be changed in development server and production server
        subject = u'溫鮮生：請驗證您的郵箱'
        to = [user.email]
        from_email = settings.OSCAR_FROM_EMAIL
        activation_url = 'http://' + self.request.get_host() + '/accounts/activation/' + activation_code
        context = {'activation_url': activation_url, 'inviter': inviter}

        message = get_template('customer/emails/activation_email.html').render(Context(context))
        msg = EmailMessage(subject, message, to=to, from_email=from_email)
        msg.content_subtype = 'html'
        msg.send()


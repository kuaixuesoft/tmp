__author__ = 'steve'
from django.db import models

from oscar.apps.customer.abstract_models import AbstractUser

# invitation code is the base64 encoding of user's id
class User(AbstractUser):
    activation_code = models.CharField(max_length=255, blank=True)
    points = models.IntegerField(default=0, help_text='rewarding points')
    inviter_id = models.CharField(max_length=255, blank=True)

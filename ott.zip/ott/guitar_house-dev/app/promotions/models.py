from oscar.apps.promotions.models import *  # noqa

from django.conf.urls import url

from oscar.apps.promotions.models import KeywordPromotion, PagePromotion
from oscar.core.application import Application
from oscar.core.loading import get_class


class PromotionsApplication(Application):
    name = 'promotions'

    home_view = get_class('promotions.views', 'HomeView')
    record_click_view = get_class('promotions.views', 'RecordClickView')
    about_view = get_class('promotions.views', 'AboutView')
    sale_view = get_class('promotions.views', 'SaleView')

    def get_urls(self):
        urls = [
            url(r'page-redirect/(?P<page_promotion_id>\d+)/$',
                self.record_click_view.as_view(model=PagePromotion),
                name='page-click'),
            url(r'keyword-redirect/(?P<keyword_promotion_id>\d+)/$',
                self.record_click_view.as_view(model=KeywordPromotion),
                name='keyword-click'),
            url(r'about/$', self.about_view.as_view(), name='about'),
            url(r'sale/$', self.sale_view.as_view(), name='sale'),
            url(r'^$', self.home_view.as_view(), name='home'),
        ]
        return self.post_process_urls(urls)


application = PromotionsApplication()

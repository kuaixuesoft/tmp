default_app_config = 'oscar.apps.promotions.config.PromotionsConfig'

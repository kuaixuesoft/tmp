import hashlib,json

def sortStringByMap(bo):
    #print(bo)
    keyarray = bo.keys()
    sortarray = list(keyarray)
    sortarray.sort()
    result_list = []
    for node in sortarray:
        result_list.append( str(bo[node]) )
    result = ''.join(result_list)
    #print(result)
    return result

def signByMD5(str):
    sign = hashlib.md5(str.encode('utf-8')).hexdigest().upper()
    return sign
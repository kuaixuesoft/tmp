from django.conf.urls import url
from django.views.decorators.csrf import csrf_exempt

from .views import PayView, PayNotifyView, RefundView, QueryTransactionView, QueryRefundView

urlpatterns = [
    url(r"^pay/$", csrf_exempt(PayView.as_view()), name="pay"),
    url(r"^notify/$", PayNotifyView.as_view(), name="notify"),
    url(r"^refund/$", RefundView.as_view(), name="refund"),
    url(r"^querytransaction/$", QueryTransactionView.as_view(), name="querytransaction"),
    url(r"^queryrefund/$", QueryRefundView.as_view(), name="queryrefund"),
]

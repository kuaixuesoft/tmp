from rest_framework import serializers

from .models import OTTOrder, OTTRefund


class OrderSerializer(serializers.ModelSerializer):

    class Meta:
        model = OTTOrder
        fields = '__all__'

        
class RefundSerializer(serializers.ModelSerializer):

    class Meta:
        model = OTTRefund
        fields = '__all__'

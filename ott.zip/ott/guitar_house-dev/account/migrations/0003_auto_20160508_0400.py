# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('account', '0002_availablecity_slug'),
    ]

    operations = [
        migrations.AlterField(
            model_name='availableshippingtime',
            name='city',
            field=models.ForeignKey(related_name='time_slots', to='account.AvailableCity'),
        ),
    ]

# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('account', '0005_pickupinfo'),
    ]

    operations = [
        migrations.AddField(
            model_name='availablecity',
            name='shipping_fee',
            field=models.FloatField(default=5, help_text='shipping fee of this city'),
        ),
    ]

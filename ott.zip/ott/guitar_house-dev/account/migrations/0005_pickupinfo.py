# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('account', '0004_indexpagedata'),
    ]

    operations = [
        migrations.CreateModel(
            name='PickUpInfo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('data', models.TextField(help_text='pick up location or time')),
            ],
        ),
    ]

# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('account', '0007_verification'),
    ]

    operations = [
        migrations.CreateModel(
            name='Message',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('order_id', models.IntegerField(help_text='order id')),
                ('subject', models.CharField(max_length=256, null=True, blank=True)),
                ('body', models.TextField(null=True, blank=True)),
                ('html', models.TextField(null=True, blank=True)),
            ],
        ),
    ]
